import os
from pysettings.jsonConfig import AdvancedJsonConfig

"""
This script handles the Config file I/O.
"""

BASE_PATH = os.getcwd()
CONFIG_PATH = os.path.join(BASE_PATH, 'config')

class Config:
    AdvancedJsonConfig.setConfigFolderPath(CONFIG_PATH)

    SETTINGS_CONFIG = AdvancedJsonConfig("SettingsConfig")
    SETTINGS_CONFIG.setDefault({
        "show_system_files":False,
        "show_hidden_files":False,
        "ask_before_delete":True,

        "active_theme":"default",

        "dark_mode":False
    })
    SETTINGS_CONFIG.load("settings.json")

    NEW_FILE_CONFIG = AdvancedJsonConfig("FileTypesConfig")
    NEW_FILE_CONFIG.setDefault({
        "Text-File":["txt", "none"],
        "Json-File":["json", "none"],
        "Python-File":["py", "none"],
        "Word-Document":["docx", "none"],
        "Excel-Document":["xslx", "none"],
        "Acces-Database":["accdb", "none"],
        "PowerPoint-Document":["ppt", "none"],
    })
    NEW_FILE_CONFIG.load("file_types.json")

    FAVORITES_CONFIG = AdvancedJsonConfig("FavoritesConfig")
    FAVORITES_CONFIG.setDefault({
        "favorites":{}
    })
    FAVORITES_CONFIG.load("favorites.json")

    KEY_BIND_CONFIG = AdvancedJsonConfig("KeyBinds")
    KEY_BIND_CONFIG.setDefault({
        "main":{
            "copy":{"bind":"<Control-c>", "text":"Control + c"},
            "cut":{"bind":"<Control-x>", "text":"Control + x"},
            "paste":{"bind":"<Control-v>", "text":"Control + v"},
            "undo":{"bind":"<Control-z>", "text":"Control + z"},
            "redo":{"bind":"<Control-y>", "text":"Control + y"},
            "rename":{"bind":"<F2>", "text":"F2"},
            "duplicate":{"bind":"<Alt-d>", "text":"Alt + d"},
            "delete":{"bind":"<Delete>", "text":"Entf"},
            "search":{"bind":"<Control-f>", "text":"Control + f"},

            "refresh":{"bind":"<F5>", "text":"F5"},

            "new_folder":{"bind":"CANCEL", "text":"None"},
            "new_file":{"bind":"CANCEL", "text":"None"},
            "new_zip":{"bind":"CANCEL", "text":"None"},
            "new_ref":{"bind":"CANCEL", "text":"None"},
            "new_py":{"bind":"CANCEL", "text":"None"},
            "new_template":{"bind":"CANCEL", "text":"None"},


            "filetree_backward":{"bind":"<BackSpace>", "text":"Backspace"},
            "filetree_forward":{"bind":"CANCEL", "text":"None"},
            "filetree_openInWin":{"bind":"<Alt-e>", "text":"Alt + e"},
            "filetree_selectAll":{"bind":"<Control-a>", "text":"Control + a"},
            "filetree_dir_up":{"bind":"<Alt-Up>", "text":"Alt + Up"},

            "settings":{"bind":"<Alt-s>", "text":"Alt + s"},
            "plugin_manager":{"bind":"<Alt-p>", "text":"Alt + p"},
            "pin_menu":{"bind":"<Alt-p>", "text":"Alt + p"},
            "favorites_menu":{"bind":"<Alt-f>", "text":"Alt + f"},
        }
    })
    KEY_BIND_CONFIG.load("key_bindings.json")
