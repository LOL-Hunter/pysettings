from pysettings.text import MsgText, TextColor
from pysettings import tk
import time as t
import os

PATH = os.path.split(os.path.realpath(__file__))[0]

COMMON_PATH = os.path.join(PATH, "icons", "common")
EXTENTIONS_PATH = os.path.join(PATH, "icons", "extention")
NAVIGATION_PATH = os.path.join(PATH, "icons", "navigation")



class IconHandler:
    COMMON = {}
    NAVIGATION = {}
    FILE_EXTENTIONS = {}
    @staticmethod
    def getIconFromExtention(ext):
        ext = ext.replace(".", "")
        ext = ext.lower()
        if ext in IconHandler.FILE_EXTENTIONS.keys():
            return IconHandler.FILE_EXTENTIONS[ext]
        elif ext in IconHandler.COMMON.keys():
            return IconHandler.COMMON[ext]
        else:
            return IconHandler.COMMON["file"]
    @staticmethod
    def getReferenceIcon():
        return IconHandler.COMMON["reference"]
    @staticmethod
    def getFolderIcon()->tk.PILImage:
        return IconHandler.COMMON["folder"]
    @staticmethod
    def getFileIcon():
        return IconHandler.COMMON["file"]
    @staticmethod
    def mainIcon():
        return IconHandler.COMMON["main"]
    @staticmethod
    def getNavigationIcon(name):
        return IconHandler.NAVIGATION[name]
    @staticmethod
    def loadIcons():
        icons = 0
        MsgText.info("Loading icons...")
        extentions = {}
        for image in os.listdir(EXTENTIONS_PATH):
            icons += 1
            _ext = image.split(".")[0]
            extentions[_ext] = tk.PILImage.loadImage(EXTENTIONS_PATH+"\\"+image).resizeToIcon().preRender()
        comData = {}
        for image in os.listdir(COMMON_PATH):
            icons += 1
            _ext = image.split(".")[0]
            comData[_ext] = tk.PILImage.loadImage(COMMON_PATH+"\\"+image).resizeToIcon().preRender()
        navigationData = {}
        for image in os.listdir(NAVIGATION_PATH):
            icons += 1
            _ext = image.split(".")[0]
            navigationData[_ext] = tk.PILImage.loadImage(NAVIGATION_PATH + "\\" + image).resizeToIcon().preRender()

        IconHandler.NAVIGATION = navigationData
        IconHandler.COMMON = comData
        IconHandler.FILE_EXTENTIONS = extentions
        MsgText.info(f"Successfully loaded {icons} icons!")


