import os
import time as t
from traceback import format_exc
from importlib import import_module, reload
from pysettings.text import MsgText, TextColor
from pysettings import tk
from string import ascii_letters
from time import sleep
import threading as th

from PyExplorer.src.configLoader import Config
from PyExplorer.src.package.misc import parseTkEvent

BASE_PATH = os.getcwd() #C:\Users\langh\AppData\Local\Programs\Python\Python310\Lib\PyExplorer\src


class PluginGeneratorGUI(tk.Dialog):
    """
    -add event
    -add gui execute func
    """

    def __init__(self, master):
        super().__init__(master, False)

        self.setTitle("Plugin Generator v1.0")

        self.plugin_data = {
            "name":"",
            "path":"",
            "version":"",
            "desc":""
        }
        self._imports = {}
        self._events = {}

        self.template = self.loadTemplate("template.py")
        self.gui = self.loadTemplate("template_gui.py")


        self.setWindowSize(800, 500)
        #self.setResizeable(False)

        self.text = tk.Text(self, readOnly=True)
        self.text.placeRelative(changeWidth=-200)

        self.saved = True

        tools = tk.LabelFrame(self)
        tools.setText("Configure plugin")
        tools.placeRelative(fixWidth=200, stickRight=True)

        self.name = tk.TextEntry(tools)
        self.name.getEntry().onUserInputEvent(self.updateWidgets)
        self.name.setText("Plugin name: ")
        self.name.place(0, 0, 195, 25)
        self.oldName = ""

        self.version = tk.TextEntry(tools)
        self.version.getEntry().onUserInputEvent(self.updateWidgets)
        self.version.setValue("v1.0")
        self.version.setText("Plugin version: ")
        self.version.place(0, 25, 195, 25)

        frame = tk.LabelFrame(tools)
        frame.setText("Description")
        frame.placeRelative(fixY=50, fixHeight=125, changeWidth=-5)

        self.desc = tk.Text(frame).placeRelative(changeWidth=-5, changeHeight=-20)
        self.desc.setWrapping(tk.Wrap.WORD)
        self.desc.onUserInputEvent(self.updateWidgets)

        frame2 = tk.LabelFrame(tools)
        frame2.setText("Options")
        frame2.placeRelative(fixY=175, changeHeight=-50, changeWidth=-5)

        self._disable = tk.Checkbutton(frame2).setText("Disable plugin").placeRelative(fixY=0, fixHeight=25, changeWidth=-5).setTextOrientation().onSelectEvent(self.updateWidgets)
        self._gui = tk.Checkbutton(frame2).setText("Add GUI").placeRelative(fixY=25, fixHeight=25, changeWidth=-5).setTextOrientation().onSelectEvent(self.updateWidgets)

        self.guiFrame = tk.LabelFrame(frame2)
        self.guiFrame.setText("GUI-Options")
        self.guiFrame.placeRelative(fixY=50, changeHeight=-50, changeWidth=-5)

        self._gui_alwTop = tk.Checkbutton(self.guiFrame).setText("Always on top").placeRelative(fixY=0, fixHeight=25,changeWidth=-5).setTextOrientation().onSelectEvent(self.updateWidgets)
        self._gui_onClose = tk.Checkbutton(self.guiFrame).setText("Add onClose").placeRelative(fixY=25, fixHeight=25,changeWidth=-5).setTextOrientation().onSelectEvent(self.updateWidgets)
        self._gui_closeEsc = tk.Checkbutton(self.guiFrame).setText("Close via Escape").placeRelative(fixY=50, fixHeight=25,changeWidth=-5).setTextOrientation().onSelectEvent(self.updateWidgets)

        self.guiFrame.placeForget()


        tk.Button(tools).setText("Create Plugin").placeRelative(changeWidth=-5, changeY=-20, fixHeight=25, stickDown=True).setCommand(self.generate).lift()

        self.updateText()
        self.show()

    def getGUI(self):
        content = self.gui

        if self._gui_alwTop:
            top = str(True)
        else:
            top = str(False)
        if self._gui_onClose:
            close1 = "\n\tself.onCloseEvent(self._onClose)"
            close2 = "\n    def _onClose(self, e):\n\tself.running = False\n\treturn True"
        else:
            close1 = ""
            close2 = ""
        if self._gui_closeEsc:
            closeESC = "\n\tself.closeViaESC()"
        else:
            closeESC = ""


        content = content.replace("{{top}}", top)
        content = content.replace("{{onClose1}}", close1)
        content = content.replace("{{onClose2}}", close2)
        content = content.replace("{{closeESC}}", closeESC)

        return content


    def updateText(self):
        content = self.template

        if self.plugin_data["desc"] == "":
            desc = '""'
        else:
            desc = f'"""{self.plugin_data["desc"]}"""'

        if self.plugin_data["name"] == "":
            name = "PluginTemplate"
        else:
            name = self.plugin_data["name"][0].upper() + self.plugin_data["name"][1:]
        if self._gui:
            gui = self.getGUI()
            self.guiFrame.placeRelative(fixY=50, changeHeight=-50, changeWidth=-5)
            self._imports["tk"] = "from pysettings import tk"
        else:
            gui = ""
            self.guiFrame.placeForget()
            if "tk" in self._imports.keys(): self._imports.pop("tk")
        if not self._disable:
            disa = ""
        else:
            disa = "\nplugin.disable()"





        content = content.replace("{{version}}", f'"{self.plugin_data["version"]}"')
        content = content.replace("{{description}}", desc)
        content = content.replace("{{name}}", name)
        content = content.replace("{{name}}", name)
        content = content.replace("{{gui}}", gui)
        content = content.replace("{{disable}}", disa)
        content = content.replace("{{events}}", "\n".join(self._events.values()))
        content = content.replace("{{imports}}", "\n".join(self._imports.values()))

        self.text.setText(content)



    def updateWidgets(self):
        self.saved = False
        self.plugin_data["desc"] = self.desc.getText()
        self.plugin_data["version"] = self.version.getValue()
        self.plugin_data["name"] = self.name.getValue()

        if len(self.plugin_data["name"]) > 0:
            if not self.plugin_data["name"][-1] in ascii_letters:
                self.plugin_data["name"] = self.plugin_data["name"][:-1]
                self.name.setValue(self.plugin_data["name"])

        self.oldName = self.plugin_data["name"]


        self.updateText()

    def loadTemplate(self, name):
        path = os.path.join(BASE_PATH, "plugins", "templates", name)
        if not os.path.exists(path):
            tk.SimpleDialog.askError(self, f"This template Path does not exist!\n{path}")
            return ""
        file = open(path)
        con = file.read()
        file.close()
        return con

    def checkParameters(self):
        path = os.path.split(PluginManager.PLUGIN_DATA[0].getRealPath())[0]
        name = self.name.getValue()
        if os.path.splitext(name)[1] != "":
            name = os.path.splitext(name)[0]
        if name == "":
            tk.SimpleDialog.askError(self, "Name cannot be Empty!")
            return 


        self.plugin_data["name"] = name
        self.plugin_data["path"] = os.path.join(path, self.plugin_data["name"]+".py")
        self.plugin_data["desc"] = self.desc.getText()



        if os.path.exists(self.plugin_data["path"]):
            if not tk.SimpleDialog.askError(self, f"This plugin name exists already! '{self.plugin_data['name']}'\nDo you want to overwrite it?"):
                return
        

        return True

    def generate(self):
        if self.checkParameters() is None: return
        file = open(self.plugin_data["path"], "w")
        file.write(self.text.getText())
        file.close()

        if tk.SimpleDialog.askYesNo(self, "Plugin successfully created!\nDo you want to load it?"):
            PluginManager._loadPluginFromName(self.plugin_data["name"])







class PluginManagerGUI(tk.Dialog):
    _OPEN = False
    def __init__(self, master):
        PluginManagerGUI._OPEN = True
        super().__init__(master, False)

        self.setWindowSize(600, 450)
        self.setResizeable(False)
        self.setTitle("Plugin Manager GUI")
        self.onCloseEvent(self._onCloseEvent)
        self.bind(self.close, tk.EventType.ESC)
        self.waiting = True
        self.openTextGUIs = []
        self.changedTextGUIs = []

        self.pluginFrame = tk.LabelFrame(self).place(400, 0, 200, 150).setText("Selected Plugin")
        self.l_name = tk.Label(self.pluginFrame).setText("Name: ").place(0, 0, 200, 25).setTextOrientation(tk.Anchor.LEFT)
        self.l_version = tk.Label(self.pluginFrame).setText("Version: ").place(0, 20, 200, 25).setTextOrientation(tk.Anchor.LEFT)
        self.l_prio = tk.Label(self.pluginFrame).setText("Priority: ").place(0, 40, 200, 25).setTextOrientation(tk.Anchor.LEFT)
        self.l_state = tk.Label(self.pluginFrame).setText("State: ").place(0, 60, 200, 25).setTextOrientation(tk.Anchor.LEFT)

        legend = tk.LabelFrame(self).setText("Legend").place(200, 150, 200, 150)

        tk.Label(legend).place(10, 10, 10, 10).setBg("green")
        tk.Label(legend).place(20, 5, 170, 16).setText(" = Running").setTextOrientation(tk.Anchor.LEFT)

        tk.Label(legend).place(10, 10+15, 10, 10).setBg("red")
        tk.Label(legend).place(20, 5+15, 170, 16).setText(" = Stopped (during runtime)").setTextOrientation(tk.Anchor.LEFT)

        tk.Label(legend).place(10, 10+15*2, 10, 10).setBg("gray")
        tk.Label(legend).place(20, 5+15*2, 170, 16).setText(" = Disabled (not started)").setTextOrientation(tk.Anchor.LEFT)

        tk.Label(legend).place(10, 10+15*3, 10, 10).setBg("purple")
        tk.Label(legend).place(20, 5+15*3, 170, 16).setText(" = Error").setTextOrientation(tk.Anchor.LEFT)

        control = tk.LabelFrame(self).setText("Control").place(400, 150, 200, 150)
        self._disable = tk.Button(control).setText("Disable").placeRelative(fixY=0, fixHeight=25, changeWidth=-5).setFg("red").setCommand(self.disenable)
        self._reload = tk.Button(control).setText("Reload").placeRelative(fixY=25, fixHeight=25, changeWidth=-5).setCommand(self.reloadSelected)
        tk.Button(control).setText("Disable all").placeRelative(fixY=50, fixHeight=25, changeWidth=-5).setCommand(self._disableAll)
        tk.Button(control).setText("Enable all").placeRelative(fixY=75, fixHeight=25, changeWidth=-5).setCommand(self._enableAll)
        tk.Button(control).setText("Reload all").placeRelative(fixY=100, fixHeight=25, changeWidth=-5).setCommand(self.reloadAll)

        console = tk.LabelFrame(self).place(0, 300, 400, 150).setText("Console")
        self.console = tk.Text(console, scrollAble=True, readOnly=True).placeRelative(changeWidth=-5, changeHeight=-20).setWrapping(tk.Wrap.NONE)

        desc = tk.LabelFrame(self).setText("Description").place(400, 300, 200, 150)
        self.desc = tk.Text(desc, readOnly=True, scrollAble=True).placeRelative(changeWidth=-5, changeHeight=-20).setBg(tk.Color.DEFAULT).setStyle(tk.Style.FLAT).setWrapping(tk.Wrap.WORD)

        pl_list = tk.LabelFrame(self).setText("Plugin list").place(0, 0, 200, 300)
        self.lis = tk.Listbox(pl_list).placeRelative(changeWidth=-5, changeHeight=-20)
        self.lis.onSelectEvent(self.onListBoxSelect)
        self.lis.bind(self.onListBoxDoubleSelect, tk.EventType.DOUBBLE_LEFT)

        info = tk.LabelFrame(self).place(200, 0, 200, 150).setText("Info")
        self._count = tk.Label(info).setTextOrientation(tk.Anchor.LEFT).place(0, 0, 100, 25)
        self._runs = tk.Label(info).setTextOrientation(tk.Anchor.LEFT).place(0, 20, 100, 25)
        self._sto = tk.Label(info).setTextOrientation(tk.Anchor.LEFT).place(0, 40, 100, 25)
        self._disa = tk.Label(info).setTextOrientation(tk.Anchor.LEFT).place(0, 60, 100, 25)
        self._errs = tk.Label(info).setTextOrientation(tk.Anchor.LEFT).place(0, 60, 100, 25)



        self.indexPlugins()
        th.Thread(target=self._waitForEditorClose).start()
        self.show()
    def indexPlugins(self, sel=None):
        disa = 0
        active = 0
        inactive = 0
        err = 0

        self.lis.clear()
        for i, data in enumerate(PluginManager.PLUGIN_DATA):
            color = "green" if data["state"] == "active" else "red"
            color = "gray" if data["state"] == "disabled" else color
            color = "purple" if data["state"] == "error" else color
            if color == "green":
                active += 1
            elif color == "red":
                inactive += 1
            elif color == "gray":
                disa += 1
            elif color == "purple":
                err += 1

            self.lis.add(data["name"], color=color)
        if sel is not None: self.lis.setItemSelectedByName(sel)

        self._count.setText(f"Plugin count: {len(PluginManager.PLUGIN_DATA)}")
        self._runs.setText(f"Plugins running: {active}")
        self._sto.setText(f"Plugins stopped: {inactive}")
        self._disa.setText(f"Plugins disabled: {disa}")
        self._errs.setText(f"Errors: {err}")
    def onListBoxSelect(self, e):
        if isinstance(e, tk.Event):
            e = tk.Event(e)
            sel = self.lis.getSelectedItem()
            if sel is not None:
                data = PluginManager.PLUGIN_DATA_DICT[sel]
            else: return
        else: data = e

        self.l_name.setText("Name: "+data["name"])
        self.l_version.setText("Version: "+str(data["version"]))
        self.l_prio.setText("Priority: "+str(data["priority"]))

        self._disable.setEnabled()
        self._reload.setEnabled()
        if data["state"] == "active":
            self._disable.setText("Disable").setFg("red")
            color = "green"
            state = "running"
        elif data["state"] == "inactive":
            self._disable.setText("Enable").setFg("green")
            color = "red"
            state = "stopped"
        elif data["state"] == "disabled":
            self._disable.setText("Plugin Disabled in File!").setFg("black")
            self._disable.setDisabled()
            self._reload.setDisabled()
            color = "gray"
            state = "disabled"
        elif data["state"] == "error":
            self._disable.setText("Error! Reload to activate!").setFg("black")
            self._disable.setDisabled()
            color = "purple"
            state = "error"
        else:
            raise Exception("Unknown state: "+str(data["state"]))

        self.l_state.setText("State: "+state).setBg(color)
        self.desc.clear()
        self.desc.addText(str(data["description"]))

        self.console.clear()
        self.console.addText(str(data["console"]))
    def _waitForEditorClose(self):
        while True:
            t.sleep(.1)
            for text in self.openTextGUIs:
                if not text.saved and text not in self.changedTextGUIs:
                    self.changedTextGUIs.append(text)
                if text.closed:
                    if text in self.changedTextGUIs:
                        pluginName = os.path.splitext(os.path.split(text.currPath)[1])[0]
                        if tk.SimpleDialog.askOkayCancel(self, f"Plugin '{pluginName}' changed. Do you want to reload the plugin?"):
                            data = self.reload(PluginManager.PLUGIN_DATA_DICT[pluginName])
                            self.onListBoxSelect(data)
                            self.indexPlugins()
                            if data["state"] == "active": tk.SimpleDialog.askInfo(PluginManager.WINDOW,f"Plugins reloaded successfully!\n-{data['name']}")
                            self.lift()
                        self.changedTextGUIs.remove(text)
                    self.openTextGUIs.remove(text)
    def onListBoxDoubleSelect(self, e):
        sel = self.lis.getSelectedItem()
        if sel is not None:
            data = PluginManager.PLUGIN_DATA_DICT[sel]
            if "textEditorPlugin" in PluginManager.PLUGIN_DATA_DICT.keys():
                dataText = PluginManager.PLUGIN_DATA_DICT["textEditorPlugin"]
                if dataText["state"] == "active":
                    _gui = dataText["plugin"]._getPluginClass().openGUI(data.getRealPath())
                    self.waiting = True
                    self.openTextGUIs.append(_gui)
                else:
                    tk.SimpleDialog.askError(self, f"Plugin 'textEditorPlugin' has state {dataText['state']} \nenable is first to view other plugin's code!")
            else:
                tk.SimpleDialog.askError(self, f"Plugin 'textEditorPlugin' is not installed!\ You cannot view the plugin's code!")
    def disenable(self):
        sel = self.lis.getSelectedItem()
        if sel is not None:
            data = PluginManager.PLUGIN_DATA_DICT[sel]
            if data["state"] == "active":
                self.disablePlugin(data)
                self.indexPlugins()

            elif data["state"] == "inactive":
                self.enablePlugin(data)
                self.indexPlugins()

            self.lis.setItemSelectedByName(data["name"])
            self.onListBoxSelect(data)
    def _disableAll(self):
        PluginManagerGUI.disableAll()
        self.indexPlugins()
    @staticmethod
    def disableAll():
        disab = []
        cdisab = []
        for data in PluginManager.PLUGIN_DATA:
            if data["state"] == "active":
                disab.append(data)
            else:
                cdisab.append(data)
        out = tk.SimpleDialog.askOkayCancel(PluginManager.WINDOW, "Plugins to disable:\n -"+"\n -".join([i['name'] for i in disab])+"\nPlugins cant be disabled:\n -"+"\n -".join([i['name']+f"({i['state']})" for i in cdisab]))
        if not out: return
        for i in disab:
            PluginManagerGUI.disablePlugin(i)
    def _enableAll(self):
        PluginManagerGUI.enableAll()
        self.indexPlugins()
    @staticmethod
    def enableAll():
        disab = []
        cdisab = []
        for data in PluginManager.PLUGIN_DATA:
            if data["state"] == "inactive":
                disab.append(data)
            else:
                cdisab.append(data)
        out = tk.SimpleDialog.askOkayCancel(PluginManager.WINDOW, "Plugins to enable:\n -" + "\n -".join([i['name'] for i in disab]) + "\nPlugins cant be enabled:\n -" + "\n -".join([i['name'] + f"({i['state']})" for i in cdisab]))
        if not out: return
        for i in disab:
            PluginManagerGUI.enablePlugin(i)
    def reloadAll(self):
        pass
    def reloadSelected(self):
        sel = self.lis.getSelectedItem()
        if sel is not None:
            print(sel)
            data = PluginManager.PLUGIN_DATA_DICT[sel]
            self._reload.setText("Reloading...").setDisabled()
            print(data.data)
            data = self.reload(data)
            self._reload.setText("Reload").setEnabled()
            self.onListBoxSelect(data)
            self.indexPlugins()
            print(data.data)
            if data["state"] == "active": tk.SimpleDialog.askInfo(PluginManager.WINDOW, f"Plugins reloaded successfully!\n-{data['name']}")
            self.lift()
    @staticmethod
    def disablePlugin(data):
        data["state"] = "inactive"
    @staticmethod
    def enablePlugin(data):
        data["state"] = "active"
    def reload(self, data):
        def onErr():
            exc = format_exc()
            tk.SimpleDialog.askError(PluginManager.WINDOW, exc, "Plugin-Loader-Exception")
            TextColor.printStrf("§r" + exc)
            TextColor.printStrf("§ERRORCould not execute Plugin! (§c" + data["name"] + "§r)")
            data["console"] += "\n====================================\n" + exc
            self.console.setText(data["console"])
        if data["module"] is None:
            try:
                module = import_module(data["path"])
            except:
                onErr()
                return
        else:
            try:
                module = reload(data["module"])
            except:
                onErr()
                return
        pluginName = data["name"]

        instance = module.Plugin._INSTANCE
        #PluginManager.PLUGIN_DATA.remove(data)

        data.data = {
            "name":pluginName,  # name of the Plugin
            "version":module.VERSION if hasattr(module, "VERSION") else None,
            "description":module.DESCRIPTION if hasattr(module, "DESCRIPTION") else "Has no Description!",
            "path":"PyExplorer.src.plugins." + pluginName,
            "module":module,  # module instance from import
            "plugin":instance,  # plugin instance from class:
            "priority":instance.priority,
            "state":"disabled" if instance._disabled else "active",  # active, inactive, disabled, error
            "console":"",
        }
        instance._pluginName = pluginName
        instance._getStateHook = PluginManager._getState
        instance._window = PluginManager.WINDOW
        #data = PluginManager.PLUGIN_DATA[-1]
        PluginManager.PLUGIN_DATA_DICT[data["name"]] = data
        if data["state"] == "active":
            instance._run()
        nameLen = len(module.__name__)
        state = data["state"]
        if state == "active":
            instance._run()  # run the Plugin
            TextColor.printStrf("§INFO   -Plugin successfully reloaded!   (§c" + module.__name__ + "§g)" + "-" * (50 - nameLen + 2) + "§g-> §gENABLED")
        elif state == "disabled":
            TextColor.printStrf("§INFO   -Plugin successfully reloaded!   (§c" + module.__name__ + "§g)" + "-" * (50 - nameLen + 2) + "§g-> §rDISABLED")
        else:
            TextColor.printStrf("§INFO   -Plugin successfully reloaded!   (§c" + module.__name__ + "§g)" + "-" * (50 - nameLen))
        return data
    def close(self):
        self._onCloseEvent()
        self.destroy()
    def _onCloseEvent(self, e=""):
        self.waiting = False
        t.sleep(.2)
        PluginManagerGUI._OPEN = False
class PluginData:
    def __init__(self, name, version, desc, path, module, plugin, priority, state="active", console=""):
        self.data = {
        "name":name,       # name of the Plugin
        "version":version,
        "description":desc,
        "path":path,
        "module":module,   # module instance from import
        "plugin":plugin,   # plugin instance from class: 
        "priority":priority,
        "state":state,  # active, inactive, disabled, error
        "console":console,
    }
    def __getitem__(self, key):
        return self.data[key]
    def __setitem__(self, key, value):
        self.data[key] = value
    def __lt__(self, other):
        return self["priority"] < other["priority"]
    def getRealPath(self):
        return os.path.join(os.path.split(os.path.split(BASE_PATH)[0])[0], *self["path"].split("."))+".py"
class PluginManager:
    PLUGIN_DATA:[PluginData] = [] # in correct priority order!
    PLUGIN_DATA_DICT = {}         # to fast access from name
    WINDOW = None
    @staticmethod
    def _getState(name):
        return PluginManager.PLUGIN_DATA_DICT[name]["state"]
    @staticmethod
    def _registerBind(pluginName, name, bind, force=False):
        if pluginName in Config.KEY_BIND_CONFIG.keys():
            if not name in Config.KEY_BIND_CONFIG[pluginName].keys() or force:
                Config.KEY_BIND_CONFIG[pluginName][name] = {"bind":bind, "text":parseTkEvent(bind)}
        else:
            Config.KEY_BIND_CONFIG[pluginName] = {name:{"bind":bind, "text":parseTkEvent(bind)}}
        Config.KEY_BIND_CONFIG.save()
    @staticmethod
    def _getBind(pluginName, name):
        if pluginName in Config.KEY_BIND_CONFIG.keys():
            if name in Config.KEY_BIND_CONFIG[pluginName].keys():
                return Config.KEY_BIND_CONFIG[pluginName][name]
            else:
                return Exception("Register the Keybind first! Before you register the plugin! (event does not exist)")
        else:
            return Exception("Register the Keybind first! Before you register the plugin! (pluginName does not exist)")
    @staticmethod
    def openGUI(e=""):
        if not PluginManagerGUI._OPEN:
            gui = PluginManagerGUI(PluginManager.WINDOW)
    @staticmethod
    def openGeneratorGUI():
        gui = PluginGeneratorGUI(PluginManager.WINDOW)
    @staticmethod
    def call(eventName, **kwargs):
        """

        @param eventName:
        @param kwargs:
        @return: False -> no cancel, True one or more cancels!
        """
        canc = []
        event = None
        for data in PluginManager.PLUGIN_DATA:
            if event is not None and event["cancelOther"]: break
            if not data["state"] == "active": continue
            try:
                event = data["plugin"]._call(eventName, **kwargs)
            except Exception as e:
                exc = format_exc()
                data["console"] += "\n"+exc
                tk.SimpleDialog.askError(PluginManager.WINDOW, f"An error occurred while executing event '<{eventName}>' in Plugin '{data['name']}'.\nCheck the console in the PluginManager for more information.", "PluginManager GUI")
                TextColor.print(exc, "red")
                data["state"] = "error"
            if event is not None: canc.append(event["setCanceled"])
        return any(canc)
    @staticmethod
    def _getPlugins(path):
        for pluginName in os.listdir(path):
            if os.path.splitext(pluginName)[1] != ".py": continue
            pluginName = pluginName.replace(".py", "")
            if pluginName.startswith("__"): continue
            yield pluginName
    @staticmethod
    def _loadPluginFromName(pluginName):
        try:
            module = import_module("PyExplorer.src.plugins." + pluginName)
            if hasattr(module, "Plugin") and module.Plugin._INSTANCE is not None:

                instance = module.Plugin._INSTANCE
                pl_data = PluginData(
                    name=pluginName,
                    version=module.VERSION if hasattr(module, "VERSION") else None,
                    desc=module.DESCRIPTION if hasattr(module, "DESCRIPTION") else "Has no Description!",
                    path="PyExplorer.src.plugins." + pluginName,
                    module=module,
                    plugin=instance,
                    priority=instance.priority,
                    state="disabled" if instance._disabled else "active",
                )
                PluginManager.PLUGIN_DATA.append(pl_data)
                PluginManager.PLUGIN_DATA_DICT[pluginName] = pl_data
                instance._pluginName = pluginName
                instance._getStateHook = PluginManager._getState
                instance._window = PluginManager.WINDOW
                #t.sleep(0.2)
                state = PluginManager.PLUGIN_DATA[-1]["state"]
                nameLen = len(module.__name__)
                if state == "active":
                    instance._run()  # run the Plugin
                    TextColor.printStrf(
                        "§INFO   -Plugin successfully registered! (§c" + module.__name__ + "§g)" + "-" * (
                                    50 - nameLen + 2) + "§g-> §gENABLED")
                elif state == "disabled":
                    TextColor.printStrf(
                        "§INFO   -Plugin successfully registered! (§c" + module.__name__ + "§g)" + "-" * (
                                    50 - nameLen + 2) + "§g-> §rDISABLED")
                else:
                    TextColor.printStrf(
                        "§INFO   -Plugin successfully registered! (§c" + module.__name__ + "§g)" + "-" * (50 - nameLen))
            else:
                pl_data = PluginData(
                    name=pluginName,
                    version=None,
                    desc="",
                    path="PyExplorer.src.plugins." + pluginName,
                    module=None,
                    plugin=None,
                    priority=1000,
                    state="error",
                    console="Could not register Plugin: Plugin class not available!"
                )
                PluginManager.PLUGIN_DATA.append(pl_data)
                PluginManager.PLUGIN_DATA_DICT[pluginName] = pl_data
                TextColor.printStrf(
                    "§ERROR§rCould not register Plugin: Plugin class not available! (§c" + module.__name__ + "§r)")

        except Exception as e:
            exc = format_exc()
            pl_data = PluginData(
                name=pluginName,
                version=None,
                desc="",
                path="PyExplorer.src.plugins." + pluginName,
                module=None,
                plugin=None,
                priority=1000,
                state="error",
                console=str(exc)
            )
            PluginManager.PLUGIN_DATA.append(pl_data)
            PluginManager.PLUGIN_DATA_DICT[pluginName] = pl_data
            tk.SimpleDialog.askError(PluginManager.WINDOW, exc, "Plugin-Loader-Exception")
            TextColor.printStrf("§r" + exc)
            TextColor.printStrf("§ERRORCould not execute Plugin! (§c" + pluginName + "§r)")




    @staticmethod
    def loadPlugins(loadingFrame):
        pluginNames = [i for i in PluginManager._getPlugins(os.path.join(BASE_PATH, "plugins"))]
        """
        master = tk.Dialog(window)
        master.setTopmost(True)
        master.setTitle("Plugin loader")
        master.setCloseable(False)
        master.setWindowSize(350, 100)
        """
        pg = tk.Progressbar(loadingFrame)
        pg.placeRelative(fixHeight=30, changeX=+150, changeWidth=-300, stickDown=True, changeY=-75)
        lb = tk.Label(loadingFrame).setText(f"Loading Plugins... (0/{len(pluginNames)}) 0%").setBg("white").setFont(15)
        lb.placeRelative(fixHeight=25, changeX=+100, changeWidth=-200, stickDown=True, changeY=-175)
        lb2 = tk.Label(loadingFrame).setText("-textEditorPlugin").setBg("white").setFont(15)
        lb2.placeRelative(fixHeight=25, changeX=+100, changeWidth=-200, stickDown=True, changeY=-125)
        MsgText.info(f"Loading plugins... ({len(pluginNames)})")
        for i, pluginName in enumerate(pluginNames):
            PluginManager._loadPluginFromName(pluginName)
            lb.setText(f"Loading Plugins... ({i}/{len(pluginNames)}) {round(((i) / len(pluginNames)) * 100, 1)}%")
            lb2.setText(f"Plugin: {pluginName}")
            pg.setPercentage((i / len(pluginNames)) * 100)
            PluginManager.WINDOW.update()
        pg.setPercentage(100)
        lb.setText(f"Finishing up... 100%")
        lb2.setText("Building GUI...")
        #t.sleep(.5)


        PluginManager.PLUGIN_DATA.sort()
        PluginManager.PLUGIN_DATA.reverse()
