import tkinter as _tk_
import os, time as t
from shutil import copyfile
from pysettings import tk
from pysettings.text import MsgText
from send2trash import send2trash
from typing import Union
from pyperclip import copy as copyToClip


from PyExplorer.src.package.misc import parseTimeFromSec, parseSize, parseNumber
from PyExplorer.src.package.pathTools import FileIndexer, getCaptionFromPath, History as TreeHistory
#from PyExplorer.src.package.system import Memory
from PyExplorer.src.images import IconHandler

class PathCompleterEntry(tk.Entry):
    def __init__(self, _master):
        if isinstance(_master, dict):
            self.data = _master
        elif isinstance(_master, tk.Tk) or isinstance(_master, tk.Frame) or isinstance(_master, tk.LabelFrame) or isinstance(_master, tk.NotebookTab):
            data = {"master":_master, "widget":_tk_.Entry(_master._get())}
            super().__init__(_master)
            self._addData(data)
            self.selected = -1 # selected index during the lb is open
            self._listBox = tk.Listbox(_master)
            self._listBox.setBg(tk.Color.rgb(240, 240, 240))
            self.bind(self._onRelPlace, tk.EventType.CUSTOM_RELATIVE_UPDATE)
            self.bind(self._up, "<Up>")
            self.bind(self._down, "<Down>")
            self.bind(self._escape, "<Escape>")
            self._listBox.bind(self._escape, "<Escape>")
            self.isListboxOpen = False
            self._scroll = tk.ScrollBar(_master)
            self._listBox.attachVerticalScrollBar(self._scroll)

            self._rect = None
        else:
            raise tk.TKExceptions.InvalidWidgetTypeException("_master must be " + str(self.__class__.__name__) + ", Frame or Tk instance not: " + str(_master.__class__.__name__))
    def _up(self, e):
        if self.isListboxOpen:
            selected = self._listBox.getSelectedIndex()
            if selected is None or selected == 0:
                selected = -1
                self._listBox.clearSelection()
                #self._listBox.setItemSelectedByIndex(0)
            else:
                if selected > 0:
                    selected -= 1
                    self._listBox.setItemSelectedByIndex(selected)


            self._listBox.see(selected)
            self.selected = selected
    def _down(self, e):
        if self.isListboxOpen:
            selected = self._listBox.getSelectedIndex()
            if selected is None:
                selected = 0
                self._listBox.setItemSelectedByIndex(0)
            else:
                if selected < self._listBox.length():
                    selected += 1
                    self._listBox.setItemSelectedByIndex(selected)

            self._listBox.see(selected)
            self.selected = selected
    def _escape(self, e):
        self.closeListbox()
    def _updateMenu(self, e, out):
        if out is None or self._rect is None or out == [] or e.getTkArgs().keysym == "Escape" or (e.getTkArgs().keysym == "Return" and self.selected == -1):
            self.isListboxOpen = False
            self._listBox.placeForget()
            self._scroll.placeForget()
            return
        if not self.isListboxOpen:
            rect = tk.Rect.fromLocWidthHeight(tk.Location2D(self._rect.loc1.clone()), self._rect.getWidth()-20, self._rect.getHeight())
            rect2 = tk.Rect.fromLocWidthHeight(tk.Location2D(self._rect.loc1.clone()).change(x=+self._rect.getWidth()-20), 20, self._rect.getHeight())
            self._listBox.place(rect)
            self._scroll.place(rect2)
        self.isListboxOpen = True
        selected = -1
        if self._listBox.length() == len(out) and self._listBox.getSelectedIndex() is not None:
            selected = self.selected
        self._listBox.clear()
        self._listBox.addAll(out, color=tk.Color.rgb(240, 240, 240))
        if selected == -1: return
        self._listBox.setItemSelectedByIndex(selected)
        self._listBox.see(selected)
    def _onListboxSelect(self, e):
        if e.type == "35" or e.keysym == "Escape": #virtual event triggered by shift-Left? without no marking
            self.selected = self._listBox.getSelectedIndex()
            return self.getValue()
        entry = self.getValue()
        if self.selected == -1:
            self.closeListbox()
            return self.getValue()
        selected = self._listBox.getSelectedItem()
        _path, raw = os.path.split(entry)
        if selected is None:
            path = _path
        else:
            path = os.path.join(_path, selected)
        if entry != path:
            self.setValue(path)
        self.closeListbox()
        return self.getValue()
    def closeListbox(self):
        self.isListboxOpen = False
        self._listBox.placeForget()
    def _decryptEvent(self, args):
        return args
    def onUserInputEvent(self, func, args:list=None, priority:int=0, defaultArgs=False, disableArgs=False):
        event = tk.EventHandler._registerNewEvent(self, func, tk.EventType.KEY_UP, args, priority, decryptValueFunc=self._decryptEvent, defaultArgs=defaultArgs, disableArgs=disableArgs)
        event["afterTriggered"] = self._updateMenu
    """def onListBoxSelectEvent(self, func, args: list = None, priority: int = 0, defaultArgs=False, disableArgs=False):
        self._listboxSelect = tk.EventHandler._registerNewEvent(self._listBox, func, tk.EventType.LISTBOX_SELECT, args, priority, defaultArgs=defaultArgs, disableArgs=disableArgs, decryptValueFunc=self.__decryptEvent)"""
    def onSelectEvent(self, func, args: list = None, priority: int = 0, defaultArgs=False, disableArgs=False):
        tk.EventHandler._registerNewEvent(self._listBox, func, tk.EventType.LISTBOX_SELECT, args, priority, decryptValueFunc=self._onListboxSelect, defaultArgs=defaultArgs, disableArgs=disableArgs)
        tk.EventHandler._registerNewEvent(self._listBox, func, tk.EventType.DOUBBLE_LEFT, args, priority, decryptValueFunc=self._onListboxSelect, defaultArgs=defaultArgs, disableArgs=disableArgs)
        tk.EventHandler._registerNewEvent(self, func, tk.EventType.RETURN, args, priority, decryptValueFunc=self._onListboxSelect, defaultArgs=defaultArgs, disableArgs=disableArgs)
    def __decryptEvent(self, args):
        try:
            w = args.widget
            if self._listBox["selectionMode"] == tk.Listbox.SINGLE:
                return w.get(int(w.curselection()[0]))
            else:
                return [w.get(int(i)) for i in w.curselection()]
        except IndexError:
            pass
    def _onRelPlace(self, e):
        if e.getValue() is None: return

        x, y, width, height = e.getValue()
        self._rect = tk.Rect.fromLocWidthHeight(tk.Location2D(x, y + height), width, 200)
    def place(self, x=None, y=None, width=None, height=None, anchor:tk.Anchor=tk.Anchor.UP_LEFT):
        assert not self["destroyed"], "The widget has been destroyed and can no longer be placed."
        if x is None: x = 0
        if y is None: y = 0
        if hasattr(anchor, "value"):
            anchor = anchor.value
        if isinstance(x, tk.Location2D):
            x, y = x.get()
        if isinstance(x, tk.Rect):
            width = x.getWidth()
            height = x.getHeight()
            x, y, = x.getLoc1().get()
        x = int(round(x, 0))
        y = int(round(y, 0))
        self.placeForget()
        self._rect = tk.Rect.fromLocWidthHeight(tk.Location2D(x, y + height), width, 180)
        self["widget"].place(x=x, y=y, width=width, height=height, anchor=anchor)
        self["alive"] = True
        return self
class CopyWindow(tk.Dialog):
    #get all active copy's sizes and check if this fits too
    def __init__(self, _master, from_, to_, copySys=True, copyHidden=True):
        if to_ == "trash": raise()
        super().__init__(_master, False)
        self.__master = _master
        self.onCloseEvent(self._onClose)
        self.isIndexingFinished = False
        self.running = True
        self._copySys = copySys
        self._copyHidden = copyHidden
        self.from_ = from_
        self.to_ = to_
    def open(self):
        self._indexerFrom = FileIndexer(self.from_, self._copyHidden, self._copyHidden)
        #self._indexerTo = FileIndexer(to_)

        self._createGUI()
        self.show()
        #self._indexerTo.start()
        self._indexerFrom.start()
        self._waitForIndex()
        if not self.running: return
        if self.to_ != "trash":
            if not self._checkTarget():
                #TODO TOO LARGE FOR DRIVE
                self.isIndexingFinished = True
                self.running = False
                t.sleep(.1)
                self.destroy()
            else:
                self._prog.setNormalMode()
                self.existingFiles, self.existingSize = self._startCopy()
                self.running=False
                if not self.existingFiles: #empty
                    t.sleep(0.5)
                    self.destroy()
                else:
                    self._changeGUI()
        else:
            #trash
            self._prog.setNormalMode()
            self._startCopy()
            t.sleep(0.5)
            self.destroy()
    def _checkFile(self, path):
        fileName = os.path.split(path)[1]
        ext = os.path.splitext(fileName)[1]
        if not self._copySys:
            if ext in [".ini", ".sys"] or fileName.startswith("$"):
                return False
            if fileName == "bootmgr":
                return False
        if not self._copyHidden:
            if fileName.startswith("."):
                return False
        return True
    def _createGUI(self):
        # isinstance(from_, list) or
        _curr = t.time()

        self.setTitle("indexing...")
        # self._master.setCloseable(False)
        self.setResizeable(False)
        self.setWindowSize(400, 200)
        self.centerWindowOnScreen()

        self._infoLabel = tk.Text(self, readOnly=True)
        self._infoLabel.setBg(tk.Color.DEFAULT)
        self._infoLabel.setStyle(tk.Style.FLAT)
        #self._infoLabel.addStrf("Copying ... items from §b" + os.path.split(self.from_)[1] + "§B to §b" + os.path.split(self.to_)[1])
        self._infoLabel.setDisabled()
        self._infoLabel.place(10, 0, width=600, height=25)

        self.complete = tk.Label(self).setText("").setFont(15).place(80, 35)
        self._progLabel = tk.Label(self)
        self._progLabel.setText("indexing...")
        self._progLabel.setFont(15)
        self._progLabel.place(20, 35)

        self._prog = tk.Progressbar(self)
        self._prog.setAutomaticMode()
        self._prog.place(20, 80, width=360)

        tk.Label(self).setText("Current File: ").setTextOrientation().place(20, 110)
        self._currFile = tk.Label(self)
        self._currFile.setText("None")
        self._currFile.place(120, 110)

        tk.Label(self).setText("Time remaining:").setTextOrientation().place(20, 130)
        self._timeRem = tk.Label(self)
        self._timeRem.setText("Calculating...")
        self._timeRem.place(120, 130)

        tk.Label(self).setText("Items remaining:").setTextOrientation().place(20, 150)
        self._iteRem = tk.Label(self)
        self._iteRem.setTextOrientation()
        self._iteRem.setText("Calculating...")
        self._iteRem.place(120, 150)

        _cancel = tk.Button(self)
        _cancel.setText("Cancel")
        _cancel.setFg("red")
        _cancel.setCommand(self.close)
        _cancel.place(340, 102, width=40)
    def _changeGUI(self):
        self.setWindowSize(400, 250)
        tk.Label(self).setText(f"There are {len(self.existingFiles)} files with the same name!").setTextOrientation().place(20, 170).setFont(10, bold=True)

        self.rep = tk.Button(self).setText("Replace Files").place(20, 195, width=360).setCommand(self._replaceFiles)

        self.ign = tk.Button(self).setText("Ignore").place(20, 220, width=360).setCommand(self.destroy)
    def _waitForIndex(self):
        while self.running:
            self.update()
            if self._indexerFrom.getFinished(): #self._indexerTo.getFinished() and
                self.setTitle("0% complete")
                self.complete.setText("complete")
                self._progLabel.setText("0%")
                self.isIndexingFinished = True
                break
    def _checkTarget(self):
        return True
        to = Memory.getMemFromCaption(getCaptionFromPath(self.to_)).getFreeDiskSpace(parse=False)
        from_ = self._indexerFrom.getSize()
        res = to > from_
        if not res: tk.SimpleDialog.askError(self, f"The files are too large to copy! ({parseSize(to)} < {parseSize(from_)})")
        return res
    def _walk(self, p):
        if isinstance(p, list): #list of Files and/or Folders
            for i in p:
                self.thisDir = ""
                if os.path.isdir(i):
                    yield [i, os.path.split(i)[0], [os.path.split(i)[1]], []]
                    for f in os.walk(i):
                        self.thisDir = os.path.split(i)[1]  # file or target folder
                        if not os.path.exists(os.path.join(self.to_, self.thisDir)) and self.to_ != "trash":
                            if os.path.isdir(os.path.join(self.to_, self.thisDir)):
                                os.mkdir(os.path.join(self.to_, self.thisDir))
                        yield (i,) + f
                else:
                    yield [i, os.path.split(i)[0], [], [os.path.split(i)[1]]]
        elif os.path.isdir(p): #Folder
            for i in os.walk(p):
                yield (self.from_,) + i
        else:
            yield [self.from_, os.path.split(p)[0], [], [os.path.split(p)[1]]] #oneFile
    def _startCopy(self):
        self.thisDir = ""
        if not isinstance(self.from_, list) and os.path.isdir(self.from_): #check could be an error: self.thisDir == "" if not isdir()
            self.thisDir = os.path.split(self.from_)[1] # file or target folder
            #print(os.path.join(self.to_, self.thisDir))
            if not os.path.exists(os.path.join(self.to_, self.thisDir)):
                os.mkdir(os.path.join(self.to_, self.thisDir))

        _files_to = 0
        _size_to = 0
        _size_exis = 0
        _finishedCalcOK = False
        _existingFiles = []

        _timer = t.time()
        _oldBytes = 0
        for from_, dirpath, dirnames, filenames in self._walk(self.from_):
            #print("FOR:", (from_, dirpath, dirnames, filenames))
            if os.path.isdir(from_):
                newPath = dirpath[len(from_):] # Path after target folder
                #print(newPath)
            else:
                newPath = ""

            if newPath.startswith("\\"):
                newPath = newPath[1:]
            if t.time() - _timer >= 1:
                bytesInOneSec = _size_to - _oldBytes
                secs = (self._indexerFrom.getSize() - _size_to) / bytesInOneSec
                self._timeRem.setText(f"{parseTimeFromSec(int(round(secs, 0)))}")
                _oldBytes = _size_to
                _timer = t.time()

            for folder in dirnames:
                if not self.running: return "", ""
                if not self._checkFile(os.path.join(self.to_, self.thisDir, newPath, folder)): continue
                if not os.path.exists(os.path.join(self.to_, self.thisDir, newPath, folder)) and self.to_ != "trash":
                    os.mkdir(os.path.join(self.to_, self.thisDir, newPath, folder))
                self.updateIdleTasks()
            for file in filenames:
                if not self.running: return "", ""
                if not self._checkFile(os.path.join(self.to_, self.thisDir, newPath, file)): continue
                size = os.path.getsize(os.path.join(dirpath, file))
                _size_to += size
                _files_to += 1
                if not _finishedCalcOK:
                    #self._infoLabel.clear()
                    #self._infoLabel.addStrf(f"Copying {self._indexerFrom.getFiles()} items from §b" + os.path.split(from_)[1] + "§B to §b" + os.path.split(self.to_)[1])
                    _finishedCalcOK = True
                if self._indexerFrom.getSize() > 0:
                    per = f"{int(round((_size_to / self._indexerFrom.getSize()) * 100, 0))}%"
                    self._progLabel.setText(per)
                    self.setTitle(per)
                    self._prog.setPercentage((_size_to / self._indexerFrom.getSize()) * 100)

                if _files_to % 10 == 0:
                    self._currFile.setText(file)
                    self._iteRem.setText(parseNumber(self._indexerFrom.getFiles() - _files_to))
                #t.sleep(0.2)
                if not os.path.exists(os.path.join(self.to_, self.thisDir, newPath, file)):
                    #print(os.path.join(dirpath, file), os.path.join(self.to_, self.thisDir, newPath, file))
                    if self.to_ != "trash":
                        try:
                            copyfile(os.path.join(dirpath, file), os.path.join(self.to_, self.thisDir, newPath, file))
                        except FileNotFoundError:
                            MsgText.error(f"FileNotFoundError: {os.path.join(dirpath, file), os.path.join(self.to_, self.thisDir, newPath, file)}")
                        except PermissionError:
                            MsgText.error(f"PermissionError: {os.path.join(dirpath, file), os.path.join(self.to_, self.thisDir, newPath, file)}")
                    else: send2trash(os.path.join(dirpath, file))
                else:
                    #print("DOUBLE", (os.path.join(dirpath, file), os.path.join(self.to_, self.thisDir, newPath, file)))
                    _existingFiles.append((os.path.join(dirpath, file), os.path.join(self.to_, self.thisDir, newPath, file)))
                    _size_exis += size

                self.update()
        self._iteRem.setText("0")
        self._timeRem.setText("0 sek")
        self._currFile.setText("")
        self.setTitle("100%")
        self._progLabel.setText("100%")
        self._prog.setPercentage(100)
        self.update()
        return _existingFiles, _size_exis
    def _replaceFiles(self):
        self.running = True
        self.ign.setDisabled()
        self.rep.setDisabled()
        self._progLabel.setText("0%")
        self._prog.setPercentage(0)
        if isinstance(self.from_, list):
            _paths = self.from_
        else:
            _paths = [self.from_]
        for paths in _paths:
            if not self.running: return
            if not os.path.isdir(paths):
                self.update()
                try:
                    os.remove(os.path.join(self.to_, os.path.split(paths)[1]))
                    copyfile(paths, os.path.join(self.to_, os.path.split(paths)[1]))
                except FileNotFoundError:
                    MsgText.error(f"FileNotFoundError: {os.path.split(paths)[1]}")
                except PermissionError:
                    MsgText.error(f"PermissionError: {os.path.split(paths)[1]}")

                self._iteRem.setText("0")
                self._timeRem.setText("0 sek")
                self._currFile.setText("")
                self._progLabel.setText("100%")
                self._prog.setPercentage(100)

                self.sleep(0.2)
                self.destroy()
                return

            self._iteRem.setText(len(self.existingFiles))
            __timer = t.time()
            __oldBytes = 0

            __files_to = 0
            __size_to = 0
            for __from, __to in self.existingFiles:
                if not self.running: return
                self.update()

                if t.time() - __timer >= 1:
                    __bytesInOneSec = __size_to - __oldBytes
                    __secs = (self.existingSize - __size_to) / __bytesInOneSec
                    self._timeRem.setText(f"{parseTimeFromSec(int(round(__secs, 0)))}")
                    __oldBytes = __size_to
                    __timer = t.time()

                __size_to += os.path.getsize(__from)
                __files_to += 1
                self._progLabel.setText(f"{int(round((__size_to / self.existingSize) * 100, 0))}%")
                self._prog.setPercentage((__size_to / self.existingSize) * 100)

                if __files_to % 10 == 0:
                    self._currFile.setText(__from)
                    self._iteRem.setText(self._indexerFrom.getFiles() - __files_to)
                try:
                    os.remove(__to)
                    copyfile(__from, __to)
                except FileNotFoundError:
                    MsgText.error(f"FileNotFoundError: {__to}")
                except PermissionError:
                    MsgText.error(f"PermissionError: {__to}")
    def close(self):
        if self._onClose(tk.Event()): self.destroy()
    def _onClose(self, e):
        if not self.running: return
        if tk.SimpleDialog.askOkayCancel(self, "Do you really want to cancel?"):
            self.isIndexingFinished = True
            self.running = False
            t.sleep(.1)


            return True
        else:
            e.setCanceled(True)
            return False
class AskKey(tk.Dialog):
    def __init__(self, _master, key=None):
        super().__init__(_master, False)
        self._master = _master
        self.setWindowSize(300, 200)
        self.setTitle("Ask Key Prompt")
        self.setResizeable(False)
        self.setCloseable(False)
        self._isListen = False

        self.isKey_ALT = False
        self.isKey_STRG = False
        self.isKey_SHIFT = False

        self._output = None
        self._exit = False

        self.bind(self._onAll, tk.EventType.ALL_KEYS)
        self.bind(self.onKey, tk.EventType.STRG_LEFT_UP, args=["isKey_STRG", False])
        self.bind(self.onKey, tk.EventType.STRG_LEFT_DOWN, args=["isKey_STRG", True])
        self.bind(self.onKey, tk.EventType.ALT_LEFT_UP, args=["isKey_ALT", False])
        self.bind(self.onKey, tk.EventType.ALT_LEFT_DOWN, args=["isKey_ALT", True])
        self.bind(self.onKey, tk.EventType.SHIFT_LEFT_UP, args=["isKey_SHIFT", False])
        self.bind(self.onKey, tk.EventType.SHIFT_LEFT_DOWN, args=["isKey_SHIFT", True])

        self._keyLabel = tk.Label(self).setBorderWidth(1).place(5, 5, 290, 30).setFont(12).setText("<None>").applyTkOption(relief="solid")


        tk.Button(self).setText("save").place(150, 175, 150, 25).setCommand(self._save)
        tk.Button(self).setText("cancel").place(0, 175, 150, 25).setCommand(self._onCancel)

    def open(self):
        self.show()
        while not self._exit:
            if self._output is not None:
                self.destroy()
                return self._output
            self._master.update()
        self.destroy()

    def _save(self):
        if self._keyLabel.getText() == "<None>":
            return
        self._output = self._keyLabel.getText()

    def _onCancel(self, e):
        self._exit = True

    def _onAll(self, e):
        e = tk.Event(e)
        keysym = e.getTkArgs().keysym

        if self.isKey_ALT:
            self._keyLabel.setText(f"<Alt-{keysym}>")
        elif self.isKey_STRG:
            self._keyLabel.setText(f"<Control-{keysym}>")
        elif self.isKey_SHIFT:
            self._keyLabel.setText(f"<Shift-{keysym}>")
        else:
            self._keyLabel.setText(f"<{keysym}>")

    def onKey(self, e):
        key, state = e.getArgs()
        setattr(self, key, state)
class DragLabel(tk.Label):
    DEBUG = False
    DRAGS = []
    ACTIVE = None
    CANCEL_RESIZE = False
    def __init__(self, _master, left=None, right=None, onRelease=None):
        super().__init__(_master)
        DragLabel.DRAGS.append(self)
        if DragLabel.DEBUG: self.setBg("red") # temp
        self._left = left
        self._right = right
        self._onRelease = onRelease
        self._master = _master
        self._isMotion = False
        self._changed = False
        self._startLoc = None
        self._isBetween = False
        self._isClickPress = False
        self._hook = None
        self.pos = []
        self.bind(self._clickPress, tk.EventType.LEFT_CLICK_PRESS)
        self.bind(self._clickRelease, tk.EventType.LEFT_CLICK_RELEASE)
        self.bind(self._enter, "<Enter>")
        self.bind(self._leave, "<Leave>")
    def isCancelHook(self, h):
        self._hook = h
    def _enter(self):
        if DragLabel.CANCEL_RESIZE: return
        self._isBetween = True
        if self._isMotion or self._isClickPress: return
        self._master.setCursor(tk.Cursor.WIN_TWO_ARROW)
    def _leave(self):
        if DragLabel.CANCEL_RESIZE: return
        self._isBetween = False
        if self._isMotion: return
        self._master.setCursor(tk.Cursor.WIN_DEFAULT)
    def _clickPress(self, e):
        if DragLabel.CANCEL_RESIZE or (self._hook is not None and (self._hook())): return
        DragLabel.ACTIVE = self
        if not DragLabel.DEBUG: self.setBg("#A0A0A0")
        self._startLoc = tk.Location2D(e.getPos())
        self._isClickPress = True
        self._master.setCursor(tk.Cursor.WIN_TWO_ARROW)
    def _clickRelease(self):
        if DragLabel.CANCEL_RESIZE or (self._hook is not None and (self._hook())): return
        if not self._isMotion:
            pass
        self._isMotion = False
        self._isClickPress = False
        self._master.setCursor(tk.Cursor.WIN_DEFAULT)
        if self._isBetween: self._leave()
        if not DragLabel.DEBUG: self.setBg(tk.Color.DEFAULT)
        DragLabel.ACTIVE = None
        if self._onRelease is not None: self._onRelease()
    def place(self, x=None, y=None, width=None, height=None, anchor:tk.Anchor=tk.Anchor.UP_LEFT):
        _pos = []
        if self.pos:
            _pos = self.pos
            if x is not None: _pos[0] = x
            if y is not None: _pos[1] = y
            if width is not None: _pos[2] = width
            if height is not None: _pos[3] = height
        else:
            assert x is not None, "specify x at first place"
            assert y is not None, "specify y at first place"
            assert width is not None, "specify width at first place"
            assert height is not None, "specify height at first place"
            self.pos = _pos = [x, y, width, height]

        super().place(*_pos)
class FileExplorer(tk.Frame):
    def __init__(self, _master, path, highlight=None):
        super().__init__(_master)
        self._master = _master
        self.history = TreeHistory(path)
        self.lastClickOnFile = (t.time()*2, None)# (lastTime, path)
        self.path = path
        self.fileTree = tk.TreeView(self)
        self.fileTree.setMultipleSelect()
        self.fileTree.setTableHeaders("Name", "File-Type", "Modification-Date", "Size")
        self.fileTree.onSingleSelectEvent(self.onFileTreeSingleSelectEvent)
        self.fileTree.onArrowKeySelectEvent(self.onArrowSelect)

        self.fileTree.bind(self.onFileTreeReturnEvent, tk.EventType.RETURN)
        self.fileTree.bind(self.hotkey_esc, tk.EventType.ESC)

        self.fileTree.bind(self.backward, "<BackSpace>")
        self.fileTree.bind(self.backward, tk.EventType.MOUSE_PREV)
        #self.fileTree.bind(self.forward, Settings.getKeyBind("filetree_forward"))
        self.fileTree.bind(self.forward, tk.EventType.MOUSE_NEXT)

        self.fileTree.bind(self.showParentDir, "<Alt-Up>")
        self.fileTree.bind(self.hotkey_strgA, "<Control-a>")
        self.fileTree.bind(self.context_openInWin, "<Alt-e>")

        self.fileTree.setFocus()

        self.cEntry = PathCompleterEntry(self)

        self.cEntry.onUserInputEvent(self.onUserInputEvent)
        self.cEntry.onSelectEvent(self.onCEntrySelectEvent)

        self.bind(self._updatePlace, tk.EventType.CUSTOM_RELATIVE_UPDATE)

        self._updatePlace()

        self.empty = tk.Label(self).setBg("white").setText("This folder is empty!")

        self.fileContext = tk.ContextMenu(self.fileTree)
        tk.Button(self.fileContext).setText("Copy Path").setCommand(self.context_copyPath)
        self.fileContext.addSeparator()
        tk.Button(self.fileContext).setText("Open in Windows-Explorer").setCommand(self.context_openInWin)

        self.fileContext.create()

        self.oldPath = "C:\\"
        self.isFileTreeInForeground = False
        self.isDraggingFile = False
        self.dragMode = None # none, copy, move, ref
        self.renameTask = None

        self.updateFileTree(path, mark=highlight)

    def _updatePlace(self):
        self.fileTree.placeRelative(yOffsetUp=10, fixY=25, changeX=-1)
        self.cEntry.placeRelative(yOffsetUp=90, fixY=0, fixHeight=25)

    def getSelectedItemsAsPath(self):
        selected = self.fileTree.getSelectedItems()
        if selected is None: return []
        return [os.path.join(self.path, i["Name"]) for i in selected]
    def updateFileTree(self, path=".", mark:Union[list, str]=None, selectAll=False):
        if not mark is None:
            mark = [mark] if isinstance(mark, str) else mark
            mark = [os.path.split(i)[1] for i in mark]
        else: mark = []

        if path == "%drives%":
            pass
        else:
            if path == ".":
                path = self.path
            if os.path.exists(path):
                self.path = path
                self.cEntry.setValue(self.path)
                self.fileTree.clear()
                highlight = []
                try:
                    offset = 0
                    for i, file in enumerate(os.listdir(path)):

                        if file in mark:
                            highlight.append(i-offset)
                        if os.path.isdir(os.path.join(path, file)): #folder
                            self.fileTree.addEntry(file, "Folder", t.ctime(os.path.getmtime(os.path.join(path, file))), "", image=IconHandler.getFolderIcon())#self._getSizeDir(path)
                        elif os.path.islink(os.path.join(path, file)): #ref
                            self.fileTree.addEntry(os.path.splitext(os.path.join(path, file))[0], "Reference", t.ctime(os.path.getmtime(os.path.join(path, file))), parseSize(os.path.getsize(os.path.join(path, file))), image=IconHandler.getReferenceIcon())
                        elif os.path.isfile(os.path.join(path, file)): #file
                            ext = os.path.splitext(file)[1]
                            self.fileTree.addEntry(file, os.path.splitext(file)[1], t.ctime(os.path.getmtime(os.path.join(path, file))), parseSize(os.path.getsize(os.path.join(path, file))), image=IconHandler.getIconFromExtention(ext))
                        else:
                            continue

                    if highlight:
                        self.fileTree.clearSelection()
                        ind = -1
                        for ind in highlight:
                            self.fileTree.setItemSelectedByIndex(ind, False)
                        if ind >= 0: self.fileTree.see(ind)
                    if selectAll:
                        self.fileTree.clearSelection()
                        for i in range(self.fileTree.getSize()):
                            self.fileTree.setItemSelectedByIndex(i, False)
                    if self.fileTree.length() == 0:
                        self.empty.placeRelative(fixHeight=25, fixWidth=120, centerX=True, fixY=100)
                    else:
                        self.empty.placeForget()

                except PermissionError as e:
                    pass
            else:
                print("PATH DOES NOT EXISTS")

    def context_copy(self, e):
        sel = self.fileTree.getSelectedItems()
        if sel is None: return
        copyToClip("|".join([os.path.join(self.path, i["Name"]) for i in sel])) # copys only in settings set Paths (maybe not hidden/sys files)

    def context_copyPath(self, e):
        selected = self.getSelectedItemsAsPath()
        if not selected or len(selected) != 1: return
        selected = selected[0]
        copyToClip(selected)
    def context_openInWin(self, e):
        if os.path.exists(self.path):
            os.popen("start explorer " + self.path)

    def hotkey_strgA(self):
        self.updateFileTree(selectAll=True)
    def hotkey_esc(self):
        self.fileTree.clearSelection()

    def hotkey_f5(self):
        self.updateFileTree(self.path)

    def forward(self):
        self.history.forward()
        self.updateFileTree(self.history.get())
    def backward(self):
        self.history.backward()
        self.updateFileTree(self.history.get())

    def onTabCloseEvent(self):
        pass
    def onUserInputEvent(self):
        entry = self.cEntry.getValue()
        if entry == "": return []
        suggestions = []
        _path, raw = os.path.split(entry)
        if os.path.exists(_path):
            try:
                for p in os.listdir(_path):
                    if p.startswith(raw) and p != raw:
                        suggestions.append(p)
            except PermissionError as e:
                pass
        return suggestions
    def onCEntrySelectEvent(self, e):
        _mark = []
        path = e.getValue()
        if os.path.exists(path):
            if not os.path.isdir(path):
                _mark = path
                path = os.path.split(path)[0]
            self.history.add(path)
            self.updateFileTree(path, mark=_mark)
    def onFileTreeReturnEvent(self):
        """

        data:str -> {'Name': 'ZP_TODO.txt', 'File-Type': '.txt', 'Modification-Date': 'Sun Feb  6 12:07:37 2022', 'Size': '407.00b'}

        @return:
        """
        data = self.fileTree.getSelectedItems()
        self.isFileTreeInForeground = True
        if data is None: return
        data = data[0]

        if data["File-Type"] == "Folder":
            self.fileTree.setItemSelectedByIndex(0)
            self.path = os.path.join(self.cEntry.getValue(), data["Name"])
            self.history.add(self.path)
            self.updateFileTree(self.path)


            #openFile(os.path.join(self.path, data["Name"]))
    def onArrowSelect(self, e):
        value = e.getValue()
        if e.isKey(tk.EventType.ARROW_DOWN):
            value = self.fileTree.getDataByIndex(0)
            if self.fileTree.getSelectedItems() is None:
                self.fileTree.setItemSelectedByIndex(0)
                self.isFileTreeInForeground = False
            else:
                if self.isFileTreeInForeground: return
                selected = self.fileTree.getSelectedIndex()[0]
                if selected+1 >= self.fileTree.getSize():
                    return
                else:
                    self.fileTree.setItemSelectedByIndex(selected+1)
                    value = self.fileTree.getSelectedItems()
        elif e.isKey(tk.EventType.ARROW_UP):
            if self.isFileTreeInForeground: return
            if self.fileTree.getSelectedItems() is None:
                return
            else:
                selected = self.fileTree.getSelectedIndex()[0]
                if selected+1 <= 1:
                    return
                else:
                    self.fileTree.setItemSelectedByIndex(selected-1)
                    value = self.fileTree.getSelectedItems()

        value = value[0] if isinstance(value, list) else value

        path = os.path.join(self.path, value["Name"])
    def onFileTreeSingleSelectEvent(self, e):

        e = tk.Event(e)
        e.setTkEventCanceled()
        value = e.getValue()
        if value is None: return
        value = value[0]
        self.isFileTreeInForeground = True
        path = os.path.join(self.path, value["Name"])
        if path == self.lastClickOnFile[1]:
            task = self.renameTask
            self.renameTask = None
            if task is not None:
                task.cancel()
            if t.time()-self.lastClickOnFile[0] < 0.3:
                self.onFileTreeReturnEvent()
        self.lastClickOnFile = (t.time(), path)

    def showParentDir(self):
        #@TODO: select the previous folder
        subPath, this = os.path.split(self.path)
        self.isFileTreeInForeground = False
        if this == "": return
        self.history.add(subPath)
        self.updateFileTree(subPath)
    def _getSizeDir(self, path):
        _size = 0
        for root, dirs, files in os.walk(path):
            for file in files:
                _size += os.path.getsize(os.path.join(root, file))
        return parseSize(_size)
class FileExplorerDialog:
    @staticmethod
    def askFile(master, title, initialPath):
        def cancel():
            nonlocal _return
            _return = "None"
        def select(e):
            nonlocal _return
            sel = tv.getSelectedItemsAsPath()
            if sel is None:
                tk.SimpleDialog.askError(dialog, "Please choose at least one!")
                return
            else:
                _return = [sel] if not isinstance(sel, list) else sel

        _return = None
        _masterNone = None
        if master is None:
            _masterNone = True
            master = tk.Tk()
            master.hide()

        dialog = tk.Dialog(master)
        dialog.setWindowSize(500, 500)
        dialog.setTitle(title)
        tv = FileExplorer(dialog, initialPath)

        tk.Button(dialog).setText("Select").placeRelative(stickDown=True, fixHeight=30, xOffsetRight=50).setCommand(select)
        tk.Button(dialog).setText("Cancel").placeRelative(stickDown=True, stickRight=True, fixHeight=30, xOffsetRight=50).setCommand(cancel)

        dialog.show()
        tv.placeRelative(changeHeight=-30)
        #tv.updateRelativePlace()

        while True:
            master.update()
            t.sleep(.1)
            if _return == "None":
                if _masterNone: master.destroy()
                dialog.destroy()
                return None
            elif isinstance(_return, list):
                if _masterNone: master.destroy()
                dialog.destroy()
                return _return



class CopyLabel(tk.Frame):
    def __init__(self, _master):
        super().__init__(_master)
        self._label = tk.Label(self)
        self._label.setTextOrientation(tk.Anchor.LEFT)
        self._btn = tk.Button(self)
        self._btn.setCommand(self._copy)
        self._btn.setText("copy")
    def place(self, x=None, y=None, width=None, height=None, anchor:tk.Anchor=tk.Anchor.UP_LEFT):
        self._place(x, y, width, height, anchor)
        self._btn.placeRelative(stickRight=True, fixWidth=30)
        self._label.placeRelative(changeWidth=-30)
        return self
    def placeRelative(self, fixX=None, fixY=None, fixWidth=None, fixHeight=None, xOffset=0, yOffset=0, xOffsetLeft = 0, xOffsetRight=0, yOffsetUp=0, yOffsetDown=0, stickRight=False, stickDown=False, centerY=False, centerX=False, changeX=0, changeY=0, changeWidth=0, changeHeight=0, nextTo=None, updateOnResize=True):
        self._placeRelative(fixX, fixY, fixWidth, fixHeight, xOffset, yOffset, xOffsetLeft, xOffsetRight, yOffsetUp, yOffsetDown, stickRight, stickDown, centerY, centerX, changeX, changeY, changeWidth, changeHeight, nextTo, updateOnResize)
        self._btn.placeRelative(stickRight=True, fixWidth=30)
        self._label.placeRelative(changeWidth=-30)
        return self
    def getLabel(self)->tk.Label:
        return self._label
    def getButton(self)->tk.Button:
        return self._btn
    def setText(self, text):
        self._label.setText(text)
        return self
    def getText(self):
        return self._label.getText()


    def _copy(self):
        value = self._label.getText()
        copyToClip(value)




if __name__ == '__main__':

    FileExplorerDialog.askFile(None, "", r"C:\Users\langh\Documents\curseforge\Instances\Vault Hunters - Official Modpack (1)\mods")
