import os, sys
import shlex
import subprocess
from typing import Union
from PyExplorer.src.package.misc import parseSize


if sys.platform == "darwin":
    pass
elif sys.platform == "win32":
    import winreg



class MemoryInfo: #only WIN
    def __init__(self, data):
        self.data = data
    def __repr__(self):
        return str(self.data)
    def __getitem__(self, item):
        return self.data[item]
    def getFreeDiskSpace(self, parse=True)->Union[str, int]:
        space = self.data["FreeSpace"]
        if parse: space = parseSize(space)
        return int(space)
    def getDiskSpace(self, parse=True)->Union[str, int]:
        space = self.data["Size"]
        if parse: space = parseSize(space)
        return int(space)
    def getSystemName(self)->str:
        return self.data["SystemName"]
    def getCaption(self)->str:
        return self.data["Caption"]
    def getName(self)->str:
        return self.data["VolumeName"]
    def inExtern(self)->str: #check!
        return self.data["VolumeDirty"] != ""


class Memory:
    @staticmethod
    def _decode()->[MemoryInfo]:
        _data = subprocess.check_output("wmic logicaldisk get /value")
        data = []
        d = {}
        _data = _data.decode("utf8", errors="ignore").replace("\r", "").replace("  ", "").split("\n")
        _data = [x for x in _data if x]

        for i, v in enumerate(_data):
            if v.startswith("Access") and i > 1:
                data.append(MemoryInfo(d))
                d = {}
            k, v, *c = v.split("=")
            d[k] = v
        data.append(MemoryInfo(d))
        return data


    @staticmethod
    def getAllMemories()->[MemoryInfo]:
        return Memory._decode()

    @staticmethod
    def getInternMemories()->[MemoryInfo]:
        return [i for i in Memory._decode() if not i.inExtern()]

    @staticmethod
    def getExternMemories()->[MemoryInfo]:
        return [i for i in Memory._decode() if i.inExtern()]

    @staticmethod
    def getMemFromCaption(c)->MemoryInfo:
        for i in Memory._decode():
            if i.getCaption().lower().startswith(c.lower()):
                return i



class System:
    @staticmethod
    def getStdProgramFromExtention(suffix):
        print(suffix)
        try:
            if suffix in [".bat", ".cmd"]: suffix = ".txt"
            class_root = winreg.QueryValue(winreg.HKEY_CLASSES_ROOT, suffix)
            with winreg.OpenKey(winreg.HKEY_CLASSES_ROOT, r'{}\shell\open\command'.format(class_root)) as key:
                command = shlex.split(winreg.QueryValueEx(key, '')[0])[0]
                print(repr(command))
                return command
                #os.popen(command)#+r" C:\Robert\Feuerwehr\Vorlage_Vorstellung.docx")
        except Exception as e:
            raise e

    @staticmethod
    def getAllPrograms():
        a = subprocess.check_output("wmic product get", shell=True).decode("utf8", errors="ignore").replace("\r", "").replace("  ", "").split("\n")
        for i in a:
            print(i)



def openFile(path):
    path, file = os.path.split(path)

    os.system(rf'start "C:\Program Files (x86)\Notepad++\notepad++.exe" {os.path.join(path, file)}')
    return
    file_, ext = os.path.splitext(file)
    if not ext.startswith("."): ext = "."+ext
    cmd = System.getStdProgramFromExtention(ext)
    os.popen(cmd+" "+path)



if __name__ == '__main__':
    print(Memory.getMemFromCaption("c"))



