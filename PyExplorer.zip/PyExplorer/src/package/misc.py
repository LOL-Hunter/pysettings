from pyperclip import copy as _copy

pil_supported = ["png", "jpg", "jpeg", "bmp", "gif", "ico"]

def parseNumber(i:int)->str:
    return "{:,}".format(i).replace(",", ".")
def parseSize(_size:int):
    units = [" b", " KB", " MB", " GB", " TB"]
    for i in units:
        if _size < 1000:
            return f"{_size:.2f}{i}"
        _size /= 1000

def parseTime(t:float):
    t = round(t, 2)
    return str(t)


def copy(path:str):
    _copy(path)

def parseTimeFromSec(sec):
    minutes = 0
    hour = 0
    day = 0
    year = 0

    out = ""
    if sec / 60 >= 1:
        minutes += int(sec / 60)
        sec %= 60
        if minutes / 60 >= 1:
            hour += int(minutes / 60)
            minutes %= 60
            if hour / 24 >= 1:
                day += int(hour/24)
                hour %= 24
                if day / 365 >= 1:
                    year += int(day / 365)
                    hour %= 365
    out += f"{year} Years " if year > 0 else ""
    out += f"{day} Days " if day > 0 else ""
    out += f"{hour} Hours " if hour > 0 else ""
    out += f"{minutes} Minutes " if minutes > 0 else ""
    out += f"{sec} Seconds"
    return out


def parseTkEvent(e:str)->str:
    e = e.replace("<", "").replace(">", "")
    if e == "CANCEL": return "None"
    if "-" in e:
        return " + ".join(e.split("-"))
    else:
        return e.capitalize()

def parseArgs():
    pass