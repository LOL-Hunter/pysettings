import os
import threading as th
import time as t

class FileIndexer:
    def __init__(self, path, hiddenFiles=True, sysFiles=True):
        self._path = path
        self._sysFiles = sysFiles
        self._hiddenFiles = hiddenFiles
        self._running = False
        self._isIndexing = True
        self._files = 0
        self._folders = 0
        self._size = 0
        self._funcFol = None
        self._funcFil = None
        self._funcFin = None
        self._time = 0
    def _fileCheck(self, fileName:str):
        ext = os.path.splitext(fileName)[1]
        if not self._sysFiles:
            if ext in [".ini", ".sys"] or fileName.startswith("$"):
                return True
            if fileName == "bootmgr":
                return True
        if not self._hiddenFiles:
            if fileName.startswith("."): return True
        return False
    def onUpdateFolder(self, func):
        self._funcFol = func
        return self
    def onUpdateFile(self, func):
        self._funcFil = func
        return self
    def onFinish(self, func):
        self._funcFin = func
        return self
    def start(self, threaded=True):
        self._running = True
        if threaded:
            th.Thread(target=self._run).start()
        else:
            self._run()
        return self
    def stop(self):
        self._running = False
    def _run(self):
        offset = 0
        _time = t.time()
        if isinstance(self._path, list):
            _paths = self._path
        else:
            offset = 1
            _paths = [self._path]
        for paths in _paths:
            if os.path.isdir(paths):
                for dirpath, dirnames, filenames in os.walk(paths):
                    self._folders += 1
                    for file in filenames:
                        path = os.path.join(dirpath, file)
                        if not self._running: return
                        if self._fileCheck(path): continue
                        self._files += 1
                        size = -1
                        err = False
                        try:
                            size = os.path.getsize(path)
                            self._size += size
                        except Exception as e:
                            err = True
                            print(e)
                        if self._funcFil is not None: self._funcFil(path, size, err)
                    if self._funcFol is not None: self._funcFol(dirpath)
            else:
                if not self._running: return
                path = paths
                err = False
                if self._fileCheck(path): continue
                size=-1
                self._files += 1
                try:
                    size = os.path.getsize(path)
                    self._size += size
                except Exception as e:
                    print("e", e)
                    err = True
                if self._funcFil is not None: self._funcFil(path, size, err)
        self._time = t.time()-self._time
        self._folders = self._folders - offset
        self._isIndexing = False
        if self._folders == -1: self._folders = 0
        if self._funcFin is not None: self._funcFin()
    def getFinished(self):
        return not self._isIndexing
    def getTime(self):
        return self._time
    def getFiles(self):
        return self._files
    def getFolders(self):
        return self._folders
    def getSize(self):
        return self._size
class File:
    def __init__(self, path, size=None):
        self.path = path
        self.size = size if size is not None else (-1 if not os.path.exists(path) else os.path.getsize(path))
        self.content = b""
    def __lt__(self, other):
        if self.size is None: return False
        if other.size is None: return True
        return self.size > other.size
class Folder:
    def __init__(self):
        self.content = []


class History:
    def __init__(self, path:str):
        self._history = [path]
        self._pointer = 0
    def add(self, path:str):
        if self._history[-1] == path: return

        if self._pointer+1 != len(self._history):
            self._history = self._history[:self._pointer+1]
        self._history.append(path)
        self._pointer = len(self._history)-1
    def get(self):
        return self._history[self._pointer]
    def length(self):
        return len(self._history)
    def backward(self):
        if self._pointer != 0:
            self._pointer -= 1
    def forward(self):
        if self._pointer < len(self._history)-1:
            self._pointer += 1
def getCaptionFromPath(path):
    if path[1] == ":":
        return os.path.splitdrive(path)[0][0]
    return None

if __name__ == '__main__':
    d = r"C:\Users\langh\Downloads\1b55a6_ce7b69019caf4ca8941cad282367f845.pdf|C:\Users\langh\Downloads\2D-Character-Controller-master.zip|C:\Users\langh\Downloads\7z1900-x64.exe|C:\Users\langh\Downloads\AimBow.zip|C:\Users\langh\Downloads\Audacity_(32bit)_v2.3.3.exe|C:\Users\langh\Downloads\AZMT-main (1).zip|C:\Users\langh\Downloads\AZMT-main.zip|C:\Users\langh\Downloads\AzubiMgmt-PRE-RELEASE-1.1.zip|C:\Users\langh\Downloads\BC546.PDF|C:\Users\langh\Downloads\BlueStacksMicroInstaller_5.4.100.1026_native_6f72c9fa1c5c20df690e1fdfbe9a3df4_0.exe|C:\Users\langh\Downloads\Chunk_Defense_v1.1.zip|C:\Users\langh\Downloads\CurseForge - Installer.exe|C:\Users\langh\Downloads\datasheet (1).pdf|C:\Users\langh\Downloads\datasheet (2).pdf|C:\Users\langh\Downloads\datasheet (3).pdf|C:\Users\langh\Downloads\datasheet (4).pdf|C:\Users\langh\Downloads\datasheet.pdf|C:\Users\langh\Downloads\DiscordSetup.exe|C:\Users\langh\Downloads\Dungeon_Arena_Remix.zip|C:\Users\langh\Downloads\EHM3151 Elekronik Devreler 1 Laboratuvar Deney 5 Bilgilendirme (1).pdf|C:\Users\langh\Downloads\EHM3151 Elekronik Devreler 1 Laboratuvar Deney 5 Bilgilendirme.pdf|C:\Users\langh\Downloads\eisatz-3.txt|C:\Users\langh\Downloads\Harvest_Season.zip|C:\Users\langh\Downloads\HUD2.0-12.png|C:\Users\langh\Downloads\IJAMinecrafts-30-Second-Killer-Machine.zip|C:\Users\langh\Downloads\JavaSetup8u311.exe|C:\Users\langh\Downloads\jdk-12.0.2_windows-x64_bin.exe|C:\Users\langh\Downloads\jdk-14.0.2_windows-x64_bin.exe|C:\Users\langh\Downloads\jdk-17.0.1_windows-x64_bin.exe|C:\Users\langh\Downloads\jdk-8u202-windows-x64.exe|C:\Users\langh\Downloads\KeePass-2.49-Setup.exe|C:\Users\langh\Downloads\kondensatorAnAC1.png|C:\Users\langh\Downloads\kondensatorAnAC2.ggb|C:\Users\langh\Downloads\kondensatorAnAC2.png|C:\Users\langh\Downloads\kondensatorAnAC3.ggb|C:\Users\langh\Downloads\kondensatorAnAC3.png|C:\Users\langh\Downloads\kondesatorAnAc1.ggb|C:\Users\langh\Downloads\LabyMod3_Installer.exe|C:\Users\langh\Downloads\McAfee_Installer_serial_N0Gow1TmCIcFFAorcbYjng2_key_affid_850_akey.exe|C:\Users\langh\Downloads\Messschaltung1.ggb|C:\Users\langh\Downloads\Messschaltung1.png|C:\Users\langh\Downloads\Messschaltung2.ggb|C:\Users\langh\Downloads\Messschaltung2.png|C:\Users\langh\Downloads\Messschaltung3.ggb|C:\Users\langh\Downloads\Messschaltung3.png|C:\Users\langh\Downloads\Messschaltung5.ggb|C:\Users\langh\Downloads\Messschaltung5.png|C:\Users\langh\Downloads\MinecraftInstaller.msi|C:\Users\langh\Downloads\minecraftmaps.com-Crafting_Conumdrum_v1.0.zip|C:\Users\langh\Downloads\minecraftmaps.com-Just_Another_Escape_House_v1.1.zip|C:\Users\langh\Downloads\minecraftmaps.com-SOS_v1.0.zip|C:\Users\langh\Downloads\minecraftmaps.com-The_Minigame_Gameshow_v1.1.zip|C:\Users\langh\Downloads\minecraftmaps.com-Waltubers_FTB_v1.1.zip|C:\Users\langh\Downloads\modlist.html|C:\Users\langh\Downloads\Monsters_Paradise_v1.2.zip|C:\Users\langh\Downloads\Mr_Herobrines_Mansion.zip|C:\Users\langh\Downloads\my_spotify_data.zip|C:\Users\langh\Downloads\Neuer_ZIP-komprimierter_Ordner.zip|C:\Users\langh\Downloads\NoMoreRecipeConflict-1.7.10-0.3.2.jar|C:\Users\langh\Downloads\npp.8.1.9.Installer.exe|C:\Users\langh\Downloads\OfficeSetup.exe|C:\Users\langh\Downloads\open_24_display_st.zip|C:\Users\langh\Downloads\OptiFine_1.12.2_HD_U_G5.jar|C:\Users\langh\Downloads\PhtonTest_leernen_-_Kopie_-_Kopie_112.txt|C:\Users\langh\Downloads\PNG-Export (1).zip|C:\Users\langh\Downloads\PNG-Export.zip|C:\Users\langh\Downloads\Praktikum.T3001|C:\Users\langh\Downloads\pycharm-community-2021.2.3.exe|C:\Users\langh\Downloads\QuarCo-opEN_PL.zip|C:\Users\langh\Downloads\quarry-master.zip|C:\Users\langh\Downloads\RobloxPlayerLauncher.exe|C:\Users\langh\Downloads\roccat--swarm_76-1.9401-9452-v1|C:\Users\langh\Downloads\roccat--swarm_76-1.9401-9452-v1.zip|C:\Users\langh\Downloads\Sicherungskopie_Roberta.py|C:\Users\langh\Downloads\SteamSetup.exe|C:\Users\langh\Downloads\TCPView.zip|C:\Users\langh\Downloads\TeamViewer_Setup_x64.exe|C:\Users\langh\Downloads\temp.png|C:\Users\langh\Downloads\Thunderstore Mod Manager - Installer.exe|C:\Users\langh\Downloads\Triple+Digits+Arena+v2.0+for+MC+1.8.3.zip|C:\Users\langh\Downloads\UnityHubSetup.exe|C:\Users\langh\Downloads\vstu2015.msi|C:\Users\langh\Downloads\vs_community__6215996b.0e0f.4d8a.93da.cb646f1215b0.exe|C:\Users\langh\Downloads\WinSCP-5.19.4-Setup.exe|C:\Users\langh\Downloads\WW mine -1.0.zip".split("|")
    m = r"C:\Users\langh\Documents\test\test1.txt|C:\Users\langh\Documents\test\test2.txt|C:\Users\langh\Documents\test\test2".split("|")
    print(len(d))
    ind = FileIndexer(r"C:\Users\langh\Downloads")
    ind.start(False)
    from PyExplorer.src.package.misc import parseSize
    print("1", parseSize(ind.getSize()), ind.getFiles(), ind.getFolders())
    print("-"*20)
    ind2 = FileIndexer(d)
    ind2.start(False)
    print("2", parseSize(ind2.getSize()), ind2.getFiles(), ind2.getFolders())