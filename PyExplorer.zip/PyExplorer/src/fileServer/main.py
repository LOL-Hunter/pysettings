from flask import Flask, request, send_file, render_template_string, redirect
import os
from logging import ERROR, getLogger

app = Flask(__name__)

app.logger.disabled = True
_log = getLogger("werkzeug")
_log.setLevel(ERROR)
_log.disable = True

PATH = []
PATH_NAME_DICT = {}

html_content = """
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>PyExplorer v1.0 - FileExchangePlugin</title>
</head>
<body>

{{ button }}

</body>
</html>
"""

def create_layout(path)->str:
    buttons = f'<h1 style="font-size:30px;font-family:courier">Downloads:</h1>\n'

    for file in path:
        name = os.path.split(file)[1]
        buttons += f'<h1 style="font-size:20px;font-family:courier"><a href=/download?name={name.replace(" ", "_")}>{name}</a></h1>\n'


    content = html_content.replace("{{ button }}", buttons)

    return content


@app.route('/', methods=["GET", "POST"])
def index():
    layout = create_layout(PATH)
    return render_template_string(layout)


@app.route('/download', methods=["GET", "POST"])
def download():
    name = request.args.get('name')
    try:
        path = PATH_NAME_DICT[name]
    except KeyError:
        return redirect("index")
    return send_file(path, as_attachment=True)



def run(path, ip, port):
    global PATH
    PATH = path
    for i in path:
        PATH_NAME_DICT[os.path.split(i)[1].replace(" ", "_")] = i
    os.environ["WERKZEUG_RUN_MAIN"] = "true"
    app.run(debug=True, host=ip, port=port, use_reloader=False)


if __name__ == '__main__':
    run(['C:\\Robert\\smily.png'], "192.168.2.122", 8000)


