from PyExplorer.src.plugins import EventHandler, Event, Plugin
from pyperclip import copy as copyToClip
from webbrowser import open as  openInBrowser
from tkinter import font
from pysettings.text import MsgText
from pysettings.jsonConfig import JsonConfig, AdvancedJsonConfig
from pysettings import tk
from pysettings.jsonConfig import JsonConfig
import os
import time as t
import threading as th

VERSION = "v1.0"
DESCRIPTION ="""Plugin to edit utf-8 encoded text."""

CONFIG_PATH = os.path.join(os.path.split(__file__)[0], "config", "textEditorPlugin.json")


class TextEditorGUI(tk.Toplevel):
    def __init__(self, path=""):
        super().__init__(plugin.getWindow(), False)
        TextEditorPlugin.EDITORS.append(self)
        self.forceFocus()
        self.currPath = path
        self.setWindowSize(300, 300)
        self.setTitle(f"Editor {VERSION}-"+path)
        self.textFrame = tk.Frame(self)
        self.textSize = 10
        self.font = TextEditorPlugin.CONFIG.get("font", "Arial")
        self.text = tk.Text(self.textFrame, scrollAble=True)
        self.text.setWrapping(tk.Wrap.NONE)
        self.text.onUserInputEvent(self.onEdit)
        self.text.bind(self.save, "<Control-s>")
        self.text.bind(self.onStrgMouseWh, "<Control-MouseWheel>")
        self.text.setFont(self.textSize, self.font)
        self.bind(self.close, "<Escape>")

        self.taskBar = tk.TaskBar(self)
        file = self.taskBar.createSubMenu("File")
        tools = self.taskBar.createSubMenu("Tools")

        tk.Button(tools).setText("Prettify JSON").setCommand(self.json, args="pr")
        tk.Button(tools).setText("Line JSON").setCommand(self.json, args="li")

        self.taskBar.create()

        self.prog = tk.Dialog(self)
        self.prog.onCloseEvent(self.closeProg)
        self.prog.setWindowSize(320, 125)
        self.prog.setResizeable(False)
        self.bar = tk.Progressbar(self.prog)
        self.bar.place(10, 10, 300, 25)
        tk.Label(self.prog).setText(f"Loading file: {self.currPath}...").place(10, 50)
        self.loadingProgress = tk.Label(self.prog).setText("Loading: 0%").place(10, 75)
        self.cancel = tk.Button(self.prog)

        self.textFrame.placeRelative()
        self.onCloseEvent(self.onClose)

        self.closed = False
        self.running = True
        self.saved = True

        self.rcMenu = tk.ContextMenu(self.text)
        tk.Button(self.rcMenu).setText("Copy").setCommand(self.textBoxMenu, args=["copy"])
        tk.Button(self.rcMenu).setText("open URL").setCommand(self.textBoxMenu, args=["openWb"])
        tk.Button(self.rcMenu).setText("search with GOOGLE").setCommand(self.textBoxMenu, args=["google"])
        self.rcMenu.create()
    def closeProg(self):
        self.running = False
        t.sleep(.1)
        self.destroy()
    def textBoxMenu(self, e):
        args = e.getArgs(0)
        selected = self.text.getSelectedText()
        if selected is None: return
        if args == "copy":
            copyToClip(selected)
        elif args == "openWb":
            openInBrowser(selected.strip())
        elif args == "google":
            openInBrowser(f"https://www.google.com/search?q={selected.strip()}")
    def onStrgMouseWh(self, e):
        delta = e.getTkArgs().delta
        if str(delta).startswith("-"):
            if self.textSize > 1:
                self.textSize -= 1
        else:
            self.textSize += 1

        self.text.setFont(self.textSize, self.font)
    def canClose(self):
        return self.closed or self.saved
    def cancelLoad(self):
        self.running = False
    def onEdit(self):
        if self.content != self.text.getText():
            self.setTitle(f"*Editor {VERSION}-" + self.currPath)
            self.saved = False
    def onClose(self, e):
        e.setCanceled(True)
        self.running = False
        t.sleep(0.1)
        if not self.saved:
            anw = tk.SimpleDialog.askYesNoCancel(self, "There are unsaved changes on this document.\nDo you want to save them?", "PyExplorer")
            if anw:
                self.save()
                e.setCanceled(False)
                self.closed = True
            elif anw is None:
                return
            else:
                e.setCanceled(False)
                self.closed = True
        else:
            e.setCanceled(False)
            self.closed = True
        if self.closed:
            TextEditorPlugin.EDITORS.remove(self)
    def save(self):
        self._save()
    def _save(self):
        self.content = self.text.getText()
        file = open(self.currPath, "w")
        file.write(self.content)
        file.close()
        self.setTitle(f"Editor {VERSION}-" + self.currPath)
        self.saved = True
        plugin.updateActiveProperties(self.currPath)
    def open(self):
        self.running = True
        self.prog.show()
        self.content = self.decodeFile(self.currPath)
        lines = len(self.content.splitlines())
        for i, line in enumerate(self.content.splitlines()):
            if not self.running:
                return
            self.text.addLine(line)
            if i % 10 == 0:
                self.bar.setPercentage(i/lines)
                self.loadingProgress.setText(f"Loading: {round((i/lines)*100, 2)}%")
            self.update()
        self.loadingProgress.setText(f"Loading: {100}%")
        self.prog.hide()
        self.text.placeRelative()
    def decodeFile(self, path):
        _, ext = os.path.splitext(path)
        file = open(path, "rb")
        raw = file.read()
        file.close()
        try:
            content = raw.decode("utf8")
        except UnicodeDecodeError as e:
            MsgText.error("Could not decode this File correctly!")
            content = raw.decode("utf8", "ignore")
        return content
    def json(self, e):
        args = e.getArgs() if isinstance(e, tk.Event) else e
        if args == "li":
            content = self.text.getText()
            content = content.replace("\n", "").replace("\t", "")
            self.text.setText(content)
        else:
            content = self.text.getText()
            data = JsonConfig.prettifyString(content, True)
            if data.startswith("{") or data.startswith("["):
                self.text.setText(data)
            else:
                tk.SimpleDialog.askError(self, data, f"*Editor {VERSION}-ERROR")
class TextEditorPlugin(EventHandler):
    EDITORS = []
    CONFIG = None
    def __init__(self):
        self.editors = []
    def openGUI(self, path):
        editor = TextEditorGUI(path)
        th.Thread(target=editor.open).start()
        return editor
    def onFileTreeSelectEvent(self, e):
        e = Event(e)
        self.openGUI(e.getPath())
    def onSettingsFrameConstruct(self, frame):
        lf = tk.LabelFrame(frame).setText("Font").place(0, 0, 100, 100)
        self.drop = tk.DropdownMenu(lf).setOptionList(font.families()).onSelectEvent(self.changeFont).setValue(TextEditorPlugin.CONFIG["font"]).place(0, 0, 95, 25)
    def changeFont(self):
        _font = self.drop.getValue()
        if _font is not None:
            _font = _font.title()
            if _font not in font.families():
                return
            TextEditorPlugin.CONFIG["font"] = _font
            TextEditorPlugin.CONFIG.save()
            for i in TextEditorPlugin.EDITORS:
                i.text.setFont(i.textSize, _font)
    def onEnable(self):
        TextEditorPlugin.CONFIG = AdvancedJsonConfig("textEditorPlugin")
        TextEditorPlugin.CONFIG.setDefault({
	        "font":"Arial",
        })
        TextEditorPlugin.CONFIG.load(CONFIG_PATH)
    def onDisable(self, e):
        e.setCanceled(not all([editor.canClose() for editor in self.editors]))

plugin = Plugin(priority=-10)
plugin.registerBind("test", "<Escape>")
plugin.register(TextEditorPlugin)



