from PyExplorer.src.plugins import EventHandler, Event, Plugin
from pysettings.text import MsgText
from pysettings.jsonConfig import JsonConfig
from pysettings import tk
import os
import threading as th

VERSION = "v1.0"

class TextEditor(tk.Toplevel):
    def __init__(self, path=""):
        super().__init__(plugin.getWindow(), False)
        self.forceFocus()
        self.currPath = path
        self.setWindowSize(300, 300)
        self.setTitle(f"PDF-Viewer {VERSION}-"+path)
        self.textFrame = tk.Frame(self)
        self.text = tk.Text(self.textFrame, scrollAble=True)
        self.text.onUserInputEvent(self.onEdit)
        self.text.bind(self.save, "<Control-s>")
        self.bind(self.close, "<Escape>")

        self.taskBar = tk.TaskBar(self)
        file = self.taskBar.createSubMenu("File")
        tools = self.taskBar.createSubMenu("Tools")


        tk.Button(tools).setText("Prettify JSON").setCommand(self.json, args="pr")
        tk.Button(tools).setText("Line JSON").setCommand(self.json, args="li")


        self.taskBar.create()

        self.prog = tk.Dialog(self)
        self.prog.setWindowSize(320, 125)
        self.prog.setResizeable(False)
        self.bar = tk.Progressbar(self.prog)
        self.bar.place(10, 10, 300, 25)
        tk.Label(self.prog).setText(f"Loading file: {self.currPath}...").place(10, 50)
        self.loadingProgress = tk.Label(self.prog).setText("Loading: 0%").place(10, 75)
        self.cancel = tk.Button(self.prog)



        self.textFrame.placeRelative()
        self.onCloseEvent(self.onClose)

        self.closed = False
        self.running = True
        self.saved = True

        if path is not None:
            if os.path.exists(path):
                th.Thread(target=self.open).start()


        self.mainloop()
    def canClose(self):
        return self.closed or self.saved
    def cancelLoad(self):
        self.running = False
    def onEdit(self):
        if self.content != self.text.getText():
            self.setTitle(f"*Editor {VERSION}-" + self.currPath)
            self.saved = False
    def onClose(self, e):
        e.setCanceled(True)
        self.running = False
        if not self.saved:
            anw = tk.SimpleDialog.askYesNoCancel(self, "There are unsaved changes on this document.\nDo you want to save them?")
            if anw:
                self.save()
                e.setCanceled(False)
                self.closed = True
            elif anw is None:
                return
            else:
                e.setCanceled(False)
                self.closed = True
        else:
            e.setCanceled(False)
            self.closed = True
    def save(self):
        self._save()
    def _save(self):
        self.content = self.text.getText()
        file = open(self.currPath, "w")
        file.write(self.content)
        file.close()
        self.setTitle(f"Editor {VERSION}-" + self.currPath)
        self.saved = True
        plugin.updateActiveProperties(self.currPath)
    def open(self):
        self.running = True
        self.prog.show()
        content = self.decodeFile(self.currPath)
        lines = len(content.splitlines())
        for i, line in enumerate(content.splitlines()):
            if not self.running:
                break
            self.text.addLine(line)
            if i % 10 == 0:
                self.bar.setPercentage(i/lines)
                self.loadingProgress.setText(f"Loading: {round((i/lines)*100, 2)}%")
            self.update()
        self.loadingProgress.setText(f"Loading: {100}%")
        self.prog.hide()
        self.text.placeRelative()
    def decodeFile(self, path):
        _, ext = os.path.splitext(path)
        file = open(path, "rb")
        raw = file.read()
        file.close()
        try:
            content = raw.decode("utf8")
        except UnicodeDecodeError:
            MsgText.error("Could not decode this File correctly!")
            content = raw.decode("utf8", "ignore")
        return content

    def json(self, e):
        args = e.getArgs() if isinstance(e, tk.Event) else e
        print(args)
        if args == "li":
            content = self.text.getText()
            content = content.replace("\n", "").replace("\t", "")
            self.text.setText(content)
        else:
            content = self.text.getText()
            data = JsonConfig.prettifyString(content, True)
            if data.startswith("{") or data.startswith("["):
                self.text.setText(data)
            else:
                tk.SimpleDialog.askError(self, data, f"*Editor {VERSION}-ERROR")


class PDFViewerPlugin(EventHandler):
    def __init__(self):
        self.editors = []
    def onFileTreeSelectEvent(self, e):
        if os.path.splitext(e.getPath())[1] == ".pdf":
            e = Event(e)
            e.cancelOtherCalls(True)
            editor = TextEditor(e.getPath())
            th.Thread(target=editor.open).start()
    def onEnable(self):
        pass
    def onDisable(self, e):
        e.setCanceled(not all([editor.canClose() for editor in self.editors]))



plugin = Plugin(priority=-9)
plugin.disable()
plugin.register(PDFViewerPlugin)

if __name__ == '__main__':

    TextEditor("")