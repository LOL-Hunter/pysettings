from PyExplorer.src.plugins import EventHandler, Event, Plugin
import os
import time as t
import threading as th
from pysettings import tk
from PyExplorer.src.package.misc import parseNumber, parseSize
from PyExplorer.src.package.pathTools import FileIndexer as _Indexer


"""
-export to file
-hide with same name

"""
DESCRIPTION ="""This Plugin can analyze folder structures and show the information.
The user can also save the results in JSON-File.
"""


class File:
    def __init__(self, path, size=None):
        self.path = path
        self.size = size if size is not None else (-1 if not os.path.exists(path) else os.path.getsize(path))
    def __lt__(self, other):
        if self.size is None: return False
        if other.size is None: return True
        return self.size > other.size

class Folder:
    def __init__(self):
        pass

class FileIndexer(_Indexer):
    def __init__(self, path):
        self.files = []
        self.fileTypes = {}
        super().__init__(path)
        self.onUpdateFile(self._update)
    def _update(self, path, size, err):
        file = File(path, size)
        ext = os.path.splitext(path)[1]
        key = ("none" if ext == "" else ext)
        self.files.append(file)
        if key in self.fileTypes.keys():
            self.fileTypes[key].append(file)
        else:
            self.fileTypes[key] = [file]

    def sortFileTypes(self):
        for i in self.fileTypes.values():
            i.sort()

class Analyzer(tk.Toplevel):
    ACTIVE_ANALYZER = None
    def __init__(self, path):
        self.data = {}
        Analyzer.ACTIVE_ANALYZER = self
        self.path = path
        super().__init__(plugin.getWindow(), topMost=False)
        self.setTitle("Directory-Analyzer v1.0")
        self.setWindowSize(500, 300)
        self.bind(self.close, tk.EventType.ESC)

        self.startFrame = tk.Frame(self)
        self.analyzeFrame = tk.Frame(self)
        self.endFrame = tk.Frame(self)

        self.onCloseEvent(self.onClose)
        self.startBtn = tk.Button(self.startFrame).setText("Start Analyzing").place(500-105, 300-30, 100, 25).setCommand(self.analyze)

        self.pathE = tk.TextEntry(self.startFrame).setText("Target Directory:").place(0, 25, 500, 25).setValue(self.path)

        self.setFocus()

        self.analyzeTasks = ["Indexing...", "Analyzing...", "Finishing up..."]
        self.mainProg = tk.Progressbar(self.analyzeFrame, values=len(self.analyzeTasks))
        self.mainProg.place(10, 25, 480, 25)
        self.mainTask = tk.Label(self.analyzeFrame).setText(self.analyzeTasks[0]).place(10, 0, 480, 25)

        self.subTaskProg = tk.Progressbar(self.analyzeFrame).setAutomaticMode().place(10, 75, 480, 25)
        self.subTask = tk.Label(self.analyzeFrame).setText(self.analyzeTasks[0]).place(10, 100, 480, 25)

        self.dataNotebook = tk.Notebook(self.endFrame)

        self.tab_general = self.dataNotebook.createNewTab("General")
        #self.dataNotebook.createNewTab("Sizes")
        #self.dataNotebook.createNewTab("Sizes")
        self.tab_sizes = self.dataNotebook.createNewTab("Files Size")
        self.tab_types = self.dataNotebook.createNewTab("File Types")

        self.dataNotebook.placeRelative(fixY=25)

        tk.Button(self.endFrame).setText("Export Data").placeRelative(stickDown=True, fixHeight=25, fixWidth=100, centerX=True)
        tk.Button(self.endFrame).setText("Exit").placeRelative(stickDown=True, fixHeight=25, fixWidth=100, stickRight=True)
        tk.Button(self.endFrame).setText("Reanalyze").placeRelative(stickDown=True, fixHeight=25, fixWidth=100)

        self.generalText = tk.Text(self.tab_general, readOnly=True)
        self.generalText.placeRelative(changeHeight=-25)

        self.filesSize = tk.TreeView(self.tab_sizes)
        self.filesSize.setTableHeaders("Name", "Size", "Path")
        self.filesSize.bind(self.onFileTreeSelectEvent, tk.EventType.DOUBBLE_LEFT, args=[self.filesSize])
        self.filesSize.placeRelative(changeHeight=-25)

        self.filesSize2 = tk.TreeView(self.tab_types)
        self.filesSize2.setTableHeaders("Name", "Size", "Path")
        self.filesSize2.bind(self.onFileTreeSelectEvent, tk.EventType.DOUBBLE_LEFT, args=[self.filesSize2])
        self.filesSize2.placeRelative(xOffsetLeft=20, fixY=25, changeHeight=-25)

        self.fileTypesNum = tk.Label(self.tab_types)
        self.fileTypesNum.setTextOrientation(tk.Anchor.LEFT)
        self.fileTypesNum.placeRelative(xOffsetLeft=50, fixY=0, fixHeight=25)

        self.fileTypeSearch = tk.Entry(self.tab_types)
        self.fileTypeSearch.onUserInputEvent(self.onSearch)
        self.fileTypeSearch.placeRelative(xOffsetRight=80, fixY=0, fixHeight=25)

        self.typesListbox = tk.Listbox(self.tab_types)
        self.typesListbox.onSelectEvent(self.addToFileTypes)
        self.typesListbox.placeRelative(xOffsetRight=80, fixY=25, changeHeight=-25)

        self.startFrame.placeRelative()

        self.updateDynamicWidgets()
        self.isRunning = False
    def _sleep(self, s):
        curr = t.time()
        while True:
            self.update()
            if t.time() - curr >= s:
                break
    def analyze(self):
        self.isRunning = True
        self.path = self.pathE.getValue()
        if not os.path.exists(self.path):
            tk.SimpleDialog.askError(self, f"This target directory does not exists!\n{self.path}")
            return
        self.startFrame.placeForget()
        self.analyzeFrame.placeRelative()

        c = 0
        def update(path):
            nonlocal c
            if c > 10:
                c=0
                self.subTask.setText(path)
                self.update()
            c+=1
        self.timerIndexing = t.time()
        self.indexer = FileIndexer(self.path)
        self.indexer.onUpdateFolder(update)
        self.indexer.start(threaded=False)
        self.timerIndexing = t.time()-self.timerIndexing
        self.subTask.setText("")
        self.subTaskProg.setNormalMode()
        self.update()
        self.subTaskProg.reset()
        self.mainProg.addValue()
        self.update()
        self.mainTask.setText(self.analyzeTasks[1]) # analyzing"

        content = f"""Path:    {self.path}
Files:   {parseNumber(self.indexer.getFiles())}
Folders: {parseNumber(self.indexer.getFolders())}
Size:    {parseSize(self.indexer.getSize())}
"""
        self.generalText.setText(content)

        self.indexer.files.sort()
        self.indexer.sortFileTypes()

        self._sleep(0.5)

        self.mainProg.addValue()
        self.mainTask.setText(self.analyzeTasks[2]) # finishing up

        for i in self.indexer.files:
            self.filesSize.addEntry(os.path.split(i.path)[1], (parseSize(i.size) if i.size is not None else "none"), i.path)
        for i in self.indexer.fileTypes.keys():
            self.typesListbox.add(i+f"| ({parseNumber(len(self.indexer.fileTypes[i]))} Files)")
        self.addToFileTypes(list(self.indexer.fileTypes.values())[0])

        self._sleep(1)

        self.mainProg.setPercentage(100)
        self._sleep(0.2)

        self.endFrame.placeRelative()
        self.updateDynamicWidgets()
        self.isRunning = False
    def addToFileTypes(self, l):
        if isinstance(l, tk.Event):
            if l.getValue() is None: return
            l = self.indexer.fileTypes[l.getValue().split("|")[0]]
        self.filesSize2.clear()
        for i in l:
            self.filesSize2.addEntry(os.path.split(i.path)[1], (parseSize(i.size) if i.size is not None else "none"), i.path)
        self.fileTypesNum.setText(f"Different Types: {len(list(self.indexer.fileTypes.keys()))}|Files: {len(l)}")
    def onFileTreeSelectEvent(self, e):
        """

        {'Name': 'ZP_TODO.txt', 'File-Typ': '.txt', 'Modification-Date': 'Sun Feb  6 12:07:37 2022', 'Size': '407.00b'}

        @return:
        """

        sel = e.getArgs()[0].getSelectedItems()
        if sel is None: return
        data = sel[0]
        if data is None: return
        plugin.call("onFileTreeSelectEvent", path=data["Path"])
    def onSearch(self, e):
        content = self.fileTypeSearch.getValue()
        self.typesListbox.clear()
        if content == "":
            for i in self.indexer.fileTypes.keys():
                self.typesListbox.add(i+f"| ({parseNumber(len(self.indexer.fileTypes[i]))} Files)")
        else:
            for i in self.indexer.fileTypes.keys():
                if i.lower().startswith(content):
                    self.typesListbox.add(i+f"| ({parseNumber(len(self.indexer.fileTypes[i]))} Files)")
    def reset(self):
        self.filesSize.clear()
        self.generalText.clear()
        self.filesSize2.clear()
        self.typesListbox.clear()
        self.fileTypeSearch.clear()
    def close(self):
        if self.onClose(tk.Event()): self.destroy()
    def onClose(self, e):
        if self.isRunning:
            if not tk.SimpleDialog.askOkayCancel(self, "Do you want to cancel\nthe analyzing process?", "Analyzer"):
                e.setCanceled(True)
                return False
            else:
                self.isRunning = False
        Analyzer.ACTIVE_ANALYZER = None
        return True
    def tryOpen(self):
        pass
    def open(self):
        pass
    def canClose(self):
        return True

class AnalyzerPlugin(EventHandler):
    def __init__(self):
        self.analyzers = []
    def open(self):
        if Analyzer.ACTIVE_ANALYZER is None:
            editor = Analyzer(plugin.getPath())
            th.Thread(target=editor.open).start()
        else:
            Analyzer.ACTIVE_ANALYZER.tryOpen()
    def onEnable(self):
        plugin.registerTaskCommand("tools", "Directory Analyzer", self.open)
        #editor = Analyzer("C:\\Robert")
        #th.Thread(target=editor.open).start()

    def onDisable(self, e):
        if Analyzer.ACTIVE_ANALYZER is not None:
            e.setCanceled(not Analyzer.ACTIVE_ANALYZER.canClose())


plugin = Plugin()
plugin.register(AnalyzerPlugin)

if __name__ == '__main__':

    Analyzer("")