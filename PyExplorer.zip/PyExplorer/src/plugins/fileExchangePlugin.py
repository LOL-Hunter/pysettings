from PyExplorer.src.plugins import EventHandler, Event, Plugin
from PyExplorer.src.package.widgets import FileExplorer, CopyLabel
#from PyExplorer.src.fileServer import FileServer
from multiprocessing import Process
from pysettings.text import MsgText
from pysettings import tk
from pysettings.jsonConfig import AdvancedJsonConfig

from webbrowser import open as openWeb
import requests
import os, socket, sys
import threading as th

VERSION = "v1.0"
DESCRIPTION = """This is a Plugin to share files via open port and http server."""

CONFIG_PATH = os.path.join(os.path.split(__file__)[0], "config", "fileExchangePlugin.json")

class FileServer:
    def __init__(self, ip, port):
        self._ip = ip
        self._port = port
        self._extPort = self._getExternIp()
        self._process = None
        self._int_url = f"http://{ip}:{port}"
        self._ext_url = f"http://{self._extPort}:{port}"
    def _getExternIp(self):
        return requests.get("https://checkip.amazonaws.com/").content.decode("utf8").replace("\n", "")
    def updateURL(self):
        self._int_url = f"http://{self._ip}:{self._port}"
        self._ext_url = f"http://{self._extPort}:{self._port}"
    def getExternURL(self):
        return self._ext_url
    def getInternURL(self):
        return self._int_url

    def start(self, path):
        if type(path) == list:
            path = [p for p in path if not os.path.isdir(p)]
        elif type(path) == str:
            if os.path.isdir(path):
                paths = os.listdir(path)
                path = [p for p in paths if not os.path.isdir(p)]
            else:
                path = [path]
        if self._process is not None:
            self.stop()
        MsgText.info(f"FileServer session opened! Running on: {self.getInternURL()}")
        self._process = Process(target=self._start, args=(path, self._ip, self._port))
        self._process.start()

    def _start(self, path, ip, port):
        from PyExplorer.src.fileServer.main import run
        run(path, ip, port)

    def stop(self):
        if self._process is not None:
            MsgText.info("FileServer session closed successfully!")
            self._process.terminate()
            self._process = None
class FileExchangeGUI(tk.Dialog):
    SELECTED_PATHS = []
    IS_PORT_LOCAL = False
    SERVER_RUNNING = False
    ACTIVE_FILE_SERVER = None
    ACTIVE_GUI = None
    def __init__(self, path=""):
        super().__init__(plugin.getWindow(), False)
        FileExchangeGUI.ACTIVE_GUI = self
        self.onCloseEvent(self._onClose)
        self.forceFocus()
        self.setWindowSize(600, 400)
        self.setResizeable(False)
        self.setTitle(f"FileExchange {VERSION}-"+path)

        self.explFrame = tk.LabelFrame(self)
        self.explFrame.setText("Select files")
        self.explFrame.place(225, 0, 400, 400)
        self.bind(self.close, tk.EventType.ESC)

        self.expl = FileExplorer(self.explFrame, path)
        self.expl.placeRelative(changeHeight=-20, changeWidth=-5)

        self.controlFrame = tk.LabelFrame(self)
        self.controlFrame.setText("Control-Panel")
        self.controlFrame.place(0, 0, 225, 200)

        self.toggleServer = tk.OnOffButton(self.controlFrame).placeRelative(changeWidth=-5, fixHeight=25)
        self.toggleServer.setValue(FileExchangeGUI.SERVER_RUNNING)
        self.toggleServer.setOnText("Server Online!")
        self.toggleServer.setOffText("Server Offline!")
        self.toggleServer.setCommand(self.btnToggleServer)

        self.listb = tk.Listbox(self.controlFrame).placeRelative(fixY=25, changeHeight=-45)
        self.listb.addAll(FileExchangeGUI.SELECTED_PATHS)


        tk.Button(self.controlFrame).setText("Add").placeRelative(fixHeight=25, stickDown=True, xOffsetRight=50, changeY=-20, changeWidth=-40).setCommand(self.addSelected).attachToolTip("Adds the elements selected in the filetree to the list.")
        tk.Button(self.controlFrame).setText("Remove").placeRelative(fixHeight=25, stickDown=True, xOffsetRight=50, changeY=-20, changeWidth=-40, changeX=60).setCommand(self.deleteSelected).attachToolTip("Deletes the element selected in the list.")
        tk.Button(self.controlFrame).setText("Clear").placeRelative(fixHeight=25, stickDown=True, xOffsetLeft=50, changeY=-20, changeWidth=-25, changeX=+20).setCommand(self.clear).attachToolTip("Deletes all elements of the list box.")

        self.info = tk.LabelFrame(self)
        self.info.setText("Info")
        self.info.place(0, 200, 225, 200)

        tk.Label(self.info).setText("URL intern:").setTextOrientation(tk.Anchor.LEFT).placeRelative(fixHeight=25, changeWidth=-5)
        self.urlLabel = CopyLabel(self.info).placeRelative(fixHeight=25, fixY=25, changeWidth=-5)
        self.urlLabel.getLabel().setFg("#365EFF")
        self.urlLabel.getLabel().setFont(underline=True)
        self.urlLabel.getLabel().bind(self.openURL, tk.EventType.LEFT_CLICK, args=["intern"])
        self.urlLabel.getLabel().bind(self.openURLRelease, tk.EventType.LEFT_CLICK_RELEASE, args=["intern"])

        tk.Label(self.info).setText("URL extern:").setTextOrientation(tk.Anchor.LEFT).placeRelative(fixHeight=25, fixY=50, changeWidth=-5)
        self.urlLabel2 = CopyLabel(self.info).placeRelative(fixHeight=25, fixY=75, changeWidth=-5)
        self.urlLabel2.getLabel().setFg("#365EFF")
        self.urlLabel2.getLabel().setFont(underline=True)
        self.urlLabel2.getLabel().bind(self.openURL, tk.EventType.LEFT_CLICK, args=["extern"])
        self.urlLabel2.getLabel().bind(self.openURLRelease, tk.EventType.LEFT_CLICK_RELEASE, args=["extern"])

        self.localCheck = tk.Checkbutton(self.info).placeRelative(fixHeight=25, fixY=100, changeWidth=-5).setText("Use local port").setTextOrientation(tk.Anchor.LEFT).onSelectEvent(self.updateCheck)

        self.running = True
        self.saved = True
        self.ip = socket.gethostbyname(socket.gethostname())
        if FileExchangeGUI.ACTIVE_FILE_SERVER is None:
            FileExchangeGUI.ACTIVE_FILE_SERVER = FileServer(self.ip, FileExchangePlugin.INT_PORT if FileExchangeGUI.IS_PORT_LOCAL else FileExchangePlugin.EXT_PORT)

        self.updateDynamicWidgets()
        self.show()
    def updateCheck(self):
        FileExchangeGUI.IS_PORT_LOCAL = self.localCheck.getValue()
        FileExchangeGUI.ACTIVE_FILE_SERVER._port = FileExchangePlugin.INT_PORT if FileExchangeGUI.IS_PORT_LOCAL else FileExchangePlugin.EXT_PORT
        FileExchangeGUI.ACTIVE_FILE_SERVER.updateURL()
    def deleteSelected(self):
        sel = self.listb.getSelectedItem()
        if sel is None: return
        FileExchangeGUI.SELECTED_PATHS.remove(sel)
        self.listb.deleteItemByName(sel)
    def addSelected(self, e):
        sel = self.expl.fileTree.getSelectedItems()
        if sel is None: return
        all_ = self.listb.getAllSlots()
        for data in sel:
            path = os.path.join(self.expl.path, data["Name"])
            if path in all_: continue
            self.listb.add(path)
        FileExchangeGUI.SELECTED_PATHS = self.listb.getAllSlots()
    def clear(self, e):
        if tk.SimpleDialog.askYesNo(plugin.getWindow(), "Are you sure you want to clear the list?"):
            FileExchangeGUI.SELECTED_PATHS = []
            self.listb.clear()
    def openURL(self, e):
        mode = e.getArgs()[0]
        if FileExchangeGUI.SERVER_RUNNING:
            if mode == "intern":
                self.urlLabel.getLabel().setFg("#7B45FF")
            elif mode == "extern":
                self.urlLabel2.getLabel().setFg("#7B45FF")
    def openURLRelease(self, e):
        mode = e.getArgs()[0]
        if FileExchangeGUI.SERVER_RUNNING:
            if mode == "intern":
                self.urlLabel.getLabel().setFg("#365EFF")
                openWeb(FileExchangeGUI.ACTIVE_FILE_SERVER.getInternURL())
            elif mode == "extern":
                self.urlLabel2.getLabel().setFg("#365EFF")
                openWeb(FileExchangeGUI.ACTIVE_FILE_SERVER.getExternURL())
    def btnToggleServer(self, e):
        value = e.getValue()
        all_ = self.listb.getAllSlots()
        if all_ == [] and not FileExchangeGUI.SERVER_RUNNING:
            self.toggleServer.setOff()
            tk.SimpleDialog.askError(self, "Select at least one file!")
            return
        if value:
            self.startServer(all_)
        else:
            self.stopServer()
    def startServer(self, paths):
        MsgText.info("Starting fileserver...")
        FileExchangeGUI.SERVER_RUNNING = True
        FileExchangeGUI.ACTIVE_FILE_SERVER.start(paths)
        self.urlLabel.setText(FileExchangeGUI.ACTIVE_FILE_SERVER.getInternURL())
        self.urlLabel2.setText(FileExchangeGUI.ACTIVE_FILE_SERVER.getExternURL())
    def stopServer(self):
        FileExchangeGUI.SERVER_RUNNING = False
        self.urlLabel.setText("")
        self.urlLabel2.setText("")
        FileExchangeGUI.ACTIVE_FILE_SERVER.stop()
        MsgText.info("Stopping fileserver...")
    def canClose(self):
        return self.saved
    def cancelLoad(self):
        self.running = False
    def close(self):
        self._onClose()
        self.destroy()
    def _onClose(self):
        self.running = False
        #FileExchangeGUI.ACTIVE_FILE_SERVER.stop()
        FileExchangeGUI.ACTIVE_GUI = None
class FileExchangePlugin(EventHandler):
    EXT_PORT = 25565
    INT_PORT = 8000
    CONFIG = None
    def __init__(self):
        self.port_entry = None

    def openGUI(self):
        if FileExchangeGUI.ACTIVE_GUI is None:
            FileExchangeGUI(plugin.getPath())

    def onSettingsFrameConstruct(self, frame):
        self.port_ext_entry = tk.TextEntry(frame).setText("Forwarded port: ").setValue(FileExchangePlugin.CONFIG["ext_port"]).place(0, 0, 200, 25)
        self.port_int_entry = tk.TextEntry(frame).setText("Local port: ").setValue(FileExchangePlugin.CONFIG["int_port"]).place(0, 25, 200, 25)

    def onSettingsCloseEvent(self, e):
        if self.port_entry is None:
            ext_port = FileExchangePlugin.CONFIG["ext_port"]
            int_port = FileExchangePlugin.CONFIG["int_port"]
        else:
            ext_port = self.port_ext_entry.getValue()
            int_port = self.port_int_entry.getValue()
        for i, port in enumerate([ext_port, int_port]):
            port = str(port)
            if port.isnumeric():
                port = int(port)
                if port > 65535 or port < 0:
                    e.setCanceled(True)
                    tk.SimpleDialog.askError(plugin.getWindow(), f"{'Port forwarding' if i == 0 else 'Local'} port must be between 0 and 65535! not: "+str(port), f"FileExchange {VERSION}")
                    return
            else:
                e.setCanceled(True)
                tk.SimpleDialog.askError(plugin.getWindow(), f"{'Port forwarding' if i == 0 else 'Local'} port must be a number! not: " + str(port), f"FileExchange {VERSION}")
                return
        FileExchangePlugin.EXT_PORT = int(ext_port)
        FileExchangePlugin.INT_PORT = int(int_port)
        FileExchangePlugin.CONFIG["ext_port"] = int(ext_port)
        FileExchangePlugin.CONFIG["int_port"] = int(int_port)
        FileExchangePlugin.CONFIG.save()




    def onEnable(self):
        """
        This event is called by the EventHandler on startup.
        Use this event instead of the __init__ when using the 'Event API'.

        @return:
        """
        FileExchangePlugin.CONFIG = AdvancedJsonConfig("textEditorPlugin")
        FileExchangePlugin.CONFIG.setDefault({
            "ext_port":25565,
            "int_port":8000
        })
        FileExchangePlugin.CONFIG.load(CONFIG_PATH)
        FileExchangePlugin.EXT_PORT = FileExchangePlugin.CONFIG["ext_port"]
        FileExchangePlugin.INT_PORT = FileExchangePlugin.CONFIG["int_port"]

        plugin.registerTaskCommand("tools", "File Exchanger", self.openGUI)


    def onDisable(self, e):
        """
        This event is called by the EventHandler on exit.
        This can be prevented by 'e.setCanceled(True)'.
        @param e:
        @return:
        """
        if FileExchangeGUI.SERVER_RUNNING:
            anw = tk.SimpleDialog.askYesNoCancel(plugin.getWindow(), "The File-Server is still running.\nDo you want to quit before closing the PyExplorer?", f"FileExchange {VERSION}")
            if anw is None:
                e.setCanceled(True)
            elif anw:
                FileExchangeGUI.ACTIVE_FILE_SERVER.stop()

plugin = Plugin(priority=-10)
plugin.register(FileExchangePlugin)

