from PyExplorer.src.plugins import EventHandler, Event, Plugin
from pysettings.text import MsgText
from pysettings.jsonConfig import JsonConfig
from pysettings import tk
from typing import Union
import os
import threading as th

VERSION = "v1.0"
pil_supported = ["png", "jpg", "jpeg", "bmp", "gif", "ico"]

class ImageViewer(tk.Toplevel):
    def __init__(self, path=""):
        super().__init__(plugin.getWindow(), False)
        self.forceFocus()
        self.currPath = path
        self.setWindowSize(300, 300)

        self.largestSize = (1920-200, 1800-1000)
        self.minSize = (300, 300)
        self.setTitle(f"Image-Viewer {VERSION}-"+path)
        self.imageFrame = tk.Frame(self)

        self.imageLabel = tk.Label(self.imageFrame)
        self.imageLabel.setBg("green")
        self.bind(self.onStrgMouseWh, "<Control-MouseWheel>")
        self.imageLabel.bind(self.onStrgMouseWh, "<Control-MouseWheel>")

        #self.imageFrame.bind(self.save, "<Control-s>")
        self.bind(self.close, "<Escape>")

        self.taskBar = tk.TaskBar(self)
        file = self.taskBar.createSubMenu("File")
        tools = self.taskBar.createSubMenu("Tools")

        self.taskBar.create()
        self.onCloseEvent(self.onClose)

        self.imgSize = 1
        self.closed = False
        self.running = True
        self.saved = True


    def onStrgMouseWh(self, e):
        imgFaq = .1
        delta = e.getTkArgs().delta
        if str(delta).startswith("-"):
            if self.imgSize - imgFaq > 0:
                self.imgSize -= imgFaq
        else:
           self.imgSize += imgFaq
        self.image.resize(self.imgSize, True)
        self.imageLabel.place(0, 0, self.image.getWidth(), self.image.getHeight())
        self.imageLabel.setImage(self.image)
        print("faq:", self.imgSize, "-> newSize:", self.image.getWidth(), self.image.getHeight())
        self.imageFrame.updateRelativePlace()
        #self.imageLabel.updateRelativePlace()
        #self.imageFrame.updateRelativePlace()


    def canClose(self):
        return self.closed or self.saved
    def cancelLoad(self):
        self.running = False
    def onEdit(self):
        """
        if self.content != self.text.getText():
            self.setTitle(f"*Editor {VERSION}-" + self.currPath)
            self.saved = False
            """
        pass
    def onClose(self, e):
        e.setCanceled(True)
        self.running = False
        if not self.saved:
            anw = tk.SimpleDialog.askYesNoCancel(self, "There are unsaved changes on this document.\nDo you want to save them?")
            if anw:
                self.save()
                e.setCanceled(False)
                self.closed = True
            elif anw is None:
                return
            else:
                e.setCanceled(False)
                self.closed = True
        else:
            e.setCanceled(False)
            self.closed = True
    def save(self):
        self._save()
    def _save(self):

        plugin.updateActiveProperties(self.currPath)
    def open(self):
        self.running = True
        self.image = self.decodeFile(self.currPath)
        size = [0, 0]
        if self.image.getWidth() < self.largestSize[0]:
            if self.image.getWidth() < self.minSize[0]:
                size[0] = self.minSize[0]
            else:
                size[0] = self.image.getWidth()
        else:
            size[0] = self.largestSize[0]
        if self.image.getHeight() < self.largestSize[1]:
            if self.image.getHeight() < self.minSize[1]:
                size[1] = self.minSize[1]
            else:
                size[1] = self.image.getHeight()
        else:
            size[1] = self.largestSize[1]

        self.setWindowSize(*size)

        self.imageLabel.setImage(self.image)
        self.imageLabel.place(0, 0, self.image.getWidth(), self.image.getHeight())
        self.imageFrame.placeRelative()
        self.imageFrame.updateRelativePlace()

    def decodeFile(self, path)->Union[tk.PILImage, None]:
        try:
            img = tk.PILImage.loadImage(path)
            return img
        except UnicodeDecodeError:
            tk.SimpleDialog.askError("Could not load Image!\nPath: "+path)
            return None


class ImageViewerPlugin(EventHandler):
    def __init__(self):
        self.editors = []
    def onFileTreeSelectEvent(self, e):
        e = Event(e)
        if os.path.splitext(e.getPath())[1][1:] in pil_supported:
            editor = ImageViewer(e.getPath())
            th.Thread(target=editor.open).start()
            e.cancelOtherCalls(True)
    def onEnable(self):
        pass
    def onDisable(self, e):
        e.setCanceled(not all([editor.canClose() for editor in self.editors]))



plugin = Plugin(priority=-8)
plugin.register(ImageViewerPlugin)



