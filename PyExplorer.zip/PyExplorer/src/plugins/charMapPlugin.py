from PyExplorer.src.plugins import EventHandler, Event, Plugin
from pysettings.text import MsgText
from pysettings.jsonConfig import JsonConfig
from pysettings import tk
import os
import threading as th

VERSION = "v1.0"
DESCRIPTION = """This is a Plugin Template!"""

class CharMap(tk.Dialog):
    def __init__(self):
        super().__init__(plugin.getWindow(), False)
        self.forceFocus()
        self.setWindowSize(300, 300)
        self.setTitle(f"CharMap {VERSION}")


        self.mainloop()
    def test(self):
        import unicodedata

        for i in range(0, 144697):
            try:
                d = chr(i)
                print(i, chr(i), unicodedata.name(d), unicodedata.category(d))
            except:
                pass




class CharMapPlugin(EventHandler):
    def __init__(self):
        pass

    def openGUI(self):
        CharMap()

    def onEnable(self):
        """
        This event is called by the EventHandler on startup.
        Use this event instead of the __init__ when using the 'Event API'.

        @return:
        """
        plugin.registerTaskCommand("tools", "CharMap", self.openGUI)





plugin = Plugin(priority=-10)
plugin.disable()
plugin.register(CharMapPlugin)










