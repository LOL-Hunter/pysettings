from PyExplorer.src.plugins import EventHandler, Event, Plugin
from pysettings import tk
import time as t
import threading as th
from PyExplorer.src.package.widgets import CopyLabel
from pyautogui import position, pixel as getPixel, size


VERSION = "v1.0"
DESCRIPTION = """This is a simple color Picker
with pick-in-screen feature.
"""




class ColorPickerGUI(tk.Toplevel):
    ACTIVE = None
    def __init__(self):
        super().__init__(plugin.getWindow(), False)
        self.running = True
        self.scanningColors = False
        self.forceFocus()
        self.setWindowSize(300, 300)
        self.setTitle(f"Color Picker {VERSION}")
        self.onCloseEvent(self._onClose)
        self.closeViaESC()

        self.scX, self.scY = size()

        wx, wy = 450, 145

        self.savedColors = []
        self.color = [(255, 255, 255), "#ffffff"] # [(r, g, b), hex]

        self.setWindowSize(wx, wy)
        x, y = self.getScreenSize()
        self.setPositionOnScreen(x - wx-10, y - wy - 75)

        self.bind(self.onF1, tk.EventType.F1)
        self.bind(self.onF2, tk.EventType.F2)

        self.colorFrame = tk.LabelFrame(self)
        self.colorFrame.setText("Current color")
        self.colorFrame.placeRelative(stickRight=True, fixWidth=200)

        tk.Label(self.colorFrame).setText("Color:").placeRelative(fixHeight=25, xOffsetRight=60).setTextOrientation()
        self.colorLabel = tk.Label(self.colorFrame).placeRelative(fixHeight=25, fixWidth=25, xOffsetLeft=40).setStyle(tk.Style.SUNKEN)
        tk.Label(self.colorFrame).setText("Mouse pos:").placeRelative(fixY=25, fixHeight=25,xOffsetRight=60).setTextOrientation()
        self.mousePos = CopyLabel(self.colorFrame).placeRelative(fixHeight=25, fixY=25, xOffsetLeft=40, changeWidth=-5)
        tk.Label(self.colorFrame).setText("Color (hex):").placeRelative(fixY=50, fixHeight=25, xOffsetRight=60).setTextOrientation()
        self.colorHex = CopyLabel(self.colorFrame).placeRelative(fixHeight=25, fixY=50, xOffsetLeft=40, changeWidth=-5)
        tk.Label(self.colorFrame).setText("Color (rgb):").placeRelative(fixY=75, fixHeight=25, xOffsetRight=60).setTextOrientation()
        self.colorRGB = CopyLabel(self.colorFrame).placeRelative(fixHeight=25, fixY=75, xOffsetLeft=40, changeWidth=-5)
        tk.Button(self.colorFrame).setText("Save color").placeRelative(fixHeight=25, fixY=100, changeWidth=-5).setCommand(self.saveColor)

        self.nb = tk.Notebook(self)
        colorPicker = self.nb.createNewTab("Color picker")


        screenPicker = self.nb.createNewTab("Screen picker")
        self.toggleColorPicker = tk.Checkbutton(screenPicker).setText("Auto pick (F1)").placeRelative(fixY=25, fixHeight=25, changeWidth=-5).onSelectEvent(self.updateWidgets).setTextOrientation()
        tk.Label(screenPicker).setText("Pick once (F2)").placeRelative(fixHeight=25, changeWidth=-5).setTextOrientation()
        savedColors = self.nb.createNewTab("Saved colors")

        self.savedColorsW = tk.Listbox(savedColors)
        self.savedColorsW.onSelectEvent(self.selectSavedColor)
        self.savedColorsW.placeRelative()

        self.nb.onTabSelectEvent(self.onTabSelect)
        self.nb.placeRelative(changeWidth=-200)

        tk.Button(colorPicker).placeRelative().setText("Click here to pick color").setStyle(tk.Style.FLAT).setCommand(self.pickColor)

        th.Thread(target=self._update).start()
        self.show()

    def hexToRGB(self, h):
        h = str(h).replace("#", "")
        return tuple(int(h[i:i+2], 16) for i in (0, 2, 4))


    def selectSavedColor(self):
        sel = self.savedColorsW.getSelectedItem()
        if sel is None: return
        hex_ = sel
        r, g, b = self.hexToRGB(hex_)
        self.colorRGB.setText(str((r, g, b)))
        self.colorHex.setText(hex_)
        self.colorLabel.setBg(hex_)
        self.color = [(r, g, b), hex_]

    def saveColor(self):
        if self.color[1] not in self.savedColors:
            self.savedColorsW.add(self.color[1], color=self.color[1])
            self.savedColors.append(self.color[1])

    def pickColor(self):
        cp = tk.ColorChooser.askColor(self, self.colorHex.getText())
        if cp.getCanceled(): return
        hex_ = cp.getHex()
        r, g, b = cp.getRGB()
        self.colorRGB.setText(str((r, g, b)))
        self.colorHex.setText(hex_)
        self.colorLabel.setBg(hex_)
        self.color = [(r, g, b), hex_]

    def onTabSelect(self, e):
        sel = self.nb.getSelectedTabName()
        if sel is None: return
        if self.nb.getSelectedTabName() != "Screen picker":
            self.scanningColors = False
            self.toggleColorPicker.setState(False)

    def updateWidgets(self):
        if self.toggleColorPicker:
            self.scanningColors = True
        else:
            self.scanningColors = False

    def onF1(self):
        if self.nb.getSelectedTabName() == "Screen picker":
            self.toggleColorPicker.toggle()
            if self.toggleColorPicker:
                self.scanningColors = True
            else:
                self.scanningColors = False

    def onF2(self):
        if self.nb.getSelectedTabName() == "Screen picker" and not self.scanningColors:
            x, y = position()
            self.mousePos.setText(str((x, y)))
            self._updateScreenPick(x, y)

    def _updateScreenPick(self, x, y):

        if x > self.scX or y > self.scY:
            self.colorRGB.setText("Only works on first Screen!")
            self.colorHex.setText("Only works on first Screen!")
            return
        r, g, b = getPixel(x, y)
        hex_ = tk.Color.rgb(r, g, b)
        self.colorRGB.setText(str((r, g, b)))
        self.colorHex.setText(hex_)
        self.colorLabel.setBg(hex_)
        self.color = [(r, g, b), hex_]

    def _update(self):
        while True:
            x, y = position()
            self.mousePos.setText(str((x, y)))
            t.sleep(.1)
            if not self.running: return
            if not self.scanningColors: continue

            self._updateScreenPick(x, y)

    def _onClose(self):
        self.running = False
        t.sleep(.2)

class ColorPickerPlugin(EventHandler):
    def __init__(self):
        pass
    def openGUI(self):
        if not ColorPickerGUI.ACTIVE:
            ColorPickerGUI()
    
    def onEnable(self):
        """
        This event is called by the EventHandler on startup.
        Use this event instead of the __init__ when using the 'Event API'.

        @return:
        """
        plugin.registerTaskCommand("tools", "ColorPicker", self.openGUI)

    def onDisable(self, e):
        """
        This event is called by the EventHandler on exit.
        This can be prevented by 'e.setCanceled(True)'.
        @param e:
        @return:
        """



plugin = Plugin(priority=-10)
plugin.register(ColorPickerPlugin)

