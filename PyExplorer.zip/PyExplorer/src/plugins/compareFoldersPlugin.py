from PyExplorer.src.plugins import EventHandler, Event, Plugin
from pysettings.text import MsgText
from pysettings.jsonConfig import JsonConfig
from string import ascii_letters
from pysettings import tk
import os, time as t
import threading as th
from pyperclip import paste as getClip
from PyExplorer.src.images import IconHandler
from PyExplorer.src.package.misc import parseNumber, parseSize
from PyExplorer.src.settings import Settings
from PyExplorer.src.package.widgets import FileExplorerDialog

VERSION = "v1.0"
DESCRIPTION = """This is a Plugin to compare Folder contents to each other."""

class CustomTreeView(tk.TreeView):
    def __init__(self, master):
        self.master = master
        super().__init__(master)
        self.path = None
        self.selectionFrame = tk.Frame(master)
        self.closeBtn = tk.Button(master).setText("Close/Change folder").placeRelative(stickDown=True, fixHeight=25, changeY=-20, changeWidth=-5).setCommand(self.close)
        self.setTableHeaders("Name", "File-Type", "Modification-Date", "Size")
        self.emptyLabel = tk.Label(master).setText("No matches found!")
        self.onSingleSelectEvent(self.onFileTreeSingleSelectEvent)
    def close(self):
        self.closeBtn.disable()
        self.path = None
        self.renderSelection()
    def getOtherCTV(self):
        _list = CompareGUI.ACTIVE.treeViews
        index = _list.index(self)
        if index == 0: return _list[1]
        else: return _list[0]
    def onFileTreeSingleSelectEvent(self, e):
        pass
    def closeSelection(self):
        if self.selectionFrame is not None:
            self.selectionFrame.destroy()
            self.selectionFrame = None
    def renderSelection(self):
        def fromClip():
            path = getClip()
            if path is not None and os.path.exists(path):
                if os.path.isdir(path):
                    self.path = path
                else:
                    #self.master.hide()
                    if tk.SimpleDialog.askOkayCancel(CompareGUI.ACTIVE, "This is a path to a file.\nWould you like to take the path of its parent folder?", f"Compare {VERSION}"):
                        self.path = os.path.split(path)[0]
                    else:
                        return
                    self._update()
            else:
                tk.SimpleDialog.askError(CompareGUI.ACTIVE, "This path does not exist!\n'"+str(path)+"'", f"Compare {VERSION}")
        def fromTree():
            otherPath = self.getOtherCTV().path
            if otherPath is None: otherPath = "C:\\"


            paths = FileExplorerDialog.askFile(CompareGUI.ACTIVE, f"Compare {VERSION}", otherPath)
            if paths is None:
                tk.SimpleDialog.askError(CompareGUI.ACTIVE, "Choose a folder path to compare!", f"Compare {VERSION}")
                return
            path = paths[0]

            if os.path.isdir(path):
                self.path = path
            else:
                if tk.SimpleDialog.askOkayCancel(CompareGUI.ACTIVE, "This is a path to a file.\nWould you like to take the path of its parent folder?", f"Compare {VERSION}"):
                    self.path = os.path.split(path)[0]
                else:
                    return
            self._update()
        def cloneFromOtherTV():
            otherPath = self.getOtherCTV().path
            if otherPath is None:
                tk.SimpleDialog.askError(CompareGUI.ACTIVE, "Could not clone! Path from other tree view is None!", f"Compare {VERSION}")
                return
            self.path = otherPath
            self._update()
        def selectFromNotebooks():
            nbs = plugin.getWindow().notebooks
            values = [i.activeTab.path for i in nbs]
            sel = tk.SimpleDialog.chooseFromList(CompareGUI.ACTIVE, f"Compare {VERSION}", values, forceToChoose=False)
            if sel is None: return
            path = sel[0]
            if os.path.isdir(path):
                self.path = path
            else:
                if tk.SimpleDialog.askOkayCancel(CompareGUI.ACTIVE, "This is a path to a file.\nWould you like to take the path of its parent folder?", f"Compare {VERSION}"):
                    self.path = os.path.split(path)[0]
                else:
                    return
            self._update()
        def selectFromTabs():
            nbs = plugin.getWindow().notebooks
            values = []
            for nb in nbs:
                for tab in nb.tabs:
                    values.append(tab.path)

            sel = tk.SimpleDialog.chooseFromList(CompareGUI.ACTIVE, f"Compare {VERSION}", values, forceToChoose=False)
            if sel is None: return
            path = sel[0]
            if os.path.isdir(path):
                self.path = path
            else:
                if tk.SimpleDialog.askOkayCancel(CompareGUI.ACTIVE, "This is a path to a file.\nWould you like to take the path of its parent folder?", f"Compare {VERSION}"):
                    self.path = os.path.split(path)[0]
                else:
                    return
            self._update()
        self.closeSelection()
        self.clear()
        self.selectionFrame = tk.LabelFrame(self.master)
        self.selectionFrame.setText("Open folder from:")
        self.selectionFrame.placeRelative(centerX=True, centerY=True, fixWidth=200, fixHeight=170-25)
        tk.Button(self.selectionFrame).setText("Select Tab...").placeRelative(fixHeight=25, fixY=0, changeWidth=-5).attachToolTip("Select from open tabs in the PyExplorer.").setCommand(selectFromTabs)
        tk.Button(self.selectionFrame).setText("Select Notebook...").placeRelative(fixHeight=25, fixY=25, changeWidth=-5).attachToolTip("Select from open notebooks in the PyExplorer.\nAnd take their active tab.").setCommand(selectFromNotebooks)
        tk.Button(self.selectionFrame).setText("Select Folder...").placeRelative(fixHeight=25, fixY=50, changeWidth=-5).attachToolTip("Select folder from selection.").setCommand(fromTree)
        tk.Button(self.selectionFrame).setText("Clone from other View").placeRelative(fixHeight=25, fixY=75, changeWidth=-5).attachToolTip("Clones the path from the other compare view treeview.").setCommand(cloneFromOtherTV)
        tk.Button(self.selectionFrame).setText("Take path from Clip").placeRelative(fixHeight=25, fixY=100, changeWidth=-5).attachToolTip("Use path in clipboard.").setCommand(fromClip)
    def updateFileTree(self, pathList, selectAll=False, pg=None):
        if self.path is None:
            self.closeBtn.disable()
            self.renderSelection()
            return
        else:
            self.closeBtn.enable()
            self.closeSelection()

        self.clear()

        if len(pathList) == 0:
            self.emptyLabel.placeRelative(centerY=True, centerX=True, fixWidth=110, fixHeight=25)
            return
        else:
            self.emptyLabel.placeForget()

        #pathList = CompareGUI.ACTIVE.updateCompare()
        try:
            for i, file in enumerate(pathList):
                if not CompareGUI.ACTIVE.running: return
                if pg is not None: pg.addValue()
                if os.path.isdir(os.path.join(self.path, file)): #folder
                    if Settings.fileCheck(file): continue
                    self.addEntry(file, "Folder", t.ctime(os.path.getmtime(os.path.join(self.path, file))), "", image=IconHandler.getFolderIcon())#self._getSizeDir(path)
                elif os.path.islink(os.path.join(self.path, file)): #ref
                    self.addEntry(os.path.splitext(os.path.join(self.path, file))[0], "Reference", t.ctime(os.path.getmtime(os.path.join(self.path, file))), parseSize(os.path.getsize(os.path.join(self.path, file))), image=IconHandler.getReferenceIcon())
                elif os.path.isfile(os.path.join(self.path, file)): #file
                    if Settings.fileCheck(file): continue
                    ext = os.path.splitext(file)[1]
                    self.addEntry(file, os.path.splitext(file)[1], t.ctime(os.path.getmtime(os.path.join(self.path, file))), parseSize(os.path.getsize(os.path.join(self.path, file))), image=IconHandler.getIconFromExtention(ext))
                else:
                    continue
            if selectAll:
                self.clearSelection()
                for i in range(self.getSize()):
                    self.setItemSelectedByIndex(i, False)
        except PermissionError as e:
            pass
    def _update(self):
        CompareGUI.ACTIVE.updateCompare()
class CompareGUI(tk.Dialog):
    STATES = []
    PATH1 = None
    PATH2 = None
    ACTIVE = None
    def __init__(self):
        super().__init__(plugin.getWindow(), False)
        CompareGUI.ACTIVE = self
        self.forceFocus()
        self.onCloseEvent(self.onClose)
        self.setWindowSize(1000, 600, True)
        self.setTitle(f"Compare {VERSION}")
        self.onWindowResize(self.onRelUpdate)

        self.closed = False
        self.running = True
        self.saved = True

        self.createGUI()
        self.show()
        self.chooseTargets()

        self.displayMode = "same" # all, same, diff
        self.equalMode = "exact" # exact, letters, size
        self.typeMode = "all"    # all, files, folders
        self.ignoreCase = True

        self.treeViews = [self.treeView1, self.treeView2]
        self.updateGUI()
        self.updateCompare()

    def getMatches(self, path1, path2):
        path1_ = path1.copy()
        path2_ = path2.copy()

        out = []
        diff1 = []
        diff2 = []

        if self.ignoreCase:
            path1_ = [i.lower() for i in path1_]
            path2_ = [i.lower() for i in path2_]
        if self.equalMode == "exact":
            for item in path1_:
                if not self.running: return []
                if item in path2_:
                    out.append(path1[path1_.index(item)])
                else:
                    diff1.append(path1[path1_.index(item)])
            for item in path2_:
                if not self.running: return []
                if item not in path1_:
                    diff2.append(path2[path2_.index(item)])
        elif self.equalMode == "letters":
            def _pre(_path, _out):
                for _item in _path:
                    _item_name, _ext = os.path.splitext(_item)
                    _new_name = ""
                    for _char in _item_name:
                        if _char in ascii_letters:
                            _new_name += _char
                    _out.append(_new_name + _ext)
            path1__ = []
            path2__ = []
            _pre(path1_, path1__)# filter all != ascii_letters
            _pre(path2_, path2__)

            for item in path1__:
                if not self.running: return []
                if item in path2__:
                    out.append(path1[path1__.index(item)])
                else:
                    diff1.append(path1[path1__.index(item)])
            for item in path2__:
                if not self.running: return []
                if item not in path1__:
                    diff2.append(path2[path2__.index(item)])
        elif self.equalMode == "size":
            return [], [], []

        return out, diff1, diff2

    def getPgDialog(self)->(tk.Progressbar, tk.Dialog):
        def close():
            self.running = False
            t.sleep(.1)
            self.destroy()
        dialog = tk.Dialog(self)
        #dialog.onCloseEvent(close)
        dialog.setWindowSize(200, 60)
        tk.Label(dialog).setText("Loading content...").placeRelative(fixHeight=25, fixX=0)
        pg = tk.Progressbar(dialog)
        pg.placeRelative(changeWidth=-20, changeX=+10, fixHeight=25, fixY=30)
        dialog.show()
        return pg, dialog
    def addToViews(self, v1=None, v2=None):
        def reduce(v:list, base:str):
            _v = []
            if self.typeMode == "folders":
                for i in v:
                    if os.path.isdir(os.path.join(base, i)):
                        _v.append(i)
            elif self.typeMode == "files":
                for i in v:
                    if not os.path.isdir(os.path.join(base, i)):
                        _v.append(i)
            else:
                return v.copy()
            return _v
        all_ = []
        if v1 is not None:
            v1 = reduce(v1, self.treeView1.path)
            all_.extend(v1)

        if v2 is not None:
            v2 = reduce(v2, self.treeView1.path)
            all_.extend(v2)

        dialog = None
        pg=None
        if len(all_) > 25:
            pg, dialog = self.getPgDialog()
            pg.setValues(len(all_))
        if v1 is not None:
            self.amount1L.setText(str(len(v1)))
            self.treeView1.updateFileTree(v1, pg=pg)
        else:
            self.amount1L.setText("0")
        if v2 is not None:
            self.amount2L.setText(str(len(v2)))
            self.treeView2.updateFileTree(v2, pg=pg)
        else:
            self.amount2L.setText("0")

        if dialog is not None: dialog.destroy()

    def updateCompare(self):
        path1, path2 = self.treeView1.path, self.treeView2.path

        if path1 is not None and path2 is not None:
            self.frame1.setText(path1)
            self.frame2.setText(path2)
            listDir1 = os.listdir(path1)
            listDir2 = os.listdir(path2)
            matches, diff1, diff2= self.getMatches(listDir1, listDir2)

            self.matchesL.setText(f"Matches: {parseNumber(len(matches))}")

            if self.displayMode == "all":
                self.addToViews(os.listdir(path1), os.listdir(path2))
            elif self.displayMode == "same":
                self.addToViews(matches, matches)
            elif self.displayMode == "diff":
                self.addToViews(diff1, diff2)


        else: # render all
            if path1 is not None:
                self.frame1.setText(path1)
                self.treeView1.updateFileTree(os.listdir(path1))
            else:
                self.frame1.setText("Empty")
                self.treeView1.renderSelection()
            if path2 is not None:
                self.frame1.setText(path2)
                self.treeView1.updateFileTree(os.listdir(path2))
            else:
                self.frame2.setText("Empty")
                self.treeView2.renderSelection()
            self.matchesL.setText("Matches: ")

    def onDirChange(self):
        pass
    def onRelUpdate(self):
        width, height = self.getWindowSize()
        self.frame1.place(0, 0, int((width-200)/2), height)
        self.frame2.place(int((width-200)/2), 0, int((width-200)/2), height)

        self.updateDynamicWidgets()
    def createGUI(self):
        self.frame1 = tk.LabelFrame(self)
        self.frame1.setText("Empty1")
        self.frame2 = tk.LabelFrame(self)
        self.frame2.setText("Empty2")

        self.toolsFrame = tk.LabelFrame(self)
        self.toolsFrame.setText("Tools")
        self.toolsFrame.placeRelative(fixWidth=200, stickRight=True, fixX=0)

        self.treeView1 = CustomTreeView(self.frame1)
        self.treeView1.placeRelative(changeWidth=-5, changeHeight=-45)
        self.treeView2 = CustomTreeView(self.frame2)
        self.treeView2.placeRelative(changeWidth=-5, changeHeight=-45)

        lf1 = tk.LabelFrame(self.toolsFrame)
        lf1.setText("Show matches:")
        lf1.placeRelative(fixHeight=95, changeWidth=-5) # -20


        self.displayModeRB = tk.Radiobutton(lf1)
        self.displayModeRB.createNewRadioButton().setText("Show all").placeRelative(changeWidth=-5, fixHeight=25, fixY=0).setTextOrientation(tk.Anchor.LEFT)
        self.displayModeRB.createNewRadioButton().setText("Show all same").placeRelative(changeWidth=-5, fixHeight=25, fixY=25).setTextOrientation(tk.Anchor.LEFT).setSelected()
        self.displayModeRB.createNewRadioButton().setText("Show all different").placeRelative(changeWidth=-5, fixHeight=25, fixY=50).setTextOrientation(tk.Anchor.LEFT)
        self.displayModeRB.onSelectEvent(self.updateGUI)

        lf2 = tk.LabelFrame(self.toolsFrame)
        lf2.setText("Match type:")
        lf2.placeRelative(fixHeight=95+25, changeWidth=-5, fixY=95)

        self.equalModeRB = tk.Radiobutton(lf2)
        self.equalModeRB.createNewRadioButton().setText("Exact match").placeRelative(changeWidth=-5, fixHeight=25, fixY=0).setTextOrientation(tk.Anchor.LEFT)
        self.equalModeRB.createNewRadioButton().setText("Letters only").placeRelative(changeWidth=-5, fixHeight=25, fixY=25).setTextOrientation(tk.Anchor.LEFT)
        self.equalModeRB.createNewRadioButton().setText("Match size").placeRelative(changeWidth=-5, fixHeight=25, fixY=50).setTextOrientation(tk.Anchor.LEFT)
        self.equalModeRB.onSelectEvent(self.updateGUI)
        self.ignoreCaseCB = tk.Checkbutton(lf2).setSelected().setText("Ignore case").placeRelative(changeWidth=-5, fixHeight=25, fixY=75).setTextOrientation(tk.Anchor.LEFT)
        self.ignoreCaseCB.onSelectEvent(self.updateGUI)

        lf3 = tk.LabelFrame(self.toolsFrame)
        lf3.setText("Filter:")
        lf3.placeRelative(fixHeight=95, changeWidth=-5, fixY=95*2+25)

        self.typeModeRB = tk.Radiobutton(lf3)
        self.typeModeRB.createNewRadioButton().setText("Show all").placeRelative(changeWidth=-5, fixHeight=25, fixY=0).setTextOrientation(tk.Anchor.LEFT).setSelected()
        self.typeModeRB.createNewRadioButton().setText("Only files").placeRelative(changeWidth=-5, fixHeight=25, fixY=25).setTextOrientation(tk.Anchor.LEFT)
        self.typeModeRB.createNewRadioButton().setText("Only folders").placeRelative(changeWidth=-5, fixHeight=25, fixY=50).setTextOrientation(tk.Anchor.LEFT)
        self.typeModeRB.onSelectEvent(self.updateGUI)

        lf4 = tk.LabelFrame(self.toolsFrame)
        lf4.setText("Info:")
        lf4.placeRelative(fixHeight=95+25, changeWidth=-5, fixY=95*3+25)

        self.matchesL = tk.Label(lf4).setText("Matches: ").placeRelative(changeWidth=-5, fixHeight=25, fixY=0).setTextOrientation(tk.Anchor.LEFT)
        tk.Label(lf4).setText("Items: (View1/View2)").placeRelative(changeWidth=-5, fixHeight=25, fixY=50).setTextOrientation(tk.Anchor.LEFT)
        self.amount1L = tk.Label(lf4).setText("0").placeRelative(fixHeight=25, fixY=75, xOffsetRight=50).setTextOrientation(tk.Anchor.LEFT)
        self.amount2L = tk.Label(lf4).setText("0").placeRelative(changeWidth=-5, fixHeight=25, fixY=75, xOffsetLeft=50).setTextOrientation(tk.Anchor.LEFT)


        self.onRelUpdate()
    def updateGUI(self):
        def indexToStr(i:int, l:list):
            return l[i]
        self.displayMode = indexToStr(self.displayModeRB.getState(), ["all", "same", "diff"])
        self.typeMode = indexToStr(self.typeModeRB.getState(), ["all", "files", "folders"])
        self.equalMode = indexToStr(self.equalModeRB.getState(), ["exact", "letters", "size"])
        self.ignoreCase = bool(self.ignoreCaseCB.getState())

        self.updateCompare()
    def chooseTargets(self):
        win = plugin.getWindow()
        if CompareGUI.PATH1 is not None and CompareGUI.PATH2 is not None:
            if tk.SimpleDialog.askOkayCancel(self, f"Do you want to load last session?\n- {CompareGUI.PATH1}\n- {CompareGUI.PATH2}", f"Compare {VERSION}"):
                self.treeView1.path = CompareGUI.PATH1
                self.treeView2.path = CompareGUI.PATH2
                widgets = [self.displayModeRB,
                          self.typeModeRB,
                          self.equalModeRB,
                          self.ignoreCaseCB
                          ]
                for widget, state in zip(widgets, CompareGUI.STATES):
                    widget.setState(state)
                return
        self.treeView1.path = win.activeNotebook.activeTab.path
        if len(win.notebooks) == 2:
            if tk.SimpleDialog.askOkayCancel(self, f"Would you like to compare the open Notebooks?\n- {win.notebooks[0].activeTab.path}\n- {win.notebooks[1].activeTab.path}", f"Compare {VERSION}"):
                self.treeView1.path = win.notebooks[0].activeTab.path
                self.treeView2.path = win.notebooks[1].activeTab.path

        # debug temp
        #self.treeView1.path = r"C:\Users\langh\Documents\curseforge\Instances\Vault Hunters - Official Modpack\mods"
        #self.treeView2.path = r"C:\Users\langh\Documents\curseforge\Instances\Vault Hunters - Official Modpack (1)\mods"


        #tk.SimpleDialog.chooseFromList(self, f"Compare {VERSION}", values=[], chooseOnlyOne=False)
    def canClose(self):
        return self.closed or self.saved
    def cancelLoad(self):
        self.running = False
    def onClose(self, e):
        self.running = False
        if self.treeView1.path is not None and self.treeView2.path is not None:
            CompareGUI.PATH1 = self.treeView1.path
            CompareGUI.PATH2 = self.treeView2.path
            CompareGUI.STATES = [
                self.displayModeRB.getState(),
                self.typeModeRB.getState(),
                self.equalModeRB.getState(),
                self.ignoreCaseCB.getState()
            ]
        else:
            CompareGUI.PATH1 = None
            CompareGUI.PATH2 = None
        t.sleep(.1)
        CompareGUI.ACTIVE = None
class ComparePlugin(EventHandler):
    def __init__(self):
        pass
    def openGUI(self):
        CompareGUI()
    def onFileTreeSelectEvent(self, e):
        """
        This event is called by the EventHandler if the user opens a file in the Explorer.
        @param e:
        @return:
        """
    def onEnable(self):
        """
        This event is called by the EventHandler on startup.
        Use this event instead of the __init__ when using the 'Event API'.

        @return:
        """
        plugin.registerTaskCommand("tools", "Compare...", self.openGUI)
    def onDisable(self, e):
        """
        This event is called by the EventHandler on exit.
        This can be prevented by 'e.setCanceled(True)'.
        @param e:
        @return:
        """
        #e.setCanceled()
        pass

plugin = Plugin(priority=-10)
plugin.register(ComparePlugin)

