from PyExplorer.src.plugins import EventHandler, Event, Plugin
{{imports}}

VERSION = {{version}}
DESCRIPTION = {{description}}

{{gui}}

class {{name}}(EventHandler):
    def __init__(self):
        pass
    {{events}}
    def onEnable(self):
        """
        This event is called by the EventHandler on startup.
        Use this event instead of the __init__ when using the 'Event API'.

        @return:
        """
    def onDisable(self, e):
        """
        This event is called by the EventHandler on exit.
        This can be prevented by 'e.setCanceled(True)'.
        @param e:
        @return:
        """





plugin = Plugin(priority=-10){{disable}}
plugin.register({{name}})

