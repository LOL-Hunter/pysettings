from PyExplorer.src.plugins import EventHandler, Event, Plugin
from pysettings.text import MsgText
from pysettings.jsonConfig import JsonConfig
from pysettings import tk
import os
import threading as th

VERSION = "v1.0"
DESCRIPTION = """
This is a Plugin Template!


"""

class TextEditor(tk.Toplevel):
    def __init__(self, path=""):
        super().__init__(plugin.getWindow(), False)
        self.forceFocus()
        self.setWindowSize(300, 300)
        self.setTitle(f"Editor {VERSION}-"+path)


        self.closed = False
        self.running = True
        self.saved = True


        self.mainloop()

    def canClose(self):
        return self.closed or self.saved
    def cancelLoad(self):
        self.running = False
    def onClose(self, e):
        self.running = False




class Template(EventHandler):
    def __init__(self):
        pass

    def onFileTreeSelectEvent(self, e):
        """
        This event is called by the EventHandler if the user opens a file in the Explorer.
        @param e:
        @return:
        """

    def onEnable(self):
        """
        This event is called by the EventHandler on startup.
        Use this event instead of the __init__ when using the 'Event API'.

        @return:
        """
    def onDisable(self, e):
        """
        This event is called by the EventHandler on exit.
        This can be prevented by 'e.setCanceled(True)'.
        @param e:
        @return:
        """
        #e.setCanceled()
        pass





plugin = Plugin(priority=-10)
plugin.disable() # to temporarily disable the plugin
plugin.register(Template)

