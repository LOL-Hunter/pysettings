class GUI(tk.Toplevel):
    def __init__(self):
        super().__init__(plugin.getWindow(), {{top}})
        self.forceFocus()
        self.setWindowSize(300, 300)
        self.setTitle(f"Editor {VERSION}-"){{onClose1}}{{closeESC}}

        self.closed = False
        self.running = True
        self.saved = True


        self.mainloop()

    def canClose(self):
        return self.closed or self.saved
    def cancelLoad(self):
        self.running = False{{onClose2}}