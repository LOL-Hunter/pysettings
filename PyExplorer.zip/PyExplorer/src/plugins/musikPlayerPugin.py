from PyExplorer.src.plugins import EventHandler, Event, Plugin
from pysettings.text import MsgText
from pysettings.jsonConfig import JsonConfig
from pysettings import tk
import os
import threading as th
VERSION = "v1.0"
import pygame.mixer as mixer
import os

mixer.init()






BASE_PATH = os.path.join(os.getcwd(), "Plugins") if not os.getcwd().endswith("Plugins") else os.getcwd()
IMG_PLAY = tk.PILImage.loadImage(os.path.join(BASE_PATH, "Icons", "musicPlayer", "play.png")).resizeTo(50, 50).preRender()
IMG_PAUSE = tk.PILImage.loadImage(os.path.join(BASE_PATH, "Icons", "musicPlayer", "pause.png")).resizeTo(50, 50).preRender()
IMG_SKIP_FORWARD = tk.PILImage.loadImage(os.path.join(BASE_PATH, "Icons", "musicPlayer", "skip_forward.png")).resizeTo(50, 50).preRender()
IMG_SKIP_BACKWARD = tk.PILImage.loadImage(os.path.join(BASE_PATH, "Icons", "musicPlayer", "skip_backward.png")).resizeTo(50, 50).preRender()
IMG_VOLUME_1 = tk.PILImage.loadImage(os.path.join(BASE_PATH, "Icons", "musicPlayer", "volume_low.png")).resizeTo(50, 50).preRender()
IMG_VOLUME_2 = tk.PILImage.loadImage(os.path.join(BASE_PATH, "Icons", "musicPlayer", "volume_medium.png")).resizeTo(50, 50).preRender()
IMG_VOLUME_3 = tk.PILImage.loadImage(os.path.join(BASE_PATH, "Icons", "musicPlayer", "volume_loud.png")).resizeTo(50, 50).preRender()
IMG_SHUFFLE = tk.PILImage.loadImage(os.path.join(BASE_PATH, "Icons", "musicPlayer", "shuffle.png")).resizeTo(50, 50).preRender()


class MusicPlayer(tk.Toplevel):
    def __init__(self, path=""):
        super().__init__(plugin.getWindow(), False)
        self.forceFocus()
        self.currPath = path
        self.setWindowSize(500, 300)
        #self.setResizeable()
        self.setTitle(f"MusicPlayer {VERSION}-"+path)
        self.bind(self.close, "<Escape>")
        self.bind(self.play, "<space>")

        self.taskBar = tk.TaskBar(self)
        file = self.taskBar.createSubMenu("File")
        tools = self.taskBar.createSubMenu("Tools")


        self.taskBar.create()

        self.skipBack = tk.Button(self).setImage(IMG_SKIP_BACKWARD).place(250 - 100, 200, 50, 50)
        self.playBtn = tk.Button(self).setImage(IMG_PLAY).place(250 - 25, 200, 50, 50).setCommand(self.play)
        self.skipForw = tk.Button(self).setImage(IMG_SKIP_FORWARD).place(250 + 50, 200, 50, 50)

        self.prog = tk.Label(self).setText("0.00/0.00").place(0, 150)

        self.bar = tk.Scale(self)
        self.bar.setValueVisible(False)
        self.bar.setSliderWidth(10)
        self.bar.place(60, 150, 380, 50)

        self.onCloseEvent(self.onClose)

        self.playing = False
        self.openFile = None
        self.closed = False
        self.running = True
        self.saved = True
        self.sound = None
        th.Thread(target=self.update_).start()
        self.mainloop()

    def parseToMin(self, sec):
        minutes = 0
        hour = 0
        if sec == 0: return "0.00"
        if sec / 60 >= 1:
            minutes += int(sec / 60)
            sec %= 60
            if minutes / 60 >= 1:
                hour += int(minutes / 60)
                minutes %= 60
                return f"{'0' + str(hour) if sec < 10 else hour}:{'0' + str(minutes) if minutes < 10 else minutes}:{'0' + str(sec) if sec < 10 else sec}"
            else:
                return f"{'0' + str(minutes) if minutes < 10 else minutes}:{'0' + str(sec) if sec < 10 else sec}"
        else:
            return f"0:{'0' + str(sec) if sec < 10 else sec}"





    def update_(self):
        while True:
            if self.sound is None: continue
            sec = mixer.music.get_pos()/1000
            self.bar.setValue((sec/self.sound.get_length())*100)
            self.prog.setText(f"{self.parseToMin(int(sec))}/{self.parseToMin(int(self.sound.get_length()))}")
            self.update()


    def play(self):
        if self.playing:
            self.playBtn.setImage(IMG_PLAY)
            mixer.music.pause()
            self.playing = False
        else:
            self.playBtn.setImage(IMG_PAUSE)
            mixer.music.unpause()
            self.playing = True

    def canClose(self):
        return self.closed or self.saved
    def cancelLoad(self):
        self.running = False
    def onEdit(self):
        pass
    def onClose(self, e):
        self.running = False
        mixer.music.stop()

    def open(self):
        self.running = True
        try:
            mixer.music.load(self.currPath)
            self.sound = mixer.Sound(self.currPath)
            mixer.music.play()
            mixer.music.pause()
        except Exception as e:
            self.openFile = None
            tk.SimpleDialog.askError(self, f"Could not load Audiofile!\n{str(e)}")
            return


class MusicPlayerPlugin(EventHandler):
    def __init__(self):
        self.editors = []
    def onFileTreeSelectEvent(self, e):
        if os.path.splitext(e.getPath())[1] in [".mp3", ".ogg", ".wav"]:
            e = Event(e)
            editor = MusicPlayer(e.getPath())
            th.Thread(target=editor.open).start()
            e.cancelOtherCalls(True)
    def onEnable(self):
        return
        editor = MusicPlayer("C:\Robert\Musik\Sonne-Rammstein\Sonne-Rammstein.mp3")
        th.Thread(target=editor.open).start()
    def onDisable(self, e):
        e.setCanceled(not all([editor.canClose() for editor in self.editors]))



plugin = Plugin(priority=-7)
plugin.register(MusicPlayerPlugin)

if __name__ == '__main__':
    MusicPlayer("C:\Robert\Musik\Sonne-Rammstein\Sonne-Rammstein.mp3").open()


