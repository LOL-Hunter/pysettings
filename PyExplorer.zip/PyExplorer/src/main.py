import os, sys
os.chdir(os.path.split(__file__)[0])
from pysettings.text import Title, TextColor
from PyExplorer.src.gui import Window, VERSION


class Main:
    def __init__(self, argv, master="Tk"):
        Title().print("PyExplorer", "green")
        TextColor.print(f"version: {VERSION}", "cyan")

        Window(argv, master)


if __name__ == '__main__':
    Main(sys.argv)