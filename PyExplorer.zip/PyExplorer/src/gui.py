import os, re, time as t
import threading as th
from typing import Union
from PIL import ExifTags

from send2trash import send2trash
from shutil import copy as sh_copy
from pyperclip import copy as copyToClip, paste as getClip
from webbrowser import open as  openInBrowser
from string import ascii_letters

from pysettings import tk
from pysettings import iterDict, ID
from pysettings.text import MsgText, TextColor
from pysettings.geometry import Location2D, Rect

from PyExplorer.src.images import IconHandler
from PyExplorer.src.settings import Settings, WindowStyle
from PyExplorer.src.configLoader import Config
from PyExplorer.src.package.misc import parseNumber, parseSize, parseTime, copy, pil_supported
from PyExplorer.src.pluginManager import PluginManager, PluginManagerGUI
from PyExplorer.src.package.system import Memory
from PyExplorer.src.package.widgets import PathCompleterEntry, CopyWindow, DragLabel
from PyExplorer.src.package.pathTools import FileIndexer, History as TreeHistory

"""
==todos==
-treeview scrollbar
-reload Keybinds after change in settings

-zip support
-delete files

-backupList
-timer

-overlay
-menu on screen
"""

BASE_PATH = os.getcwd()
VERSION = "2.1.4"

class SearchHandler:
    def __init__(self, slf):
        self.slf = slf
        self.running = True
    def start(self):
        self.running = True
        th.Thread(target=self._run).start()

        return self
    def stop(self):
        self.running = False
    def _run(self):
        updateTimer = t.time()
        dots = 3
        def updateSearch():
            nonlocal updateTimer, dots
            if t.time() - updateTimer >= 1:
                updateTimer = t.time()
                if dots >=3:
                    dots=1
                else:
                    dots += 1
                self.slf.searchInfo1.setText("searching: " + path + "."*dots)

        if not self.running:
            return
        else:
            path = self.slf.path

            self.isIgnoreCase = self.slf.isIgnoreCase
            self.searchMode = self.slf.searchMode # in file or in folder
            self.searchWord = self.slf.searchWord # word to search after
            if self.searchWord == "":
                self.slf.isSearching = False
                self.slf.searchBtn.setText("Search")
                return
            else:
                self.slf.searchInfo1.setText("searching: " + path + "...")
                self.slf.isSearching = True
            if ":" in self.searchWord:
                mode, self.searchWord = self.searchWord.split(":")
                if mode.lower() in self.slf.searchForModes:
                    mode = mode.lower()
                else:
                    if self.searchMode == "name":
                        self.slf.isSearching = False
                        self.slf.searchBtn.setText("Search")
                        tk.SimpleDialog.askError(Window.WINDOW, f"Mode {mode} does not exist! Try using the 'Search for:' dropdown to select the mode!", "Search")
                        return
            else: mode = "all"



        try:
            _files = 0
            _folders = 0
            found = []
            timer = t.time()
            offset = 0
            for root, dirs, files in os.walk(path):
                if mode not in ["file", "files"] or self.searchMode == "inFiles":
                    for folder in dirs:
                        updateSearch()
                        _folders +=1
                        if self.searchMode == "name":
                            searchWord = self.searchWord
                            if self.isIgnoreCase:
                                searchWord = self.searchWord.lower()
                                folder = folder.lower()

                            if searchWord in folder:
                                found.append(os.path.join(root, folder))
                if mode not in ["folder", "folders"] or self.searchMode == "inFiles":
                    for file in files:
                        updateSearch()
                        _files+=1
                        if not self.running:
                            return
                        if self.searchMode == "inFiles":
                            _found = []
                            try:
                                _file = open(os.path.join(root, file), "rb")
                                content = _file.read().decode("utf-8", "ignore")
                                _file.close()
                                for lnr, line in enumerate(content.splitlines()):
                                    if self.searchWord in line:
                                        for i in [m.start() for m in re.finditer(self.searchWord, line)]:
                                            _found.append(f"   line:{lnr}|col:{i} '{line}'")
                                if len(_found) > 0:
                                    offset+=1
                                    found.append(f"({len(_found)})|"+os.path.join(root, file))
                                    found.extend(_found)

                            except PermissionError as e:
                                print("no permission")
                        elif self.searchMode == "name":
                            searchWord = self.searchWord
                            if self.isIgnoreCase:
                                searchWord = self.searchWord.lower()
                                file = file.lower()
                            if searchWord in file and not Settings.fileCheck(file):
                                found.append(os.path.join(root, file))

            self.slf.isSearching = False
            self.slf.searchBtn.setText("Search")
            self.slf.searchInfo2Left.setText("Found: " + parseNumber(len(found)-offset))
            _mode = ""
            _num = 0
            match mode:
                case "all":
                    _mode = "items"
                    _num = _files
                case "file" | "files":
                    _mode = "files"
                    _num = _files
                case "folder" | "folders":
                    _mode = "folders"
                    _num = _folders
            self.slf.searchInfo1.setText(f"Searched {parseNumber(_num)} {_mode} in {parseTime(t.time()-timer)} sek.")
            self.slf.result.addAll(found)
        except Exception as e:
            raise e
            pass
class PreviewRenderer:
    def __init__(self, slf):
        self.slf = slf
        self.running = True
    def start(self):
        self.running = True
        th.Thread(target=self._run).start()
        return self
    def stop(self):
        self.running = False
    def _run(self):
        if not self.running:
            return
        else:
            path = self.slf.path
            self.slf.isRendering = True
        try:
            file = open(path, "rb")
            content = file.read()
            file.close()
            content = content.decode("utf8", "ignore")
            lines = len(content.splitlines())
            self.slf.lines = parseNumber(lines)
            self.slf._place()
            c = 0
            for i, line in enumerate(content.splitlines()):
                if not self.running:
                    if not self.slf.info2["tkMaster"]["destroyed"]:
                        self.slf.info2.setText("")
                    return
                self.slf.text.addLine(line)
                if c > 9:
                    c=0
                    self.slf.info2.setText("Rendering: "+str(int(round((i/lines)*100, 0)))+"%")
                    self.slf.frame["tkMaster"].update()
                c+=1
            self.slf.isRendering = False
            self.slf._place()
        except PermissionError as e:
           MsgText.error(f"permission Error while opening {path}")

class InfoTab:
    def __init__(self, slf):
        self.slf = slf
        self.running = False
        self.slf.__class__._PROP.append(self)
    def stopThread(self):
        self.running = False
        t.sleep(.01)
        self.running = True
    def render(self):
        for i in self.slf.__class__._PROP:
            i.destroy()
        self.slf.frame.placeRelative()
        self.slf.__class__._ACTIVE = self
        Window.WINDOW.updateDynamicWidgets()
    def destroy(self):
        self.stopThread()
        self.slf.__class__._ACTIVE = None
        self.slf.frame.placeForget()
class SearchTab(InfoTab):
    _ACTIVE = None
    _PROP = []
    def __init__(self, fileTab, master):
        self.path = None
        self.fileTab = fileTab
        self.frame = tk.Frame(master)
        super().__init__(self)

        self.isIgnoreCase = True
        self.searchMode = "name"
        self.isSearching = False
        self.oldSearchThread = None
        self.searchWord = ""
        self.isMenuOpen = False
        self.oldUserInput = ""

        self.textEntry = tk.LabelFrame(self.frame)
        self.textEntry.placeRelative(fixX=0, fixY=0, fixHeight=50+5)
        tk.Label(self.textEntry).setText("Search: ").placeRelative(fixWidth=50, fixHeight=25)
        self.entry = tk.Entry(self.textEntry)
        self.entry.bind(self.search, "<Return>")
        self.entry.onUserInputEvent(self.onUserInput)
        self.entry.placeRelative(fixX=50, fixHeight=25, changeWidth=-50)
        self.searchBtn = tk.Button(self.textEntry).setCommand(self.searchButton).setText("Search").placeRelative(fixY=0, fixHeight=25, fixWidth=50, changeWidth=-5, stickRight=True)
        self.radioSIF = tk.Radiobutton(self.textEntry)
        self.radioSIF.onSelectEvent(self.update)
        self.searchInFiles = self.radioSIF.createNewRadioButton().setTextOrientation(tk.Anchor.LEFT)
        self.searchName = self.radioSIF.createNewRadioButton().setTextOrientation(tk.Anchor.LEFT).setSelected()
        self.searchInFiles.setText("Search in Files")
        self.searchName.setText("Search by Name")

        self.ignoreCase = tk.Checkbutton(self.textEntry).setTextOrientation(tk.Anchor.LEFT)
        self.ignoreCase.setText("Ignore Case")
        self.ignoreCase.onSelectEvent(self.update)
        self.ignoreCase.setSelected()


        self.searchForLabel = tk.Label(self.textEntry).setText("Search for: ")
        self.searchForModes = ["all", "file", "files", "folder", "folders"]
        self.searchForModesW = ["all", "file", "folder"]
        self.searchFor = tk.DropdownMenu(self.textEntry).setOptionList(self.searchForModesW)
        self.searchFor.onSelectEvent(self.update)
        self.searchFor.setText("all")
        self.searchFor.setReadOnly()

        self.searchInfo1 = tk.Label(self.textEntry)
        self.searchInfo1.setTextOrientation(tk.Anchor.LEFT)

        self.searchInfo2Left = tk.Label(self.textEntry)
        self.searchInfo2Left.setTextOrientation(tk.Anchor.LEFT)

        self.searchInfo2Right = tk.Label(self.textEntry)
        self.searchInfo2Right.setTextOrientation(tk.Anchor.LEFT)

        self.infoOpenButton = tk.Button(self.textEntry)
        self.infoOpenButton.setText("▽")
        self.infoOpenButton.setCommand(self.openInfo)

        self.result = tk.Listbox(self.frame).attachVerticalScrollBar(tk.ScrollBar(self.frame))
        self.result.bindArrowKeys()
        self.result.bindArrowKeys(widget=self.entry)
        self.result.bind(self._openFile, tk.EventType.DOUBBLE_LEFT)
        self.result.onSelectEvent(self.onListBoxSelect)

        self.infoCloseButton = tk.Button(self.textEntry)
        self.infoCloseButton.setText("△")
        self.infoCloseButton.setCommand(self.closeInfo)

        self.context = tk.ContextMenu(self.result)
        tk.Button(self.context).setText("open").setCommand(self._openFile)
        tk.Button(self.context).setText("copy path").setCommand(self._copy)


        self.context.create()

        self._place()
    def _openFile(self):
        sel = self.result.getSelectedItem()
        if sel is None: return
        PluginManager.call("onFileTreeSelectEvent", path=sel)
    def _copy(self):
        sel = self.result.getSelectedItem()
        if sel is None: return
        copy(sel)
    def _place(self):
        if self.isMenuOpen:
            self.infoOpenButton.placeForget()
            self.textEntry.placeRelative(fixX=0, fixY=0, yOffsetDown=50)

            self.searchInfo1.placeRelative(fixY=25, fixHeight=25, stickDown=True, changeY=-25)
            self.searchInfo2Left.placeRelative(fixY=50, fixHeight=25, xOffsetRight=50, changeWidth=-25, stickDown=True)
            self.searchInfo2Right.placeRelative(fixY=50, xOffsetLeft=50, fixHeight=25, changeX=25, changeWidth=-5, stickDown=True)

            self.searchName.placeRelative(fixY=25, fixHeight=25, changeWidth=-5)
            self.searchInFiles.placeRelative(fixY=50, fixHeight=25, changeWidth=-5)
            self.ignoreCase.placeRelative(fixY=75, fixHeight=25, changeWidth=-5)

            self.searchForLabel.placeRelative(fixY=100, fixHeight=25, changeWidth=-5, xOffsetRight=50)
            self.searchFor.placeRelative(fixY=100, fixHeight=25, changeWidth=-5, xOffsetLeft=50)


            self.infoCloseButton.placeRelative(stickDown=True, centerX=True, fixHeight=20, fixWidth=50, changeY=-5)
            self.result.placeRelative(yOffsetUp=50)

        else:
            self.searchFor.placeForget()
            self.searchForLabel.placeForget()
            self.searchInFiles.placeForget()
            self.searchName.placeForget()
            self.ignoreCase.placeForget()
            self.infoCloseButton.placeForget()
            self.searchInfo1.placeRelative(fixY=25, fixHeight=25)
            self.searchInfo2Left.placeRelative(fixY=50, fixHeight=25, xOffsetRight=50, changeWidth=-25)
            self.searchInfo2Right.placeRelative(fixY=50, xOffsetLeft=50, fixHeight=25, changeX=25, changeWidth=-5)
            self.textEntry.placeRelative(fixX=0, fixY=0, fixHeight=75 + 5)
            self.infoOpenButton.placeRelative(centerX=True, fixY=51, fixHeight=20, fixWidth=50)
            self.result.placeRelative(fixY=75 + 5)
    def onListBoxSelect(self, e):
        value = e.getValue()
        if value is not None:
            if "|" in value:
                value = value.split("|")[1]
            sub, this = os.path.split(value)
            self.fileTab.updateFileTree(sub, mark=this)
    def openInfo(self):
        self.isMenuOpen = True
        self._place()
    def closeInfo(self):
        self.isMenuOpen = False
        self._place()
    def update(self, e):
        value = self.entry.getValue()
        newMode = self.searchFor.getValue()
        if ":" in value:
            mode, word = value.split(":")
        else:
            word = value
        if newMode == "all":
            self.entry.setText(word)
        else:
            self.entry.setText(newMode+":"+word)

        self.isIgnoreCase = self.ignoreCase.getState()
        d = {"0":"inFiles", "1":"name"}
        self.searchMode = d[str(self.radioSIF.getState())]



    def onUserInput(self, e):
        value = self.entry.getValue()

        if value.count(":") > 1:
            value = value[:-1]
            self.entry.setText(value)
        if ":" not in value:
            self.searchFor.setText("all")
        else:
            mode, word = value.split(":")
            mode = mode.lower()
            if mode in self.searchForModes:
                if mode.endswith("s"): mode = mode[:-1] # files -> file
                self.searchFor.setText(mode)
            else:
                self.searchFor.setText("all")



        if e.getTkArgs().keysym == "Return": return
        if self.oldSearchThread is not None: self.oldSearchThread.stop()
        self.searchBtn.setText("Search")
        self.searchInfo1.setText("")
        self.searchInfo2Left.setText("")
        self.searchInfo2Right.setText("")
        self.oldUserInput = value
    def searchButton(self):
        if self.isSearching:
            self.searchBtn.setText("Search")
            self.isSearching = False
            if self.oldSearchThread is not None: self.oldSearchThread.stop()
            self.searchInfo1.setText("")
            self.searchInfo2Left.setText("")
            self.searchInfo2Right.setText("")
        else:
            self.search()
    def search(self):
        self.searchWord = self.entry.getValue()
        self.path = self.fileTab.path
        if self.path is not None:
            self.searchBtn.setText("Cancel")
            self.isSearching = True
            self.result.clear()
            if self.oldSearchThread is not None: self.oldSearchThread.stop()
            self.oldSearchThread = SearchHandler(self).start()
    def stopThread(self):
        self.isSearching = False
        if self.oldSearchThread is not None: self.oldSearchThread.stop()
class PropertiesTab(InfoTab):
    _ACTIVE = None
    _PROP = []
    def __init__(self, fileTab, master):
        self.frame = tk.Frame(master)
        self.fileTab = fileTab
        self.path = None
        super().__init__(self)

        self.couldNotLoad = None

        self.old_prev = None
        self.old_ind = None

        self.isRendering = False
        self.isInfoOpen = False
        self.isFastRender = True
        self.pdfLabel = None
        self.image = None
        self.imgRes = None
        self.largeImgPrev = False

        self.lines = None
        self.folders = None
        self.files = None
        self.size = None

        self.mode = "file"

        self.text = tk.Text(master, scrollAble=True, readOnly=True)
        self.text.setWrapping(tk.Wrap.NONE)
        self.textSize = 10
        self.text.setFont(10)
        self.text.bind(self.onStrgMouseWh, "<Control-MouseWheel>")

        self.rcMenu = tk.ContextMenu(self.text)
        tk.Button(self.rcMenu).setText("Copy").setCommand(self.textBoxMenu, args=["copy"])
        tk.Button(self.rcMenu).setText("open URL").setCommand(self.textBoxMenu, args=["openWb"])
        tk.Button(self.rcMenu).setText("search with GOOGLE").setCommand(self.textBoxMenu, args=["google"])
        self.rcMenu.create()


        self.infoFrame = tk.LabelFrame(self.frame)

        self.infoOpenButton = tk.Button(self.infoFrame)
        self.infoOpenButton.setText("▽")
        self.infoOpenButton.setCommand(self.openInfo)

        self.info1 = tk.Label(self.infoFrame)
        self.info1.setTextOrientation(tk.Anchor.LEFT)

        self.info2 = tk.Label(self.infoFrame)
        self.info2.setTextOrientation(tk.Anchor.LEFT)

        self.info3 = tk.Label(self.infoFrame)
        self.info3.setTextOrientation(tk.Anchor.LEFT)

        self.info4 = tk.Label(self.infoFrame)
        self.info4.setTextOrientation(tk.Anchor.LEFT)

        self.info5 = tk.Label(self.infoFrame)
        self.info5.setTextOrientation(tk.Anchor.LEFT)

        self.info6 = tk.Label(self.infoFrame)
        self.info6.setTextOrientation(tk.Anchor.LEFT)

        self.infos = [self.info1, self.info2, self.info3, self.info4, self.info5, self.info6]

        self.advancedImageInfo = tk.Button(self.infoFrame)
        self.advancedImageInfo.setText("Advanced image info")
        self.advancedImageInfo.setCommand(self.showAdvancedImageInfo)

        self.fastRender = tk.Checkbutton(self.infoFrame)
        self.fastRender.setText("FastRender")
        self.fastRender.setTextOrientation(tk.Anchor.LEFT)
        self.fastRender.setSelected()
        self.text.setFont(50)
        self.fastRender.onSelectEvent(self.onFastRenderCheck)

        self.infoCloseButton = tk.Button(self.infoFrame)
        self.infoCloseButton.setText("△")
        self.infoCloseButton.setCommand(self.closeInfo)

        self.imageLabel = tk.Label(self.frame).setBg("white")
        self.imageLabel.bind(self.toggleLargePrev, tk.EventType.LEFT_CLICK)
        self.imageLabel.bind(self.onImageLabelChangeSize, tk.EventType.CUSTOM_RELATIVE_UPDATE)

        self.largeImgaeLabel = tk.Label(Window.WINDOW).setBg("white")
        self.largeImgaeLabel.bind(self.toggleLargePrev, tk.EventType.LEFT_CLICK)
        self.largeImgaeLabel.bind(self.toggleLargePrev, tk.EventType.ESC)
        self.largeImgaeLabel.bind(self.onImageLabelChangeSize, tk.EventType.CUSTOM_RELATIVE_UPDATE)

        self._place()
    def textBoxMenu(self, e):
        args = e.getArgs(0)
        selected = self.text.getSelectedText()
        if selected is None: return
        if args == "copy":
            copyToClip(selected)
        elif args == "openWb":
            openInBrowser(selected.strip())
        elif args == "google":
            openInBrowser(f"https://www.google.com/search?q={selected.strip()}")
    def toggleLargePrev(self, e):
        if self.mode != "file:img": return
        self.largeImgPrev = not self.largeImgPrev

        if self.largeImgPrev:
            Window.CANCEL_RESIZE = True
            self.largeImgaeLabel.placeRelative()
            self.largeImgaeLabel.lift()
            self.largeImgaeLabel.updateRelativePlace()
        else:
            Window.CANCEL_RESIZE = False
            self.largeImgaeLabel.placeForget()
            Window.WINDOW.updateFileTreePlace()
    def onImageLabelChangeSize(self, e):
        e = tk.Event(e)
        if self.image is None or e.getValue() is None: return
        y, x, width, height = e.getValue()
        if width < 0 or height < 0: return
        labelRect = Rect.fromLocWidthHeight(Location2D(0, 0), width, height)
        self.imageRect = Rect.fromLocWidthHeight(Location2D(0, 0), self.image.getWidth(), self.image.getHeight())
        self.imageRect.resizeToRectWithRatio(labelRect)
        self.image.resizeTo(self.imageRect.getWidth(), self.imageRect.getHeight())
        if self.largeImgPrev:
            self.largeImgaeLabel.setImage(self.image)
            self.largeImgaeLabel.setFocus()
        else:
            self.imageLabel.setImage(self.image)
    def openInfo(self, e):
        self.isInfoOpen = True
        self._place()
    def closeInfo(self, e):
        self.isInfoOpen = False
        self._place()
    def clearInfo(self):
        for info in self.infos: info.setText("")
    def showAdvancedImageInfo(self):
        _master = tk.Dialog(Window.WINDOW, False)
        _master.setTitle("Image Exif-Tags " + Window.TITLE)
        _master.setResizeable(False)
        _master.setWindowSize(400, 400)

        text = tk.Text(_master, readOnly=True)
        text.placeRelative()
        data = self.image._getPIL().getexif()
        if data != {}:
            for k, v in iterDict(data):
                #if k in ExifTags.TAGS:
                    text.addLine(f"{k}: {v}")
        else:
            tk.Label(_master).setText("This image has no EXIF tags.").placeRelative()
        _master.show()
    def _place(self):
        for info in self.infos: info.setText("")
        self.advancedImageInfo.placeForget()
        self.info1.placeRelative(fixY=0, fixHeight=25, xOffsetRight=50)
        self.info2.placeRelative(fixY=0, fixHeight=25, changeWidth=-5, xOffsetLeft=50)

        self.info3.placeRelative(fixY=25, fixHeight=25, xOffsetRight=50)
        self.info4.placeRelative(fixY=25, fixHeight=25, changeWidth=-5, xOffsetLeft=50)

        if self.isInfoOpen: #open
            self.info5.placeRelative(fixY=50, fixHeight=25, xOffsetRight=50)
            self.info6.placeRelative(fixY=50, fixHeight=25, changeWidth=-5, xOffsetLeft=50)

            self.infoOpenButton.placeForget()
            self.infoFrame.placeRelative(fixHeight=150)

            self.infoCloseButton.placeRelative(stickDown=True, centerX=True, fixHeight=20, fixWidth=50, changeY=-7)

            placeWidget = {"fixY":155}

            if self.mode == "file":
                self.imageLabel.placeForget()
                if not self.isFastRender or (self.isFastRender and not self.isRendering):
                    self.text.setFont(self.textSize)
                    self.text.placeRelative(**placeWidget)
                else:
                    self.text.placeForget()
                    self.text.setFont(50)
                if self.lines is not None: self.info1.setText("Lines: " + self.lines)
                if self.size is not None: self.info3.setText("Size: " + self.size)
                self.fastRender.placeRelative(fixY=75, fixHeight=25, xOffsetRight=50)
            elif self.mode == "file:img":  # img
                self.fastRender.placeForget()
                self.text.placeForget()
                self.imageLabel.placeRelative(**placeWidget)
                self.advancedImageInfo.placeRelative(fixY=75, fixHeight=25, changeWidth=-5)

                if self.imgRes is not None:
                    self.info1.setText("Resolution:")
                    self.info2.setText(self.imgRes)
                if self.size is not None: self.info3.setText("Size: " + self.size)
            elif self.mode == "file:pdf":  # pdf
                self.fastRender.placeForget()
                self.text.placeForget()
                self.imageLabel.placeForget()

                if self.pdfLabel is not None:
                    self.pdfLabel.placeRelative(**placeWidget)
                if self.size is not None: self.info3.setText("Size: " + self.size)
            elif self.mode == "folder":
                self.imageLabel.placeRelative(**placeWidget)
                if self.folders is None:
                    self.info1.setText("indexing...")
                self.fastRender.placeForget()
                self.text.placeForget()
                if self.folders is not None: self.info2.setText("Folders: "+self.folders)
                if self.files is not None: self.info1.setText("Files: "+self.files)
                if self.size is not None: self.info3.setText("Size: " + self.size)
            elif self.mode == "none":
                self.fastRender.placeForget()
                self.imageLabel.placeForget()
                self.text.placeForget()
        else: #close
            self.info5.placeForget()
            self.info6.placeForget()
            self.fastRender.placeForget()
            self.infoFrame.placeRelative(fixY=0, fixHeight=80)
            self.infoCloseButton.placeForget()
            self.infoOpenButton.placeRelative(centerX=True, fixHeight=20, fixY=50, fixWidth=50)

            placeWidget = {"fixY":85}
            if self.mode == "file":
                self.imageLabel.placeForget()
                if not self.isFastRender or (self.isFastRender and not self.isRendering):
                    self.text.setFont(self.textSize)
                    self.text.placeRelative(**placeWidget)
                else:
                    self.text.placeForget()
                    self.text.setFont(50)
                if self.lines is not None: self.info1.setText("Lines: " + self.lines)
                if not self.isRendering:
                    self.info2.setText("")
                if self.size is not None: self.info3.setText("Size: " + self.size)
            elif self.mode == "file:exe":
                self.imageLabel.placeForget()
                self.text.placeForget()
                if self.lines is not None: self.info1.setText("Lines: " + self.lines)
                if self.lines is not None: self.info3.setText("Size: " + self.size)
            elif self.mode == "file:img":
                self.text.placeForget()
                self.imageLabel.placeRelative(**placeWidget)
                if self.imgRes is not None:
                    self.info1.setText("Resolution:")
                    self.info2.setText(self.imgRes)
                if self.size is not None: self.info3.setText("Size: " + self.size)
            elif self.mode == "file:pdf":
                self.text.placeForget()
                self.imageLabel.placeForget()
                if self.pdfLabel is not None:
                    self.pdfLabel.placeRelative(**placeWidget)
                if self.size is not None: self.info3.setText("Size: " + self.size)
            elif self.mode == "folder":
                self.imageLabel.placeRelative(**placeWidget)
                if self.folders is None:
                    self.info1.setText("indexing...")
                self.fastRender.placeForget()
                self.text.placeForget()
                if self.folders is not None: self.info2.setText("Folders: "+self.folders)
                if self.files is not None: self.info1.setText("Files: "+self.files)
                if self.size is not None: self.info3.setText("Size: " + self.size)
            elif self.mode == "none":
                self.fastRender.placeForget()
                self.imageLabel.placeForget()
                self.text.placeForget()
        if self.couldNotLoad:
            self.info1.setText("Could not")
            self.info3.setText("load data!")
    def onFastRenderCheck(self, e):
        self.isFastRender = self.fastRender.getValue()
        self._place()
    def onStrgMouseWh(self, e):
        delta = e.getTkArgs().delta
        if str(delta).startswith("-"):
            if self.mode == "file":
                if self.textSize > 1:
                    self.textSize -= 1
            elif self.mode == "file:img":
                pass
        else:
            if self.mode == "file":
                self.textSize += 1
            elif self.mode == "file:img":
                pass
        self.text.setFont(self.textSize)
    def clearProperties(self):
        self.mode = "none"
        self.stopThread()
        self._place()
    def updateProperties(self, path):
        def update():
            self.size = parseSize(self.old_ind.getSize())
            self.folders = parseNumber(self.old_ind.getFolders())
            self.files = parseNumber(self.old_ind.getFiles())
            self._place()
        self.path = path
        self.text.placeForget()
        self.imageLabel.placeForget()
        self.stopThread() # test
        self.couldNotLoad = None
        if os.path.isfile(path):
            _path, ext = os.path.splitext(path)
            if ext.replace(".", "") in pil_supported:
                self.imgRes = None
                self.stopThread()
                self.mode = "file:img" #Image
                try:
                    self.image = tk.PILImage.loadImage(path)
                except:
                    self.couldNotLoad = True
                    self._place()
                    return
                self.imgRes = str(self.image.getWidth())+"x"+str(self.image.getHeight())
                self._place()
                self.imageLabel.updateRelativePlace()
            elif ext == ".pdf":
                self.mode = "file:pdf"
                #self.pdfLabel = tk.PDFViewer(self.infoFrame, path)
                self._place()
            elif ext == ".exe":
                self.mode = "file:exe"
                _exe = open(self.path, "rb")
                self.lines = parseNumber(len(_exe.read().splitlines()))
                self.size = parseSize(os.path.getsize(self.path))
                _exe.close()

                self._place()
            else:
                self.mode = "file"
                self.lines = None

                self.text.clear()
                self.stopThread()
                self.info1.setText("indexing...")
                self.old_prev = PreviewRenderer(self).start()
                self.old_ind = FileIndexer(self.path, sysFiles=Settings.get("show_system_files", False), hiddenFiles=Settings.get("show_hidden_files", True))
                self.old_ind.onFinish(update)
                self.old_ind.start()
        else:
            self.stopThread()
            self.files = None
            self.size = None
            self.folders = None
            self.mode = "folder"

            self.info1.setText("indexing...")
            self.old_ind = FileIndexer(self.path, sysFiles=Settings.get("show_system_files", False), hiddenFiles=Settings.get("show_hidden_files", True))
            self.old_ind.onFinish(update)
            self.old_ind.start()

            self.image = IconHandler.getNavigationIcon("temp_folder").clone(True)
            self.imgRes = str(self.image.getWidth())+"x"+str(self.image.getHeight())
            self._place()
            self.imageLabel.updateRelativePlace()
    def stopThread(self):
        self.isRendering = False
        if self.old_prev is not None:
            self.old_prev.stop()
            self.old_prev = None
        if self.old_ind is not None:
            self.old_ind.stop()
            self.old_ind = None
    def destroy(self):
        #if self.old_ind is not None:
            #self.info1.clear()
        super().destroy()

class CustomTab:
    def __init__(self, notebook, **kwargs):
        self.plugin = None
        self.frame: tk.NotebookTab = notebook.createNewTab("")
    def onTabSelect(self):
        pass
    def onTabUnselect(self):
        pass
    def updateWidgetSize(self):
        pass

class FileTab:
    def __init__(self, path, notebook, highlight=None):
        self.history = TreeHistory(path)
        self.lastClickOnFile = (t.time()*2, None)# (lastTime, path)
        self.path = path
        self.notebook:FileNotebook = notebook
        if PropertiesTab._ACTIVE is not None: PropertiesTab._ACTIVE.destroy()
        if SearchTab._ACTIVE is not None: SearchTab._ACTIVE.destroy()
        self.search = SearchTab(self, Window.WINDOW.search)
        self.search.render()
        self.properties = PropertiesTab(self, Window.WINDOW.properties)
        self.properties.render()
        self.frame:tk.NotebookTab = notebook.createNewTab("")
        self.fileTree = tk.TreeView(self.frame)
        self.fileTree.setMultipleSelect()
        self.fileTree.setTableHeaders("Name", "File-Type", "Modification-Date", "Size")
        self.fileTree.onSingleSelectEvent(self.onFileTreeSingleSelectEvent)
        self.fileTree.onArrowKeySelectEvent(self.onArrowSelect)

        self.fileTree.bind(self.onLClickMotionEvent, tk.EventType.MOTION_WITH_LEFT_CLICK)
        self.fileTree.bind(self.onLClickReleaseEvent, tk.EventType.LEFT_CLICK_RELEASE)
        self.fileTree.bind(self.onFileTreeReturnEvent, tk.EventType.RETURN)
        self.fileTree.bind(self.hotkey_esc, tk.EventType.ESC)

        self.fileTree.bind(self.backward, Settings.getKeyBind("filetree_backward"))
        self.fileTree.bind(self.backward, tk.EventType.MOUSE_PREV)
        self.fileTree.bind(self.forward, Settings.getKeyBind("filetree_forward"))
        self.fileTree.bind(self.forward, tk.EventType.MOUSE_NEXT)

        self.fileTree.bind(self.showParentDir, Settings.getKeyBind("filetree_dir_up"))
        self.fileTree.bind(self.hotkey_strgA, Settings.getKeyBind("filetree_selectAll"))
        self.fileTree.bind(self.context_openInWin, Settings.getKeyBind("filetree_openInWin"))

        self.fileTree.bind(self.context_rename, Settings.getKeyBind("rename"))
        self.fileTree.bind(self.context_delete, Settings.getKeyBind("delete"))
        self.fileTree.bind(self.context_duplicate, Settings.getKeyBind("duplicate"))
        self.fileTree.bind(self.context_copy, Settings.getKeyBind("copy"))
        self.fileTree.bind(self.context_cut, Settings.getKeyBind("cut"))
        self.fileTree.bind(self.context_paste, Settings.getKeyBind("paste"))
        self.fileTree.bind(self.onKey, tk.EventType.ALL_KEYS)

        self.fileTree.setFocus()
        self.fileTree.placeRelative(yOffsetUp=10, fixY=25, changeX=-1)
        self.cEntry = PathCompleterEntry(self.frame)

        self.cEntry.onUserInputEvent(self.onUserInputEvent)
        self.cEntry.onSelectEvent(self.onCEntrySelectEvent)

        self.cEntry.placeRelative(yOffsetUp=90, fixY=0, fixHeight=25)

        self.infoLabel = tk.Label(self.frame).setBg("white")

        self.fileContext = tk.ContextMenu(self.fileTree)
        tk.Button(self.fileContext).setText("Copy").setCommand(self.context_copy)
        tk.Button(self.fileContext).setText("Copy Path").setCommand(self.context_copyPath)
        tk.Button(self.fileContext).setText("Cut").setCommand(self.context_cut)
        tk.Button(self.fileContext).setText("Paste").setCommand(self.context_paste)
        tk.Button(self.fileContext).setText("Duplicate").setCommand(self.context_duplicate)
        tk.Button(self.fileContext).setText("Rename").setCommand(self.context_rename)
        tk.Button(self.fileContext).setText("Delete").setCommand(self.context_delete)
        self.fileContext.addSeparator()
        tk.Button(self.fileContext).setText("Open").setCommand(self.context_open)
        tk.Button(self.fileContext).setText("Open with").setCommand(self.context_openWith)
        tk.Button(self.fileContext).setText("Open in new Tab").setCommand(self.context_openInNewTab)
        tk.Button(self.fileContext).setText("Open in new Notebook").setCommand(self.context_openInNewNotebook)
        tk.Button(self.fileContext).setText("Open in Windows-Explorer").setCommand(self.context_openInWin)
        self.fileContext.addSeparator()
        new = self.fileContext.createSubMenu(tk.Button(self.frame).setText("New"))
        tk.Button(self.fileContext).setText("Add to Favorites").setCommand(self.context_addFavorites)
        tk.Button(new).setText("File").setCommand(self.context_createNewFile, args=["file"])
        tk.Button(new).setText("Folder").setCommand(self.context_createNewFile, args=["folder"])
        tk.Button(new).setText("zip-File").setCommand(self.context_createNewFile, args=[".zip"])
        new.addSeparator()
        for name in Config.NEW_FILE_CONFIG.keys():
            ext = Config.NEW_FILE_CONFIG[name][0] if Config.NEW_FILE_CONFIG[name][0].startswith(".") else "."+Config.NEW_FILE_CONFIG[name][0]
            tk.Button(new).setText(name).setCommand(self.context_createNewFile, args=[ext])

        self.fileContext.create()

        self.oldPath = "C:\\"
        self.isFileTreeInForeground = False
        self.isDraggingFile = False
        self.dragMode = None # none, copy, move, ref
        self._oldDragMode = ""
        self._oldKeyStates = [False, False, False]
        self.nbUnderCursor = None
        self._oldNbUnderCursor = None
        self.dragLabel = None
        self.draggingPath = None
        self.renameTask = None
        self.isQuickSearch = False
        self.quickSearchWidget = tk.Entry(self.frame)
        self.quickSearchWidget.bind(self.hotkey_esc, tk.EventType.ESC)
        self.quickSearchWidget.bind(self.onFileTreeReturnEvent, tk.EventType.RETURN)
        self.fileTree.onArrowKeySelectEvent(self.onArrowSelect, bindToOtherWidget=self.quickSearchWidget)
        self.quickSearchWidget.onUserInputEvent(self.updateQuickSearch)

        self.updateFileTree(path, mark=highlight)
    def getSelectedItemsAsPath(self):
        selected = self.fileTree.getSelectedItems()
        if selected is None: return []
        return [os.path.join(self.path, i["Name"]) for i in selected]
    def updateFileTree(self, path=".", mark:Union[list, str]=None, selectAll=False, showList=None):
        if not mark is None:
            mark = [mark] if isinstance(mark, str) else mark
            mark = [os.path.split(i)[1] for i in mark]
        else: mark = []

        if path == "%drives%":
            pass
        else:
            if path == ".":
                path = self.path
            if os.path.exists(path):
                self.frame.setTabName(os.path.split(path)[1] if os.path.split(path)[1] != "" else os.path.split(path)[0])
                Window.WINDOW.statusBar.clearInfo()
                self.path = path
                self.cEntry.setValue(self.path)
                self.fileTree.clear()
                highlight = []
                try:
                    offset = 0

                    _list = os.listdir(path)
                    if showList is not None:
                        _list = showList

                    for i, file in enumerate(_list):
                        if Settings.fileCheck(file): offset += 1

                        if file in mark:
                            highlight.append(i-offset)
                        if os.path.isdir(os.path.join(path, file)): #folder
                            if Settings.fileCheck(file): continue
                            self.fileTree.addEntry(file, "Folder", t.ctime(os.path.getmtime(os.path.join(path, file))), "", image=IconHandler.getFolderIcon())#self._getSizeDir(path)
                        elif os.path.islink(os.path.join(path, file)): #ref
                            self.fileTree.addEntry(os.path.splitext(os.path.join(path, file))[0], "Reference", t.ctime(os.path.getmtime(os.path.join(path, file))), parseSize(os.path.getsize(os.path.join(path, file))), image=IconHandler.getReferenceIcon())
                        elif os.path.isfile(os.path.join(path, file)): #file
                            ext = os.path.splitext(file)[1]
                            if Settings.fileCheck(file): continue
                            self.fileTree.addEntry(file, os.path.splitext(file)[1], t.ctime(os.path.getmtime(os.path.join(path, file))), parseSize(os.path.getsize(os.path.join(path, file))), image=IconHandler.getIconFromExtention(ext))
                        else:
                            print("SPECIAL: "+os.path.join(path, file))
                            if Settings.get("show_system_files", False):
                                self.fileTree.addEntry(os.path.splitext(file)[0], "_Special".upper(), t.ctime(os.path.getmtime(os.path.join(path, file))), parseSize(os.path.getsize(os.path.join(path, file))), image=IconHandler.getFileIcon())
                    if highlight:
                        self.fileTree.clearSelection()
                        ind = -1
                        Window.WINDOW.statusBar.setInfo(f"{len(highlight)} item{'s' if len(highlight) > 1 else ''} selected")
                        for ind in highlight:
                            self.fileTree.setItemSelectedByIndex(ind, False)
                        if ind >= 0: self.fileTree.see(ind)
                    if selectAll:
                        self.fileTree.clearSelection()
                        for i in range(self.fileTree.getSize()):
                            self.fileTree.setItemSelectedByIndex(i, False)
                        Window.WINDOW.statusBar.setInfo(f"{self.fileTree.getSize()} item{'s' if self.fileTree.getSize()>1 else ''} selected")
                    if self.fileTree.length() == 0:
                        if not self.isQuickSearch:
                            self.infoLabel.setText("This folder is empty!")
                        else:
                            self.infoLabel.setText("Nothing found!")
                        self.infoLabel.placeRelative(fixHeight=25, fixWidth=120, centerX=True, fixY=100)
                    else:
                        self.infoLabel.placeForget()

                except PermissionError as e:
                    self.infoLabel.setText("Permission denied!")
                    self.infoLabel.placeRelative(fixHeight=25, fixWidth=120, centerX=True, fixY=100)
                    self._permissionError(e, path)
            else:
                MsgText.error(f"Error while updating fileTree: path does not exist. {path}")

    def context_copy(self):
        sel = self.fileTree.getSelectedItems()
        if sel is None: return
        Window.WINDOW.statusBar.setTimedStatus(f"{len(sel)} file{'s' if len(sel)>1 else ''} copied!", 1)
        copyToClip("|".join([os.path.join(self.path, i["Name"]) for i in sel])) # copys only in settings set Paths (maybe not hidden/sys files)
    def context_copyPath(self):
        selected = self.getSelectedItemsAsPath()
        if not selected or len(selected) != 1: return
        Window.WINDOW.statusBar.setTimedStatus(f"Path copied!", 1)
        selected = selected[0]
        copyToClip(selected)
    def context_cut(self):
        pass
    def context_paste(self):

        clip = getClip()
        if clip is None: return
        if "|" in clip:
            clip = clip.split("|")
        else:
            if not os.path.exists(clip): return
            clip = [clip]
        CopyWindow(Window.WINDOW, clip, self.path).open()
        self.updateFileTree(mark=clip)

    def context_duplicate(self):
        selected = self.getSelectedItemsAsPath()
        if not selected or len(selected) != 1: return
        selected = selected[0]
        if os.path.isdir(selected):
            type_ = "folder"
        else:
            type_ = "file"

        while True:
            name = tk.SimpleDialog.askString(Window.WINDOW, "New name:", Window.TITLE, initialValue=os.path.split(selected)[1])

            if name is None:  # 'CANCEL'
                return

            if not self._checkFileName(name, selected): continue

            path = os.path.join(self.path, name)
            if os.path.exists(path):
                if not tk.SimpleDialog.askOkayCancel(Window.WINDOW, f"This {type_} already exists!\nDo you want to change the Name?"):
                    return
            else:
                break
        sh_copy(selected, os.path.join(self.path, name))
        self.updateFileTree()
    def context_rename(self):
        #TODO: rename multiple files
        selected = self.getSelectedItemsAsPath()
        if not selected or len(selected) != 1: return
        selected = selected[0]

        if os.path.isdir(selected):
            type_ = "folder"
        else:
            type_ = "file"

        while True:
            name = tk.SimpleDialog.askString(Window.WINDOW, "Rename:", Window.TITLE, initialValue=os.path.split(selected)[1])

            if name is None:  # 'CANCEL'
                return

            if not self._checkFileName(name, selected): continue

            path = os.path.join(self.path, name)
            if os.path.exists(path):
                if not tk.SimpleDialog.askOkayCancel(Window.WINDOW, f"This {type_} already exists!\nDo you want to change the Name?", Window.TITLE):
                    return
            else:
                break
        os.rename(selected, os.path.join(self.path, name))
        self.updateFileTree(mark=os.path.join(self.path, name))
        self.properties.updateProperties(os.path.join(self.path, name))
    def context_delete(self):
        selected = self.getSelectedItemsAsPath()
        if not selected: return
        if Settings.get("ask_before_delete", std=True):
            anw = tk.SimpleDialog.askYesNo(self.frame, f"Are you sure you want to delete this Path{'s' if len(selected)>1 else ''}? "+"\n".join([i for i in selected]), Window.TITLE) #("File" if os.path.isdir(self.selectedFilePath) else "File")
            if anw:
                CopyWindow(Window.WINDOW, selected, "trash").open()

                """for file in selected:
                    send2trash(file)"""
        self.updateFileTree()

    def context_open(self):
        pass
    def context_openWith(self):
        pass
    def context_openInNewTab(self):
        sel = self.getSelectedItemsAsPath()
        if not sel:  # nothing selected -> take folder path
            sel = self.path
        else:
            sel = sel[0]
        if os.path.isdir(sel):
            Window.WINDOW.newTab(sel)
        else:
            Window.WINDOW.openFile(sel)
    def context_openInNewNotebook(self):
        sel = self.getSelectedItemsAsPath()
        if not sel:  # nothing selected -> take folder path
            sel = self.path
        else:
            sel = sel[0]

        if os.path.isdir(sel):
            Window.WINDOW.newNotebook(sel)
        else:
            Window.WINDOW.openFile(sel)
    def context_openInWin(self):
        if os.path.exists(self.path):
            os.popen("start explorer " + self.path)

    def context_createNewFile(self, e):
        if isinstance(e, tk.Event):
            e = tk.Event(e)
            args = e.getArgs(0)
        else:
            args = e
        type_ = "file"
        if args == "file":
            _title = "New-File"
        elif args == "folder":
            type_ = "folder"
            _title = "New-Folder"
        elif args == "ref":
            _title = f"New-Reference"

        else:
            args = "."+args if not args.startswith(".") else args
            _title = f"New-{args.replace('.', '')}-File"
        while True:
            name = tk.SimpleDialog.askString(Window.WINDOW, _title)

            if name is None: #'CANCEL'
                return

            if name == "":
                tk.SimpleDialog.askError(Window.WINDOW, f"The {type_} name cannot be empty!", Window.TITLE)
                continue

            if len(name) > 255:
                tk.SimpleDialog.askError(Window.WINDOW, f"This {type_} name is too long!\n{len(name)} > 255", Window.TITLE)
                continue

            if any([i in r'|/\*?"<>:' for i in name]):
                tk.SimpleDialog.askError(Window.WINDOW, f'This {type_} name contains invalid characters!\n|/\*?"<>:', Window.TITLE)
                continue
            path = os.path.join(self.path, name)
            if os.path.exists(path):
                if not tk.SimpleDialog.askOkayCancel(Window.WINDOW, f"This {type_} already exists!\nDo you want to change the Name?", Window.TITLE):
                    return
            else:
                break

        if args.startswith("."):
            if not name.endswith(args):
                name = name + args
        if type_ == "folder":
            os.mkdir(os.path.join(self.path, name))
        else:
            open(os.path.join(self.path, name), "w").close()

        self.updateFileTree(mark=os.path.join(self.path, name))
        self.properties.updateProperties(os.path.join(self.path, name))
    def context_addFavorites(self, e):
        Window.WINDOW.favorites.openGUI(self.path)

    def moveFile(self, from_, to_):
        cw = CopyWindow(Window.WINDOW, from_, to_)
        th.Thread(target=cw.open).start()
    def newRef(self, from_, to_):
        fileName = os.path.splitext(os.path.split(from_)[1])[0]
        file = open(os.path.join(to_, fileName+".ref.py"), "w")
        file.write(f"PATH = '{from_}'\n")
        file.write(f"from PyExplorer.src.main import Main\n")
        file.write(f"import sys\n")
        file.write(f"sys.argv.append(PATH)\n")
        file.write(f"Main(sys.argv)")
        file.close()

    def hotkey_strgA(self):
        self.updateFileTree(selectAll=True)
    def hotkey_esc(self):
        if self.isQuickSearch:
            self.closeQuickSearch()
        elif self.isDraggingFile:
            self.onLClickReleaseEvent() # stop dragging
        else:
            Window.WINDOW.statusBar.clearInfo()
            self.properties.clearInfo()
            self.fileTree.clearSelection()

    def hotkey_f5(self):
        self.updateFileTree(self.path)

    def _checkFileName(self, name, type_):
        if name == "":
            tk.SimpleDialog.askError(Window.WINDOW, f"The {type_} name cannot be empty!", Window.TITLE)
            return False

        if len(name) > 255:
            tk.SimpleDialog.askError(Window.WINDOW, f"This {type_} name is too long!\n{len(name)} > 255", Window.TITLE)
            return False

        if any([i in r'|/\*?"<>:' for i in name]):
            tk.SimpleDialog.askError(Window.WINDOW, f'This {type_} name contains invalid characters!\n|/\*?"<>:', Window.TITLE)
            return False
        return True

    def forward(self):
        self.history.forward()
        self.updateFileTree(self.history.get())
    def backward(self):
        self.history.backward()
        self.updateFileTree(self.history.get())

    def updateDragImage(self):
        """
        updates the whole Label

        @return:
        """
        if not self.isDraggingFile: return
        if self._oldNbUnderCursor == self.nbUnderCursor:
            if [Window.WINDOW.isKey_ALT, Window.WINDOW.isKey_STRG, Window.WINDOW.isKey_SHIFT] == self._oldKeyStates: return
        self._updateDragImageType()
        self._updateDragImage()
        self.placeDragLabel()
        self._oldKeyStates = [Window.WINDOW.isKey_ALT, Window.WINDOW.isKey_STRG, Window.WINDOW.isKey_SHIFT]
    def _updateDragImageType(self):
        if not Window.WINDOW.isKey_ALT and Window.WINDOW.isKey_STRG and not Window.WINDOW.isKey_SHIFT:
            self.dragMode = "copy"
        elif (Window.WINDOW.isKey_ALT and not Window.WINDOW.isKey_STRG and not Window.WINDOW.isKey_SHIFT) or (not Window.WINDOW.isKey_ALT and Window.WINDOW.isKey_STRG and Window.WINDOW.isKey_SHIFT):
            self.dragMode = "ref"
        else:
            if self.nbUnderCursor == self.notebook:
                self.dragMode = None
            else:
                self.dragMode = "move"
        if self.nbUnderCursor is None: self.dragMode = None
        self._oldNbUnderCursor = self.nbUnderCursor
    def _updateDragImage(self):
        """
        only sets the image

        @return:
        """
        if self.dragMode == self._oldDragMode: return
        if self.dragMode == "copy":
            self.dragModeLabel.setImage(IconHandler.getNavigationIcon("plus").clone(True).resizeTo(30, 30))
        elif self.dragMode == "move":
            self.dragModeLabel.setImage(IconHandler.getNavigationIcon("arrow_left").clone(True).resizeTo(30, 30))
        elif self.dragMode == "ref":
            self.dragModeLabel.setImage(IconHandler.getNavigationIcon("ref").clone(True).resizeTo(30, 30))
        self._oldDragMode = ""
    def updateWidgetSize(self):
        Window.WINDOW._updateDynamicSize(self.fileTree)
        Window.WINDOW._updateDynamicSize(self.cEntry)


    def placeDragLabel(self):
        mouse = Window.WINDOW.getMousePosition()
        self.dragLabel.place(mouse.copy().change(x=-15, y=-30), width=30, height=30)
        if self.dragMode is not None:
            self.dragModeLabel.place(mouse.copy().change(x=15), width=30, height=30)
        else:
            self.dragModeLabel.placeForget()

    def onLClickMotionEvent(self, e):
        e = tk.Event(e)
        selected = self.fileTree.getSelectedItems()
        if selected is None: return
        if self.isDraggingFile: #dragging
            mouseLoc = Window.WINDOW.getMousePosition()
            _found = False

            widgetList = [*Window.WINDOW.notebooks, *Window.WINDOW.pins]

            for nb in widgetList:
                if nb.rect.collisionWithPoint(mouseLoc):
                    _found = True
                    if self.nbUnderCursor is not None:
                        if self.nbUnderCursor != nb:
                            self.nbUnderCursor.dragLeave()
                    self.nbUnderCursor = nb
                    self.nbUnderCursor.dragEnter()
                    if nb == self.notebook:
                        continue
                    self.dragMode = "move"
            if not _found:
                if self.nbUnderCursor is not None:
                    self.nbUnderCursor.dragLeave()
                self.dragMode = None
                self.nbUnderCursor = None
            self._updateDragImageType()
            self._updateDragImage()
            self.placeDragLabel()
        else:
            if len(selected) == 1: # initialize dragging
                self.isDraggingFile = True
                self.dragModeLabel = tk.Label(Window.WINDOW)
                self.dragLabel = tk.Label(Window.WINDOW)
                self.draggingPath = os.path.join(self.path, selected[0]["Name"])
                self.activeDragIcon = IconHandler.getIconFromExtention(selected[0]["File-Type"]).clone(True).resizeTo(30, 30)
                self.dragLabel.setImage(self.activeDragIcon)

                self.updateDragImage()
                # or self.dragMode -> None
    def onLClickReleaseEvent(self):
        if self.isDraggingFile:
            if self.nbUnderCursor is not None:
                self.nbUnderCursor.dragLeave()
            self.dragLabel.destroy()
            self.dragModeLabel.destroy()
            self.isDraggingFile = False
            if self.nbUnderCursor is None: return
            if self.dragMode is not None:

                targetPath = self.nbUnderCursor.activeTab.path if isinstance(self.nbUnderCursor, FileNotebook) else self.nbUnderCursor.path

                if self.dragMode == "copy":
                    CopyWindow(Window.WINDOW, self.draggingPath, targetPath).open()
                if self.dragMode == "move":
                    CopyWindow(Window.WINDOW, self.draggingPath, targetPath).open()
                    send2trash(self.draggingPath)
                elif self.dragMode == "ref":
                    self.newRef(self.draggingPath, targetPath)

                if isinstance(self.nbUnderCursor, FileNotebook): self.nbUnderCursor.activeTab.updateFileTree()
                sel = self.fileTree.getSelectedItems()
                self.updateFileTree(mark=None if sel is None else sel[0]["Name"])
            self.nbUnderCursor = None

    def openQuickSearch(self):
        if self.isQuickSearch: return
        self.isQuickSearch = True
        self.quickSearchWidget.placeRelative(fixHeight=25, fixWidth=100, stickDown=True, stickRight=True, changeX=-5, changeY=-5)
        self.quickSearchWidget.setFocus()
    def updateQuickSearch(self):
        if not self.isQuickSearch: return
        _list = []
        for item in os.listdir(self.path):
            if self.quickSearchWidget.getValue().lower() in item.lower():
                _list.append(item)
        self.isFileTreeInForeground = False
        self.updateFileTree(showList=_list, mark=[_list[0]] if len(_list) > 0 else None)
    def closeQuickSearch(self):
        if not self.isQuickSearch: return
        self.isQuickSearch = False
        self.quickSearchWidget.clear()
        self.quickSearchWidget.placeForget()
        self.fileTree.setFocus()
        self.updateFileTree()

    def openFile(self, path):
        Window.WINDOW.openFile(path)

    def onKey(self, e):
        if Window.WINDOW.activeNotebook.activeTab != self:
            print("CATCHED !!")
            return

        if not Window.WINDOW.isKey_STRG and not Window.WINDOW.isKey_ALT and not Window.WINDOW.isKey_SHIFT and not self.isDraggingFile and e.getKey() in ascii_letters:
            e = tk.Event(e)
            if not self.isQuickSearch:
                self.quickSearchWidget.setValue(e.getKey())
                self.openQuickSearch()
    def onTabCloseEvent(self):
        self.closeQuickSearch()
    def onUserInputEvent(self):
        entry = self.cEntry.getValue()
        if entry == "": return []
        suggestions = []
        _path, raw = os.path.split(entry)
        if os.path.exists(_path):
            try:
                for p in os.listdir(_path):
                    if p.startswith(raw) and p != raw and not Settings.fileCheck(p):
                        suggestions.append(p)
            except PermissionError as e:
                self._permissionError(e, _path)
        return suggestions
    def onTabSelect(self):
        if PropertiesTab._ACTIVE is not None: PropertiesTab._ACTIVE.destroy()
        if SearchTab._ACTIVE is not None: SearchTab._ACTIVE.destroy()
        self.search.render()
        self.properties.render()
    def onTabUnselect(self):
        self.closeQuickSearch()
        self.cEntry.closeListbox()
        self.fileTree.clearSelection()
    def onCEntrySelectEvent(self, e):
        _mark = []
        path = e.getValue()
        if os.path.exists(path):
            if not os.path.isdir(path):
                _mark = path
                path = os.path.split(path)[0]
            self.history.add(path)
            self.updateFileTree(path, mark=_mark)
    def onFileTreeReturnEvent(self):
        """

        data:str -> {'Name': 'ZP_TODO.txt', 'File-Type': '.txt', 'Modification-Date': 'Sun Feb  6 12:07:37 2022', 'Size': '407.00b'}

        @return:
        """
        data = self.fileTree.getSelectedItems()
        self.closeQuickSearch()
        self.isFileTreeInForeground = True
        if data is None: return
        data = data[0]

        if data["File-Type"] == "Folder":
            self.properties.clearProperties()
            Window.WINDOW.statusBar.setInfo(f"")
            self.fileTree.setItemSelectedByIndex(0)
            self.path = os.path.join(self.cEntry.getValue(), data["Name"])
            self.history.add(self.path)
            self.updateFileTree(self.path)
        else:
            self.openFile(os.path.join(self.path, data["Name"]))

            #openFile(os.path.join(self.path, data["Name"]))
    def onArrowSelect(self, e):
        if self.fileTree.length() == 0: return
        Window.WINDOW.statusBar.setInfo("1 item selected")
        value = e.getValue()
        if e.isKey(tk.EventType.ARROW_DOWN):
            value = self.fileTree.getDataByIndex(0)
            if self.fileTree.getSelectedItems() is None:
                self.fileTree.setItemSelectedByIndex(0)
                self.isFileTreeInForeground = False
            else:
                if self.isFileTreeInForeground: return
                selected = self.fileTree.getSelectedIndex()[0]
                if selected+1 >= self.fileTree.getSize():
                    return
                else:
                    self.fileTree.setItemSelectedByIndex(selected+1)
                    value = self.fileTree.getSelectedItems()
        elif e.isKey(tk.EventType.ARROW_UP):
            if self.isFileTreeInForeground: return
            if self.fileTree.getSelectedItems() is None:
                return
            else:
                selected = self.fileTree.getSelectedIndex()[0]
                if selected+1 <= 1:
                    return
                else:
                    self.fileTree.setItemSelectedByIndex(selected-1)
                    value = self.fileTree.getSelectedItems()

        value = value[0] if isinstance(value, list) else value
        path = os.path.join(self.path, value["Name"])
        self.properties.updateProperties(path)
    def onFileTreeSingleSelectEvent(self, e):
        Window.WINDOW.setNotebookSelected(self.notebook) #TODO also in cEntry on click

        self.frame.setFocus()
        self.fileTree.setFocus()

        e = tk.Event(e)
        e.setTkEventCanceled()
        value = e.getValue()
        if value is None: return
        Window.WINDOW.statusBar.setInfo(f"{len(value)} item{'s' if len(value) > 1 else ''} selected")
        value = value[0]
        self.isFileTreeInForeground = True
        path = os.path.join(self.path, value["Name"])
        if path == self.lastClickOnFile[1]:
            task = self.renameTask
            self.renameTask = None
            if task is not None:
                task.cancel()
            if t.time()-self.lastClickOnFile[0] < 0.3:
                self.onFileTreeReturnEvent()
            elif t.time()-self.lastClickOnFile[0] < 0.5:
                self.renameTask = Window.WINDOW.runTaskAfter(self.context_rename, 0.3)
            else:
                self.properties.updateProperties(path)
        else:
            self.properties.updateProperties(path)
        self.lastClickOnFile = (t.time(), path)

    def showParentDir(self):
        #@TODO: select the previous folder
        subPath, this = os.path.split(self.path)
        self.isFileTreeInForeground = False
        if this == "": return
        Window.WINDOW.statusBar.setInfo(f"")
        self.history.add(subPath)
        self.updateFileTree(subPath)
    def _permissionError(self, e, path):
        tk.SimpleDialog.askError(Window.WINDOW, "Access denied!\nPath: "+path, Window.TITLE)
    def _getSizeDir(self, path):
        _size = 0
        for root, dirs, files in os.walk(path):
            for file in files:
                _size += os.path.getsize(os.path.join(root, file))
        return parseSize(_size)
class FileNotebook(tk.Notebook):
    def __init__(self, _master):
        self.id = ID.newId(8)
        self.frame = tk.LabelFrame(_master)
        super().__init__(self.frame, closable=True)
        self.onTabSelectEvent(self.onNotebookTabSelect)
        self.onCloseEvent(self.onNotebookTabClose)
        self.rect = None
        self.tabs = []
        self._dragLabel = DragLabel(_master, onRelease=Window.WINDOW.updateFileTreePlace)
        self.activeTab:FileTab = None
        self.widthPercent = 100
    def size(self):
        return len(self.tabs)
    def addTab(self, path, highlight=None)->FileTab:
        if self.activeTab is not None: self.activeTab.closeQuickSearch()
        tab = FileTab(path=path, notebook=self, highlight=highlight)
        self.tabs.append(tab)
        if self.activeTab is None: self.activeTab = tab
        self.activeTab.onTabSelect()
        return tab
    def onNotebookSelect(self):
        #Window.WINDOW.activeNotebook = self
        self.frame.setBg("#C8C8C8")
        self.frame.setBorderWidth(1)
        self.frame.setFocus()
    def onNotebookUnSelect(self):
        self.frame.setBg(tk.Color.DEFAULT)
        self.frame.setBorderWidth(0)
        self.activeTab.onTabUnselect()
    def onNotebookTabSelect(self, e):
        val = e.getValue()
        if val is None: return
        if self.activeTab is not None: self.activeTab.onTabUnselect()
        if val > len(self.tabs)-1:
            return
        self.tabs[val].onTabSelect()
        self.activeTab = self.tabs[val]
    def onNotebookClose(self):
        Window.WINDOW.notebooks.remove(self)
        self._dragLabel.destroy()
        self.frame.destroy()
        Window.WINDOW.activeNotebook = Window.WINDOW.notebooks[-1]
        Window.WINDOW.activeNotebook.onNotebookSelect()  # <-|
        Window.WINDOW.updateFileTreePlace()
    def onNotebookTabClose(self, e):
        e = tk.Event(e)
        val = e.getValue()
        if val is None: return
        e.setCanceled(True)
        if len(self.tabs) <= 1:
            if len(Window.WINDOW.notebooks) > 1:
                self.onNotebookClose()
            return
        tab = self.tabs[val]
        tab.onTabCloseEvent()
        self.tabs.remove(tab)
        self.activeTab = self.tabs[-1]
        self.activeTab.onTabSelect()
        self.activeTab.frame.setSelected()
        e.setCanceled(False)
    def closeTab(self, tab:FileTab):
        if len(self.tabs) <= 1:
            if len(Window.WINDOW.notebooks) > 1:
                Window.WINDOW.notebooks.remove(self)
                self.destroy()
                Window.WINDOW.updateFileTreePlace()
                Window.WINDOW.notebooks[-1].onNotebookSelect()
        tab = self.tabs[tab.frame.getTabIndex()]
        tab.onTabCloseEvent()
        tab.frame.destroy()
        self.tabs.remove(tab)
        self.activeTab = self.tabs[-1]
        self.activeTab.onTabSelect()
        self.activeTab.frame.setSelected()
    def dragEnter(self):
        pass
    def dragLeave(self):
        pass
    def place(self, x=None, y=None, width=None, height=None, anchor:tk.Anchor=tk.Anchor.UP_LEFT):
        self.frame.place(x, y, width ,height, anchor)
        self.placeRelative(changeHeight=-2, changeWidth=-2)
    def destroy(self):
        self._destroy()
        self.frame.destroy()
        #self.updateRelativePlace()
    @staticmethod
    def placeNotebooks():
        window:Window = Window.WINDOW

class History:
    def __init__(self, main):
        pass
    def undo(self):
        pass
    def redo(self):
        pass
class Favorites:
    def __init__(self, taskBar, master):
        self.fav = taskBar
        self.master = master
        self.updateFavorites(False)
        Window.WINDOW.bind(self.openGUI, Settings.getKeyBind("favorites_menu"))
    def updateFavorites(self, create=True):
        favorites = Config.FAVORITES_CONFIG["favorites"]
        self.fav.clear()
        def _load(_favorites, menu, name=None):
            if name is not None:
                menu = menu.createSubMenu(tk.Button(self.master).setText(name))
            for k, v in iterDict(_favorites):
                if isinstance(v, list):
                    tk.Button(menu).setText(k).setCommand(self.openFavorite, args=v)
                else:
                    _load(v, menu, k)

        _load(favorites, self.fav)
        self.fav.addSeparator()
        tk.Button(self.fav).setText("Edit Favorites...").setCommand(self.openGUI)
        if create: self.fav.create()
    def openGUI(self, path):
        if isinstance(path, tk.Event): path = ""
        openDict = data = Config.FAVORITES_CONFIG["favorites"].copy()
        history = [openDict]
        def updateListBox(d, main):
            lis.clear()
            if not main:
                lis.add("< Back")
            for k, v in iterDict(d):
                if isinstance(v, list):
                    lis.add(k)
                else:
                    lis.add(k + " >")
        def listBoxSelect(e):
            sel = lis.getSelectedItem()
            if sel is not None:
                if sel == "< Back":
                    pathE.clear()
                    nameE.clear()
                    nameE.setDisabled()
                    pathE.setDisabled()
                elif not sel.endswith(" >"):
                    nameE.setEnabled()
                    nameE.setValue(sel)
                    pathE.setEnabled()
                    pathE.setValue(openDict[sel][0])
                else:
                    nameE.setEnabled()
                    nameE.setValue(sel[:-2])
                    pathE.clear()
                    pathE.setDisabled()
        def listBoxDoubleSelect(e):
            nonlocal openDict
            sel = lis.getSelectedItem()
            if sel.endswith(" >"):
                newDict = openDict[sel[:-2]]
                updateListBox(newDict, False)
                openDict = newDict
                history.append(newDict)
            elif sel == "< Back":
                history.pop(-1)
                openDict = history[-1]
                if len(history) == 1:
                    updateListBox(openDict, True)
                else:
                    updateListBox(openDict, False)
        def saveToFile():
            Config.FAVORITES_CONFIG["favorites"] = data
            Config.FAVORITES_CONFIG.save()
            self.updateFavorites()
        def save():
            sel = _sel = lis.getSelectedItem()
            if sel is None: return
            if sel == "< Back": return
            if pathE.getValue() != "":
                if not os.path.exists(pathE.getValue()):
                    if not tk.SimpleDialog.askOkayCancel(self.master, "The path is invalid.\nDo you want to add/change the favorite anyway?", Window.TITLE):
                        return

            _name = nameE.getValue()
            sel = sel[:-2] if sel.endswith(" >") else sel
            _data = openDict[sel].copy()
            openDict.pop(sel)
            openDict[_name] = _data
            if not _sel.endswith(" >"):
                openDict[_name][0] = pathE.getValue()
                openDict[_name][1] = "folder" if os.path.isdir(pathE.getValue()) else "file"
            if len(history) == 1:
                updateListBox(openDict, True)
            else:
                updateListBox(openDict, False)
            saveToFile()
        def delete_():
            sel = lis.getSelectedItem()
            if sel is None: return
            if sel == "< Back": return
            if not tk.SimpleDialog.askOkayCancel(self.master, f"Are you sure you want to delete '{(sel[:-2] if sel.endswith(' >') else sel)}'?", Window.TITLE):
                return

            openDict.pop(sel[:-2] if sel.endswith(" >") else sel)


            if len(history) == 1:
                updateListBox(openDict, True)
            else:
                updateListBox(openDict, False)
            saveToFile()
        def numerateName(name):
            if name in openDict.keys():
                n = 1
                while True:
                    if f"{name}({n})" not in openDict.keys():
                        name = f"{name}({n})"
                        return name
                    n += 1
        def newFolder():
            name = "newFolder"
            if "newFolder" in openDict.keys():
                name = numerateName(name)
            openDict[name] = {}
            if len(history) == 1:
                updateListBox(openDict, True)
            else:
                updateListBox(openDict, False)
            saveToFile()
        def add():
            if pathNewE.getValue() != "":
                if not os.path.exists(pathNewE.getValue()):
                    if not tk.SimpleDialog.askOkayCancel(self.master, "The path is invalid.\nDo you want to add/change the favorite anyway?", Window.TITLE):
                        return
            if nameNewE.getValue() == "":
                name = "newFavorite"
                if "newFavorite" in openDict.keys():
                   name = numerateName(name)
            else:
                name = nameNewE.getValue()
                if name in openDict.keys():
                    name = numerateName(name)
                    if not tk.SimpleDialog.askOkayCancel(self.master, f"This name exists already!\nDo you want to change the name to '{name}'?", Window.TITLE):
                        return

            openDict[name] = [pathNewE.getValue(), ("folder" if os.path.isdir(pathNewE.getValue()) else "file")]
            if len(history) == 1:
                updateListBox(openDict, True)
            else:
                updateListBox(openDict, False)
            saveToFile()
        def move(e):
            nonlocal openDict
            _openDict = openDict.copy()
            direction = e.getArgs()
            sel = _sel = lis.getSelectedItem()
            if sel is None: return
            sel = sel[:-2] if sel.endswith(" >") else sel
            size = lis.length()
            main = len(history) == 1
            index = lis.getSelectedIndex()
            if direction == "up":
                if (main and index > 0) or (not main and index > 1):
                    keys = list(_openDict.keys())
                    index = keys.index(sel)
                    keys.remove(sel)
                    keys.insert(index-1, sel)
                    openDict.clear()
                    for key in keys:
                        openDict[key] = _openDict[key]
                else: return
            else: #down
                if index+1 < size:
                    keys = list(_openDict.keys())
                    index = keys.index(sel)
                    keys.remove(sel)
                    keys.insert(index+1, sel)
                    openDict.clear()
                    for key in keys:
                        openDict[key] = _openDict[key]
                else: return


            if len(history) == 1:
                updateListBox(openDict, True)
            else:
                updateListBox(openDict, False)
            lis.setItemSelectedByName(_sel)
            saveToFile()

        _master = tk.Dialog(self.master)
        _master.setWindowSize(400, 200+25)
        _master.setResizeable(False)
        _master.bind(_master.destroy, tk.EventType.ESC)
        _master.setTitle("Favorite-Manager")

        tk.Label(_master).setText("Edit:").place(200, 10)
        nameE = tk.TextEntry(_master).setText("Name: ").place(200, 10+25, width=190) # no '<, >'
        pathE = tk.TextEntry(_master).setText("Path:    ").place(200, 35+25, width=190)
        tk.Button(_master).setText("Save changes").place(200, 60+25, width=95).setCommand(save)
        tk.Button(_master).setText("Delete").place(295, 60+25, width=95).setCommand(delete_)

        tk.Label(_master).setText("New:").place(200, 60+55)
        nameNewE = tk.TextEntry(_master).setText("Name: ").place(200, 60+80, width=190)  # no '<, >'
        pathNewE = tk.TextEntry(_master).setText("Path:    ").place(200, 60+105, width=190).setValue(path)
        tk.Button(_master).setText("Add").place(200, 60+130, width=95).setCommand(add)
        tk.Button(_master).setText("New Folder").place(295, 60+130, width=95).setCommand(newFolder)

        tk.Button(_master).setImage(IconHandler.getNavigationIcon("arrow_up")).place(400 - 35, 10, 25, 25).setCommand(move, args="up")
        tk.Button(_master).setImage(IconHandler.getNavigationIcon("arrow_down")).place(400 - 60, 10, 25, 25).setCommand(move, args="down")

        lis = tk.Listbox(_master)
        updateListBox(Config.FAVORITES_CONFIG["favorites"], True)
        lis.bind(listBoxDoubleSelect, tk.EventType.DOUBBLE_LEFT)
        lis.onSelectEvent(listBoxSelect)
        lis.place(10, 10, 190, 180+25)
        _master.show()
    def openFavorite(self, e):
        path, _type = e.getArgs()
        if os.path.exists(path):
            if _type == "folder":
                self.master.activeNotebook.activeTab.updateFileTree(path)
            else:
                self.master.activeNotebook.activeTab.updateFileTree(os.path.split(path)[0], mark=path)
class Pin(tk.Button):
    def __init__(self, frame, path, name, icon=None):
        super().__init__(frame)
        self.path = path
        self.name = " "*3+name

        self.rect = None
        self.bind(self.onRelPlace, tk.EventType.CUSTOM_RELATIVE_UPDATE_AFTER)

        self.setText(name)
        self.canTakeFocusByTab(False)
        #self.placeRelative(changeWidth=-1, fixHeight=30, fixY=30 * (len(list_) - 1))
        self.setBg("white")
        self.setFont(12)
        self.setCommand(self.onPress)
        self.setTextOrientation(tk.Anchor.LEFT)
        self.menu = tk.ContextMenu(self)

        if icon is not None:
            self.setImage(icon)
            self.setCompound(tk.Direction.LEFT)
    def addContext(self, text, cmd, args=None):
        tk.Button(self.menu).setText(text).setCommand(cmd, args)

    def placeRelative(self, fixX=None, fixY=None, fixWidth=None, fixHeight=None, xOffset=0, yOffset=0, xOffsetLeft = 0, xOffsetRight=0, yOffsetUp=0, yOffsetDown=0, stickRight=False, stickDown=False, centerY=False, centerX=False, changeX=0, changeY=0, changeWidth=0, changeHeight=0, nextTo=None, updateOnResize=True):
        self.menu.create()
        self._placeRelative(fixX, fixY, fixWidth, fixHeight, xOffset, yOffset, xOffsetLeft, xOffsetRight, yOffsetUp, yOffsetDown, stickRight, stickDown, centerY, centerX, changeX, changeY, changeWidth, changeHeight, nextTo, updateOnResize)
    def onRelPlace(self, e):
        pos = e.getValue()
        if pos is None: return
        x, y, width, height = pos
        self.rect = Rect.fromLocWidthHeight(Location2D(
            x=x+2,
            y=y+Window.WINDOW.toolBar.getHeight()+25 # -> Notebook tab height offset
        ),
        width=width,
        height=height)
    def dragEnter(self):
        self.setBg(tk.Color.BLUE)
    def dragLeave(self):
        self.setBg(tk.Color.DEFAULT)

    def onPress(self):
        Window._getActiveTab().history.add(self.path)
        Window._getActiveTab().updateFileTree(self.path)
    def _getActiveTab(self) -> FileTab:
        return Window.WINDOW.activeNotebook.activeTab

class TaskBar(tk.TaskBar):
    def __init__(self, master):
        self.master = master
        super().__init__(master)
        self.file = self.createSubMenu("File")
        self.edit = self.createSubMenu("Edit")
        self.view = self.createSubMenu("View")
        self.tools = self.createSubMenu("Tools")
        self.plugins = self.createSubMenu("Plugins")
        self.favorites = self.createSubMenu("Favorites")
        self.categories = {"file":self.file, "edit":self.edit, "view":self.view, "tools":self.tools}
        self.menu_file()
        self.menu_edit()
        self.menu_view()
        self.menu_tools()
        self.menu_plugins()
        self.menu_favorites()
    def menu_file(self):
        tk.Button(self.file).setText("Open PyCMD")
        tk.Button(self.file).setText("Open New Window")
        self.file.addSeparator()
        tk.Button(self.file).setText("Close (Alt+F4)").setCommand(Window.WINDOW.close)
    def menu_edit(self):
        tk.Button(self.edit).setText(f"Undo ({Settings.getKeyBindText('undo')})").setCommand(Window.WINDOW.history.undo)
        tk.Button(self.edit).setText(f"Redo ({Settings.getKeyBindText('redo')})").setCommand(Window.WINDOW.history.redo)

        tk.Button(self.edit).setCommand(Window.WINDOW.callTab, args=["context_copy"]).setText(f"Copy ({Settings.getKeyBindText('copy')})")
        tk.Button(self.edit).setCommand(Window.WINDOW.callTab, args=["context_cut"]).setText(f"Cut ({Settings.getKeyBindText('cut')})")
        tk.Button(self.edit).setCommand(Window.WINDOW.callTab, args=["context_paste"]).setText(f"Paste ({Settings.getKeyBindText('paste')})")
        tk.Button(self.edit).setCommand(Window.WINDOW.callTab, args=["context_duplicate"]).setText(f"Duplicate ({Settings.getKeyBindText('duplicate')})")
        tk.Button(self.edit).setCommand(Window.WINDOW.callTab, args=["context_rename"]).setText(f"Rename ({Settings.getKeyBindText('rename')})")
        tk.Button(self.edit).setCommand(Window.WINDOW.callTab, args=["context_delete"]).setText(f"Delete ({Settings.getKeyBindText('delete')})")

        self.edit.addSeparator()
        tk.Button(self.edit).setText("Settings (Alt+S)").setCommand(Settings.openGUI)  # .setImage(IconHandler.getNavigationIcon("settings"))
    def menu_view(self):
        tk.Button(self.view).setText("New Tab").setCommand(Window.WINDOW.newTab)
        tk.Button(self.view).setText("New Notebook").setCommand(Window.WINDOW.newNotebook)
        self.view.addSeparator()
        tk.Button(self.view).setText("Move selected Tab to new Notebook").setCommand(Window.WINDOW.moveSelectedTabToNewNotebook)
        self.view.addSeparator()
        tk.Button(self.view).setText("Open selected Item in new Tab")
        tk.Button(self.view).setText("Open selected Item in new Notebook")
        self.view.addSeparator()
        tk.Button(self.view).setText("Clone selected Tab").setCommand(Window.WINDOW.cloneActiveTab)
        tk.Button(self.view).setText("Clone selected Notebook").setCommand(Window.WINDOW.cloneActiveNotebook)
    def menu_tools(self):
        # tk.Button(self.tools).setText("Backup Tool")
        # tk.Button(self.tools).setText("Encrypt Tool")
        pass # build by plugins
    def menu_plugins(self):
        tk.Button(self.plugins).setText("Enable all Plugins...").setCommand(PluginManagerGUI.enableAll)
        tk.Button(self.plugins).setText("Disable all Plugins...").setCommand(PluginManagerGUI.disableAll)
        self.plugins.addSeparator()
        tk.Button(self.plugins).setText("Generate New Plugin...").setCommand(PluginManager.openGeneratorGUI)
        self.plugins.addSeparator()
        tk.Button(self.plugins).setText("Open PluginManager").setCommand(PluginManager.openGUI)
    def menu_favorites(self):
        pass # build by Favorites manager

    def add(self, category, name, cmd):
        tk.Button(self.categories[category]).setText(name).setCommand(cmd)
class ToolBar(tk.LabelFrame):
    def __init__(self, _master):
        super().__init__(_master)
        self.placeRelative(fixX=0, fixHeight=100)
        #self.bind(Window.WINDOW.enter, "<Enter>")
    def build(self):
        iconSize = 35
        self.favorites = tk.LabelFrame(self)
        self.favorites.setText("Misc")
        self.favorites.placeRelative(fixX=0, fixY=0, fixWidth=iconSize*3+5, changeHeight=-5)

        tk.Button(self.favorites).placeRelative(fixWidth=iconSize, fixHeight=iconSize).setImage(IconHandler.getNavigationIcon("star")).setCommand(Window.WINDOW.favorites.openGUI).attachToolTip(f"Favorites ({Settings.getKeyBindText('favorites_menu')})")
        tk.Button(self.favorites).placeRelative(fixWidth=iconSize, fixHeight=iconSize, fixX=iconSize).setImage(IconHandler.getNavigationIcon("pin")).setCommand(None).attachToolTip(f"Open Pin-Menu ({Settings.getKeyBindText('pin_menu')})")
        tk.Button(self.favorites).placeRelative(fixWidth=iconSize, fixHeight=iconSize, fixX=0, fixY=iconSize).setImage(IconHandler.getNavigationIcon("plug")).setCommand(PluginManager.openGUI).setCommand(Window.WINDOW.update_).attachToolTip(f"Open Plugin-Manager ({Settings.getKeyBindText('plugin_manager')})")
        tk.Button(self.favorites).placeRelative(fixWidth=iconSize, fixHeight=iconSize, fixX=iconSize, fixY=iconSize).setImage(IconHandler.getNavigationIcon("update")).setCommand(Window.WINDOW.update_).attachToolTip(f"Refresh ({Settings.getKeyBindText('refresh')})")
        tk.Button(self.favorites).placeRelative(fixWidth=iconSize, fixHeight=iconSize, fixX=iconSize*2, fixY=0).setImage(IconHandler.getNavigationIcon("search")).setCommand(None).attachToolTip(f"Advanced search... ({Settings.getKeyBindText('search')})") # maybe new bind for Advanced search
        tk.Button(self.favorites).placeRelative(fixWidth=iconSize, fixHeight=iconSize, fixX=iconSize*2, fixY=iconSize).setImage(IconHandler.getNavigationIcon("settings")).setCommand(Settings.openGUI).attachToolTip(f"Settings ({Settings.getKeyBindText('settings')})")

        self.navigation = tk.LabelFrame(self)
        self.navigation.setText("Navigation")
        self.navigation.placeRelative(fixX=iconSize*3+5, fixY=0, fixWidth=iconSize*3+5, changeHeight=-5)

        tk.Button(self.navigation).placeRelative(fixWidth=iconSize, fixHeight=iconSize).setImage(IconHandler.getNavigationIcon("arrow_left")).setCommand(Window.WINDOW.callTab, args=["backward"]).attachToolTip(f"Navigation backward\n({Settings.getKeyBindText('filetree_backward')})")
        tk.Button(self.navigation).placeRelative(fixWidth=iconSize, fixHeight=iconSize, fixX=iconSize).setImage(IconHandler.getNavigationIcon("arrow_right")).setCommand(Window.WINDOW.callTab, args=["forward"]).attachToolTip(f"Navigation forward\n({Settings.getKeyBindText('filetree_forward')})")
        tk.Button(self.navigation).placeRelative(fixWidth=iconSize, fixHeight=iconSize, fixX=iconSize*2).setImage(IconHandler.getNavigationIcon("arrow_up")).setCommand(Window.WINDOW.callTab, args=["showParentDir"]).attachToolTip(f"Show parent directory\n({Settings.getKeyBindText('filetree_dir_up')})")
        tk.Button(self.navigation).placeRelative(fixWidth=iconSize, fixHeight=iconSize, fixY=iconSize).setImage(IconHandler.getNavigationIcon("undo")).setCommand(Window.WINDOW.history.undo).attachToolTip(f"Undo current operation\n({Settings.getKeyBindText('undo')})")
        tk.Button(self.navigation).placeRelative(fixWidth=iconSize, fixHeight=iconSize, fixX=iconSize, fixY=iconSize).setImage(IconHandler.getNavigationIcon("redo")).setCommand(Window.WINDOW.history.redo).attachToolTip(f"Redo current operation\n({Settings.getKeyBindText('redo')})")

        self.new = tk.LabelFrame(self)
        self.new.setText("New")
        self.new.placeRelative(fixX=iconSize*6+10, fixY=0, fixWidth=iconSize*3+5, changeHeight=-5)

        tk.Button(self.new).placeRelative(fixWidth=iconSize, fixHeight=iconSize).setImage(IconHandler.getNavigationIcon("new_folder")).setCommand(Window.WINDOW.callTab, args=["context_createNewFile", "folder"]).attachToolTip(f"Create new folder ({Settings.getKeyBindText('new_folder')})")
        tk.Button(self.new).placeRelative(fixWidth=iconSize, fixHeight=iconSize, fixX=iconSize).setImage(IconHandler.getNavigationIcon("new_file")).setCommand(Window.WINDOW.callTab, args=["context_createNewFile", "file"]).attachToolTip(f"Create new file ({Settings.getKeyBindText('new_file')})")
        tk.Button(self.new).placeRelative(fixWidth=iconSize, fixHeight=iconSize, fixX=iconSize*2).setImage(IconHandler.getNavigationIcon("new_zip")).setCommand(Window.WINDOW.callTab, args=["context_createNewFile", ".zip"]).attachToolTip(f"Create new zip-file ({Settings.getKeyBindText('new_zip')})")
        tk.Button(self.new).placeRelative(fixWidth=iconSize, fixHeight=iconSize, fixX=0, fixY=iconSize).setImage(IconHandler.getNavigationIcon("new_ref")).setCommand(Window.WINDOW.callTab, args=["context_createNewFile", "ref"]).attachToolTip(f"Create new reference ({Settings.getKeyBindText('new_ref')})")
        tk.Button(self.new).placeRelative(fixWidth=iconSize, fixHeight=iconSize, fixX=iconSize, fixY=iconSize).setImage(IconHandler.getNavigationIcon("new_py")).setCommand(Window.WINDOW.callTab, args=["context_createNewFile" ,".py"]).attachToolTip(f"Create new python-file ({Settings.getKeyBindText('new_py')})")

        tk.Button(self.new).placeRelative(fixWidth=iconSize, fixHeight=iconSize, fixX=iconSize*2, fixY=iconSize).setImage(IconHandler.getNavigationIcon("hamb")).setCommand(None).attachToolTip(f"Create new file from template... ({Settings.getKeyBindText('new_template')})")

        self.edit = tk.LabelFrame(self)
        self.edit.setText("Edit")
        self.edit.placeRelative(fixX=iconSize*9+15, fixY=0, fixWidth=iconSize * 3 + 5, changeHeight=-5)

        tk.Button(self.edit).placeRelative(fixWidth=iconSize, fixHeight=iconSize).setImage(IconHandler.getNavigationIcon("copy")).setCommand(Window.WINDOW.callTab, args=["context_copy"]).attachToolTip(f"Copy selected item ({Settings.getKeyBindText('copy')})")
        tk.Button(self.edit).placeRelative(fixWidth=iconSize, fixHeight=iconSize, fixX=iconSize).setImage(IconHandler.getNavigationIcon("cut")).setCommand(Window.WINDOW.callTab, args=["context_cut"]).attachToolTip(f"Cut selected item ({Settings.getKeyBindText('cut')})")
        tk.Button(self.edit).placeRelative(fixWidth=iconSize, fixHeight=iconSize, fixX=iconSize * 2).setImage(IconHandler.getNavigationIcon("paste")).setCommand(Window.WINDOW.callTab, args=["context_paste"]).attachToolTip(f"Paste item from clipboard ({Settings.getKeyBindText('paste')})")
        tk.Button(self.edit).placeRelative(fixWidth=iconSize, fixHeight=iconSize, fixX=0, fixY=iconSize).setImage(IconHandler.getNavigationIcon("duplicate")).setCommand(Window.WINDOW.callTab, args=["context_duplicate"]).attachToolTip(f"Duplicate selected item ({Settings.getKeyBindText('duplicate')})")
        tk.Button(self.edit).placeRelative(fixWidth=iconSize, fixHeight=iconSize, fixX=iconSize, fixY=iconSize).setImage(IconHandler.getNavigationIcon("rename")).setCommand(Window.WINDOW.callTab, args=["context_rename"]).attachToolTip(f"Rename selected item ({Settings.getKeyBindText('rename')})")
        tk.Button(self.edit).placeRelative(fixWidth=iconSize, fixHeight=iconSize, fixX=iconSize * 2,fixY=iconSize).setImage(IconHandler.getNavigationIcon("trash")).setCommand(Window.WINDOW.callTab, args=["context_delete"]).attachToolTip(f"Delete selected item ({Settings.getKeyBindText('delete')})")
        
        
        self.view = tk.LabelFrame(self)
        self.view.setText("View")
        #self.view.placeRelative(fixX=iconSize*12+20, fixY=0, fixWidth=iconSize * 3 + 5, changeHeight=-5)

        tk.Button(self.view).placeRelative(fixWidth=iconSize, fixHeight=iconSize).setImage(IconHandler.getNavigationIcon("copy")).setCommand(Window.WINDOW.callTab, args=["context_copy"]).attachToolTip(f"Copy selected item ({Settings.getKeyBindText('copy')})")
        tk.Button(self.view).placeRelative(fixWidth=iconSize, fixHeight=iconSize, fixX=iconSize).setImage(IconHandler.getNavigationIcon("cut")).setCommand(Window.WINDOW.callTab, args=["context_cut"]).attachToolTip(f"Cut selected item ({Settings.getKeyBindText('cut')})")
        tk.Button(self.view).placeRelative(fixWidth=iconSize, fixHeight=iconSize, fixX=iconSize * 2).setImage(IconHandler.getNavigationIcon("paste")).setCommand(Window.WINDOW.callTab, args=["context_paste"]).attachToolTip(f"Paste selected item ({Settings.getKeyBindText('paste')})")
        tk.Button(self.view).placeRelative(fixWidth=iconSize, fixHeight=iconSize, fixX=0, fixY=iconSize).setImage(IconHandler.getNavigationIcon("duplicate")).setCommand(Window.WINDOW.callTab, args=["context_duplicate"]).attachToolTip(f"Duplicate selected item ({Settings.getKeyBindText('duplicate')})")
        tk.Button(self.view).placeRelative(fixWidth=iconSize, fixHeight=iconSize, fixX=iconSize, fixY=iconSize).setImage(IconHandler.getNavigationIcon("rename")).setCommand(Window.WINDOW.callTab, args=["context_rename"]).attachToolTip(f"Rename selected item ({Settings.getKeyBindText('rename')})")
        tk.Button(self.view).placeRelative(fixWidth=iconSize, fixHeight=iconSize, fixX=iconSize * 2,fixY=iconSize).setImage(IconHandler.getNavigationIcon("trash")).setCommand(Window.WINDOW.callTab, args=["context_delete"]).attachToolTip(f"Delete selected item ({Settings.getKeyBindText('delete')})")
class StatusBar(tk.LabelFrame):
    def __init__(self, _master):
        super().__init__(_master)
        self.placeRelative(stickDown=True, fixHeight=20)
        #self.bind(Window.WINDOW.enter, "<Enter>")

        self._statusTask = None
        self._infoTask = None

        self._infoLabel = tk.Label(self).placeRelative(fixX=0, changeHeight=-5, fixWidth=200).setTextOrientation(tk.Anchor.LEFT)
        tk.Separator(self).setOrientation(tk.Orient.VERTICAL).placeRelative(fixX=202, changeHeight=-5, fixWidth=5)
        self._statusLabel = tk.Label(self).placeRelative(fixX=205, changeHeight=-5, fixWidth=200).setTextOrientation(tk.Anchor.LEFT)
    def setInfo(self, i:str):
        self._infoLabel.setText(i)
    def setTimedInfo(self, i:str, ti):
        self._infoLabel.setText(i)
        task = self._infoTask
        if task is not None: task.cancel()
        self._infoTask = Window.WINDOW.runTaskAfter(self.clearInfo, ti)
    def clearInfo(self):
        self._infoLabel.clear()
    def setStatus(self, i:str):
        self._statusLabel.setText(i)
    def setTimedStatus(self, i:str, ti):
        self._statusLabel.setText(i)
        task =  self._statusTask
        if task is not None: task.cancel()
        self._statusTask = self._statusTask = Window.WINDOW.runTaskAfter(self.clearStatus, ti)
    def clearStatus(self):
        self._statusLabel.clear()

class Window(tk.Toplevel):
    TITLE = "" #f"File-Manager V{VERSION}"
    WINDOW = None
    CANCEL_RESIZE = False
    def __init__(self, args, _master="Tk"):
        self.temp = None
        self.defaultPath = r"C:\Robert"
        self.isInitComplete = False
        self.cancelFileTreeUpdate = False
        if len(args) > 1:
            self.initialPath = args[1]
        else:
            self.initialPath = self.defaultPath

        Window.TITLE = f"File-Manager V{VERSION}"
        Window.WINDOW = self
        PluginManager.WINDOW = self
        Settings.WINDOW = self

        MsgText.info("Loading GUI...")
        super().__init__(_master, False)
        IconHandler.loadIcons()

        self.isInfoOpen = True
        self.rezStartLoc = None
        self.isMotion = False
        self.isClickPress = False
        self.isBetween=False

        self.isKey_ALT = False
        self.isKey_STRG = False
        self.isKey_SHIFT = False

        self.notebooks = []

        self.windowStyle = WindowStyle(self)

        th.Thread(target=self.init).start()
        self.mainloop()
    def init(self):
        self.setTitle(Window.TITLE)
        self.setIcon(IconHandler.mainIcon())
        self.setWindowSize(1000, 600)
        self.oldWinSize = (1000, 600)
        self.setMinSize(500, 250)

        self.history = History(self)

        self.dragLabelLeft = DragLabel(self, onRelease=self.updateFileTreePlace)
        if DragLabel.DEBUG: self.dragLabelLeft.setBg("cyan")
        self.dragLabelRight = DragLabel(self, onRelease=self.updateFileTreePlace)
        if DragLabel.DEBUG: self.dragLabelRight.setBg("cyan")
        self.dragLabelRight._changed = True


        self.loadingScreen()
        self.createGUI()

        self.updateDynamicWidgets()

        self.statusBar = StatusBar(self)
        self.taskBar = TaskBar(self)
        self.favorites = Favorites(self.taskBar.favorites, self)
        self.loadingFrame.lift()

        initialPath, mark = self.getInitialPath()
        self.toolBar = ToolBar(self)
        self.loadingFrame.lift()

        self.activeNotebook = FileNotebook(self)
        self.notebooks.append(self.activeNotebook)
        self.activeNotebook.addTab(initialPath, highlight=mark)
        self.loadingFrame.lift()

        self.toolBar.build()
        self.createPins()
        self.loadingFrame.lift()
        TextColor.printStrf(f"§INFOLoading path list at: §c{self.initialPath}§g...")

        PluginManager.call("onEnable")
        self.taskBar.create()

        self.updateDynamicWidgets()
        self.loadingFrame.lift()
        self.isInitComplete = True
        self.updateFileTreePlace()
        self.loadingFrame.lift()
        self.closeLoadingScreen()
    def loadingScreen(self):
        # init note
        self.menu = tk.LabelFrame(self)
        self.menu.placeRelative(fixX=0, fixY=100, fixWidth=200, changeHeight=-20)
        self.info = tk.LabelFrame(self)
        self.info.placeRelative(fixX=0, fixY=100, fixWidth=200, stickRight=True, changeHeight=-20)

        self.loadingFrame = tk.Frame(self).setBg("white").placeRelative()
        titleImage = tk.PILImage.loadImage(os.path.join(BASE_PATH, "images", "icons", "icon.ico")).preRender()
        tk.Label(self.loadingFrame).setImage(titleImage).placeRelative(yOffsetDown=50).setBg("white")
        PluginManager.loadPlugins(self.loadingFrame)
    def closeLoadingScreen(self):
        self.sleep(0.2)
        self.loadingFrame.destroy()
    def createGUI(self):
        self.bind(self.onKey, tk.EventType.STRG_LEFT_UP, args=["isKey_STRG", False])
        self.bind(self.onKey, tk.EventType.STRG_LEFT_DOWN, args=["isKey_STRG", True])
        self.bind(self.onKey, tk.EventType.ALT_LEFT_UP, args=["isKey_ALT", False])
        self.bind(self.onKey, tk.EventType.ALT_LEFT_DOWN, args=["isKey_ALT", True])
        self.bind(self.onKey, tk.EventType.SHIFT_LEFT_UP, args=["isKey_SHIFT", False])
        self.bind(self.onKey, tk.EventType.SHIFT_LEFT_DOWN, args=["isKey_SHIFT", True])

        self.bind(self.history.undo, Settings.getKeyBind("undo"))
        self.bind(self.history.redo, Settings.getKeyBind("redo"))
        self.bind(Settings.openGUI, Settings.getKeyBind("settings"))
        self.bind(self.strgf, Settings.getKeyBind("search"))

        self.bind(PluginManager.openGUI, Settings.getKeyBind("plugin_manager"))

        self.menu.bind(self._onPlaceRelative, tk.EventType.CUSTOM_RELATIVE_UPDATE_AFTER) # temp
        self.onCloseEvent(self.onWindowClose)
        #self.onWindowResize(self._onWindowResize)
        self.fileNoteBook_spaceRight = 204
        self.fileNoteBook_fixX = 204#129

        self.bind(self.motion, tk.EventType.MOUSE_MOTION)
        self.oldInfoWidth = None
        self._oldInfoWidth = None
        self.infoNoteBook = tk.Notebook(self.info)
        self.infoNoteBook.placeRelative()
        self.menuNoteBook = tk.Notebook(self.menu)
        self.menuNoteBook.placeRelative(changeWidth=-5)
        self.closeButton = tk.Button(self.info)
        self.closeButton.setText("✕")
        self.closeButton.setFg(tk.Color.RED)
        self.closeButton.setCommand(self.closeInfo)
        self.closeButton.placeRelative(stickRight=True, fixY=-1, fixWidth=24, fixHeight=24)
        self.openButton = tk.Button(self)
        self.openButton.setText("◁")
        self.openButton.setFont(20)
        self.openButton.setCommand(self.openInfo)

        self.properties = self.infoNoteBook.createNewTab("Properties")
        self.search = self.infoNoteBook.createNewTab("Search")
    def createPins(self):
        def _newTab(e):
            args = e.getArgs()
            self.newTab(args)
        def _newNotebook(e):
            args = e.getArgs()
            self.newNotebook(args)

        self.pinsTab = self.menuNoteBook.createNewTab("Pins")
        self.drives = self.menuNoteBook.createNewTab("Drives")

        self.pins = [
            Pin(self.pinsTab, os.path.join(os.environ['USERPROFILE'], "Desktop"), "Desktop", icon=IconHandler.getNavigationIcon("desk")),  # WIN only
            Pin(self.pinsTab, os.path.join(os.environ['USERPROFILE'], "Documents"), "Documents", icon=IconHandler.getNavigationIcon("docu")),  # WIN only
            Pin(self.pinsTab, os.path.join(os.environ['USERPROFILE'], "Downloads"), "Downloads", icon=IconHandler.getNavigationIcon("dowld")),  # WIN only
            Pin(self.pinsTab, os.path.join(os.environ['USERPROFILE'], "Pictures"), "Pictures", icon=IconHandler.getNavigationIcon("img")),  # WIN only
            Pin(self.pinsTab, r"C:\Robert", "Robert", icon=IconHandler.getNavigationIcon("ufolder"))  # WIN only
                ]
        for i, pin in enumerate(self.pins):
            pin.addContext("Open in new tab", _newTab, pin.path)
            pin.addContext("Open in new Notebook", _newNotebook, pin.path)


            pin.placeRelative(changeWidth=-1, fixHeight=30, fixY=30 * i)
        self.drivesFrame = None
        self.updateDrives()



        #tk.Button(self.pins).setText("Desktop").placeRelative(fixY=0, fixHeight=50, changeWidth=-5)

    def updateDrives(self):
        def eject():
            pass
        def info(e):
            data = e.getArgs(0)
            _info = tk.Dialog(self, False)
            _info.setTitle("Drive Info")
            _info.setWindowSize(400, 400)
            _info.setResizeable(False)
            _info.destroyViaESC()
            _info.setFocus()
            text = tk.Text(_info, readOnly=True)

            size = int(data['Size'])
            free = int(data['FreeSpace'])
            used = int(data['Size']) - int(data['FreeSpace'])

            text.addLine("=" * 12 + "Info" + "=" * 12)
            text.addLine(f"Caption: '{data['Caption']}\\'")
            text.addLine(f"Description: {data['Description']}")
            text.addLine(f"Compressed: {data['Compressed'].capitalize()}")
            text.addLine(f"FileSystem: {data['FileSystem']}")
            text.addLine("="*12+"Size"+"="*12)
            text.addLine(f"Size: {parseSize(size)} ({size})Bytes")
            text.addLine(f"FreeSpace: {parseSize(free)} ({free})Bytes")
            text.addLine(f"UsedSpace: {parseSize(used)} ({used})Bytes")
            text.addLine(f"Used %: {round(size/used, 2)}")
            text.addLine("=" * 9 + "Additional" + "=" * 9)
            text.addLine(f"VolumeDirty: {False if data['VolumeDirty'] == '' else data['VolumeDirty']}")
            text.place(0, 0, 400, 350)

            tk.Label(_info).place(0, 350, 400, 25).setText(f"Used Space: {parseSize(used)}/{parseSize(size)} ({round((used/size)*100, 2)}%)")
            tk.Progressbar(_info).place(0, 375, 400, 25).setPercentage(used/size)

            _info.show()
        def onResize(e):
            x, y, width, height = e.getValue()

        i = 0
        data_int = Memory.getInternMemories()
        data_ext = Memory.getExternMemories()
        if self.isInitComplete: self.statusBar.setTimedInfo("Drives updated!", 1)

        if self.drivesFrame is not None: self.drivesFrame.destroy()
        self.drivesFrame = tk.Frame(self.drives)
        self.drivesFrame.bind(onResize, tk.EventType.CUSTOM_RELATIVE_UPDATE)
        self.drivesFrame.placeRelative()
        tk.Label(self.drivesFrame).setText(f"Intern Drives ({len(data_int)}):").placeRelative(changeWidth=-1, fixHeight=30, fixY=0).setFont(12)
        tk.Button(self.drivesFrame).setImage(IconHandler.getNavigationIcon("update")).placeRelative(fixHeight=25, fixWidth=25).setCommand(self.updateDrives).attachToolTip("Refresh drives")
        for i, drive in enumerate(data_int):
            p = Pin(self.drivesFrame, drive.getCaption()+"\\", name=drive.getCaption()+"\\"+(f"  ({drive.getName()})" if drive.getName() != "" else ""), icon=IconHandler.getNavigationIcon("int"))
            p.placeRelative(changeWidth=-1, fixHeight=30, fixY=30 * (i+1))
            context = tk.ContextMenu(p)
            tk.Button(context).setText("Info").setCommand(info, args=[drive])
            context.create()

        tk.Separator(self.drivesFrame).placeRelative(changeWidth=-1, fixHeight=5, fixY=30 * (i+2))
        tk.Label(self.drivesFrame).setText(f"Extern Drives ({len(data_ext)}):").placeRelative(changeWidth=-1, fixHeight=30, fixY=(30 * (i+2))+5).setFont(12)
        for j, drive in enumerate(data_ext):
            p = Pin(self.drivesFrame, drive.getCaption()+"\\", name=drive.getCaption()+"\\"+(f"  ({drive.getName()})" if drive.getName() != "" else ""), icon=IconHandler.getNavigationIcon("ext"))
            p.placeRelative(changeWidth=-1, fixHeight=30, fixY=(30 * (j + i + 3))+5)
            context = tk.ContextMenu(p)
            tk.Button(context).setText("Eject Drive").setCommand(eject, args=[drive])
            tk.Button(context).setText("Info").setCommand(info, args=[drive])
            context.create()
    def update_(self):
        self.updateDrives()
        for nb in self.notebooks:
            nb.activeTab.updateFileTree()
    def updateGUI(self):
        self.toolBar.destroy()
        self.toolBar = ToolBar(self)
        self.toolBar.build()
        # add bindings of widgets or rebuild
    def updateFileTreePlace(self, ignoreSize=False):
        if not self.isInitComplete: return
        if Window.CANCEL_RESIZE: return
        winSize = self.getWindowSize()
        self.cancelFileTreeUpdate = True
        self.changingSize = False
        self.dragSpace = 6
        if self.oldWinSize != winSize and not ignoreSize: # change at Window size
            self.changingSize = True
            new_x_right = self.info.getWidth()+self.dragSpace
            new_x_left = self.menu.getWidth()
            #self.oldInfoWidth = None
        else:
            if self.dragLabelLeft._changed:
                self.dragLabelLeft._changed = False
                new_x_left = self.dragLabelLeft.pos[0] # menu
                self.menu.placeRelative(fixX=0, fixY=100, fixWidth=new_x_left, changeHeight=-20)
            else:
                new_x_left = self.menu.getWidth()

            if self.dragLabelRight._changed:
                new_x_right = self.getWidth()-self.dragLabelRight.pos[0] # statusBar
                self.info.placeRelative(fixX=0, fixY=100, fixWidth=new_x_right-self.dragSpace, stickRight=True, changeHeight=-20)  # fixWidth=new_x_right-self.dragSpace
            else:
                new_x_right = self.info.getWidth() + self.dragSpace

        if self.oldInfoWidth is not None:
            new_x_right = self.oldInfoWidth + self.dragSpace
            self.oldInfoWidth = None

        self.spaceWidth = (self.getWidth()-(new_x_left+(new_x_right if self.isInfoOpen else -self.dragSpace)+self.dragSpace))
        self.spaceHeight = self.getHeight()-(self.toolBar.getHeight()+self.statusBar.getHeight())-2
        self.spaceX = new_x_left + self.dragSpace #lol
        self.spaceY = self.toolBar.getHeight()

        #if self.temp is not None: self.temp.destroy()
        #self.temp = tk.Label(self).place(self.spaceX, self.spaceY, self.spaceWidth, self.spaceHeight).setBg("red")

        self.dragLabelLeft.place(self.spaceX - self.dragSpace, self.spaceY, self.dragSpace, self.spaceHeight)

        self.dragLabelList = [self.dragLabelLeft]


        perFaq = 1/len(self.notebooks)

        for i, nb in enumerate(self.notebooks):
            nb.widthPercent = perFaq

            if i < len(self.notebooks)-1:
                _width = (self.spaceWidth * perFaq) - self.dragSpace
                nb.place(x=self.spaceX + (i * self.dragSpace) + (i * _width),
                         y=self.spaceY,
                         width=_width,
                         height=self.spaceHeight)
                nb.rect = Rect.fromLocWidthHeight(Location2D(
                    x=self.spaceX + (i * self.dragSpace) + (i * _width),
                    y=self.spaceY
                ),
                width=_width,
                height=self.spaceHeight)
                nb._dragLabel.place(x=self.spaceX+(i*self.dragSpace)+(i*_width)+_width,
                                    y=self.spaceY,
                                    width=self.dragSpace,
                                    height=self.spaceHeight)
                self.dragLabelList.append(nb._dragLabel)
            else:
                _width = (self.spaceWidth * perFaq) - self.dragSpace
                nb.place(x=self.spaceX + (self.dragSpace*i) + (i * _width),
                         y=self.spaceY,
                         width=_width+self.dragSpace,
                         height=self.spaceHeight)
                nb.rect = Rect.fromLocWidthHeight(Location2D(
                    x=self.spaceX + (self.dragSpace*i) + (i * _width),
                    y=self.spaceY
                ),
                width=_width+self.dragSpace,
                height=self.spaceHeight)
                nb._dragLabel.placeForget()
                self.dragLabelList.append(self.dragLabelRight)
                if self.dragLabelRight._changed or self.changingSize: self.dragLabelRight.place(
                                          x=self.spaceX + self.spaceWidth,
                                          y=self.spaceY,
                                          width=self.dragSpace,
                                          height=self.spaceHeight)
                if not self.isInfoOpen: self.dragLabelRight.placeForget()
                self.dragLabelRight.lift()
        self.temp = 0

        for nb in self.notebooks:
            nb.activeTab.updateWidgetSize()

        if not self.isInfoOpen:
            self.openButton.placeRelative(stickRight=True, fixHeight=50, fixWidth=20, centerY=True)
            self.openButton.lift()
        else:
            self.activeNotebook.activeTab.properties.render()
            self.activeNotebook.activeTab.search.render()
        try:
            self.updateDynamicWidgets()
        except:
            MsgText.error("Could not update Relative-Place!")
        self.oldWinSize = winSize
        self.dragLabelRight._changed = False
        self.cancelFileTreeUpdate = False

    def newNotebook(self, path=None):
        if isinstance(path, tk.Event):
            path = path.getArgs()
            if path is None:
                path = [self.activeNotebook.activeTab.path]
        elif isinstance(path, str):
            path = [path]
        self.activeNotebook.activeTab.closeQuickSearch()
        self.activeNotebook = FileNotebook(self)
        self.notebooks.append(self.activeNotebook)
        mark = []
        self.cancelFileTreeUpdate = True
        for p in path:
            if not os.path.isdir(p):
                mark = p
                p = os.path.split(p)[0]
            self.activeNotebook.addTab(p, highlight=mark)
        self.setNotebookSelected(self.activeNotebook)
        self.cancelFileTreeUpdate = False
        self.updateFileTreePlace()
    def newTab(self, path=None, nb=None):
        if isinstance(path, tk.Event):
            path = path.getArgs()
            if path is None:
                path = self.activeNotebook.activeTab.path
        if nb is None: nb = self.activeNotebook
        self.activeNotebook.activeTab.closeQuickSearch()
        mark = []
        if path is not None and not os.path.isdir(path):
            mark = path
            path = os.path.split(path)[0]
        self.activeNotebook.addTab(path, highlight=mark)

    def moveSelectedTabToNewNotebook(self):
        if self.activeNotebook.size() >= 2:
            path = self.activeNotebook.activeTab.path
            self.activeNotebook.closeTab(self.activeNotebook.activeTab)
            self.newNotebook(path)
    def cloneActiveTab(self):
        self.newTab(self.activeNotebook.activeTab.path)
    def cloneActiveNotebook(self):
        paths = [i.path for i in self.activeNotebook.tabs]
        self.newNotebook(paths)

    def openFile(self, path):
        """
        This function gets called if the user opens a File!
        @param path:
        @return:
        """
        PluginManager.call("onFileTreeSelectEvent", path=path)
    def callTab(self, e):
        name = e.getArgs(0)
        args = e.getArgs()[1:]
        getattr(self._getActiveTab(), name)(*args)
    
    def openInNewNotebook(self, path):
        pass
    def setNotebookSelected(self, nb):
        if self.activeNotebook != nb:
            self.activeNotebook = nb
            for nb in self.notebooks:
                if self.activeNotebook == nb:
                    nb.onNotebookSelect()
                    continue
                nb.onNotebookUnSelect()

    def getInitialPath(self):
        mark = []
        #if len(self.initialPaths) >= 1:
            #return self.initialPaths[0], mark
        if not os.path.exists(self.initialPath):
            tk.SimpleDialog.askError(self, f"This path does not exists!\n\n{self.initialPath}", Window.TITLE)
            return self.defaultPath, mark
        else:
            if not os.path.isdir(self.initialPath):
                mark.append(self.initialPath)

                return os.path.split(self.initialPath)[0], mark
        return self.initialPath, mark
    def strgf(self):
        self.openInfo()
        self.search.setSelected()
        self.activeNotebook.activeTab.closeQuickSearch()
        self.activeNotebook.activeTab.search.entry.setFocus()

    def onSave(self):
        PluginManager.call("onSave")
        pass
    def onWindowClose(self, e):
        if not PluginManager.call("onDisable"):
            if PropertiesTab._ACTIVE is not None:
                PropertiesTab._ACTIVE.stopThread()
            if SearchTab._ACTIVE is not None:
                SearchTab._ACTIVE.stopThread()
            if PropertiesTab._ACTIVE is not None:
                PropertiesTab._ACTIVE.stopThread()
            print("\n")
            MsgText.info("Saving Data!")
            self.onSave()
            MsgText.info("Quitting Explorer...")
            #os._exit(0)
    def _onPlaceRelative(self, e):
        if not self.isInitComplete: return
        if not self.cancelFileTreeUpdate:
            self.updateFileTreePlace()
    def motion(self, e:tk.Event):
        mouse = self.getMousePosition().change(x=-3)
        if DragLabel.ACTIVE is not None:
            drag:DragLabel = DragLabel.ACTIVE
            drag._isMotion = True
            drag._changed = True

            if self.dragLabelList[0] == drag:
                if mouse.getX() < 10:
                    return
                elif mouse.getX() > self.dragLabelList[-1].pos[0]-50:
                    return
                drag.place(x=mouse.getX())
            elif self.dragLabelList[-1] == drag:
                if mouse.getX()+6 > self.oldWinSize[0]-10:
                    return
                elif mouse.getX()+6 < self.dragLabelList[0].pos[0]+50+6:
                    return
                drag.place(x=mouse.getX())

            else:
                pass


            drag.lift()

    def closeInfo(self):
        if not self.isInfoOpen: return
        self.isInfoOpen = False
        self._oldInfoWidth = self.info.getWidth()
        self.info.placeForget()
        self.updateFileTreePlace()
    def openInfo(self):
        if self.isInfoOpen: return
        self.isInfoOpen = True
        self.oldInfoWidth = self._oldInfoWidth
        self.dragLabelRight._changed = True
        self.openButton.placeForget()
        self.updateDynamicWidgets()

    def onKey(self, e):
        key, state = e.getArgs()
        setattr(self, key, state)

        if not self.isInitComplete: return

        for nb in self.notebooks:
            nb.activeTab.updateDragImage()

    def mainloop(self):
        """
        Starts the application.
        Calls the OnEnableEvent on all Plugins.
        Mainloop
        @return:
        """
        self._mainloop()
    @staticmethod
    def _getActiveTab()->FileTab:
        return Window.WINDOW.activeNotebook.activeTab
