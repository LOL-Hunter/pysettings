import os
from traceback import format_exc

from pysettings import iterDict
from pysettings import tk

from PyExplorer.src.configLoader import Config
from PyExplorer.src.pluginManager import PluginManager
from PyExplorer.src.package.widgets import AskKey
from PyExplorer.src.package.misc import parseTkEvent

from tkinter import ttk
import ttkthemes as tk_


class WindowStyle:
    _SELECTED = ""
    _STYLES = []
    def __init__(self, master):
        self._style = tk_.ThemedStyle(master._get())
        WindowStyle._SELECTED = Config.SETTINGS_CONFIG["active_theme"]
        WindowStyle._STYLES = list(self._style.theme_names())
        #self.setStyle(WindowStyle._SELECTED)

    def setStyle(self, name:str)->bool:
        try:
            self._style.theme_use(name)
            WindowStyle._SELECTED = name
            Config.SETTINGS_CONFIG["active_theme"] = name
            return True
        except:
            return False
class SettingsGUI(tk.Dialog):
    _OPEN = False
    def __init__(self, master):
        SettingsGUI._OPEN = True
        super().__init__(master, False)
        self.window = master
        self.setTitle("Settings")
        self.setResizeable(False)
        self.setWindowSize(600, 400)
        self.config = Config.SETTINGS_CONFIG

        self.menu = tk.Notebook(self)
        #Frame height: 375
        self.frame_general = self.menu.createNewTab("General")
        self.frame_design = self.menu.createNewTab("Themes & Design")
        self.frame_network = self.menu.createNewTab("Network")
        self.frame_key_binds = self.menu.createNewTab("Keybinds")
        self.frame_advanced = self.menu.createNewTab("Advanced")
        self.frame_plugins = self.menu.createNewTab("Plugins")

        self.menu.placeRelative()
        self.onCloseEvent(self._onCloseEvent)
        self.bind(self.close, tk.EventType.ESC)

        self.create_General(self.frame_general)
        self.create_Themes(self.frame_design)
        self.create_Network(self.frame_network)
        self.create_Keybinds(self.frame_key_binds)
        self.create_Advanced(self.frame_advanced)
        self.create_Plugins(self.frame_plugins)


        self.show()
    def create_General(self, frame):
        fileOptions = tk.LabelFrame(frame).setText("File Options").place(0, 0, 200, 200)
        tk.Checkbutton(fileOptions).setText("Show System Files").placeRelative(fixY=0, fixHeight=25,changeWidth=-5).setState(self.config["show_system_files"]).onSelectEvent(self._changeValue, args=["show_system_files", bool])
        tk.Checkbutton(fileOptions).setText("Show Hidden Files").placeRelative(fixY=25, fixHeight=25,changeWidth=-5).setState(self.config["show_hidden_files"]).onSelectEvent(self._changeValue, args=["show_hidden_files", bool])
    def create_Themes(self, frame):
        def select():
            sucess = self.window.windowStyle.setStyle(spin.getValue())
        label = tk.LabelFrame(frame)
        label.setText("Theme")
        label.place(0, 0, 200, 200)

        spin = tk.DropdownMenu(label)
        spin.setOptionList(WindowStyle._STYLES)
        spin.setValue(WindowStyle._SELECTED)
        spin.onSelectEvent(select)
        spin.setReadOnly()
        spin.place(0, 0, 200-5, 25)



    def create_Network(self, frame):
        pass
    def create_Keybinds(self, frame):
        def search(e):
            content = searchEntry.getValue()
            if searchOption.getState() == 0:
                keybindList.clear()
                for section in Config.KEY_BIND_CONFIG.keys():
                    for name, data in iterDict(Config.KEY_BIND_CONFIG[section]):
                        if (section + ":" + name).startswith(content) or name.startswith(content):
                            keybindList.add(section + ":" + name)
                lf.setText(f"Keybinds ({keybindList.length()})")
            elif searchOption.getState() == 1:
                keybindList.clear()
                for section in Config.KEY_BIND_CONFIG.keys():
                    for name, data in iterDict(Config.KEY_BIND_CONFIG[section]):
                        if content in data["text"]:
                            keybindList.add(section + ":" + name+f":({data['text']})")
                lf.setText(f"Keybinds ({keybindList.length()})")


        def onListSelect():
            sel = keybindList.getSelectedItem()
            if sel is None: return
            data = Settings.getKeyBindData(sel.split(":")[0], sel.split(":")[1])
            keyBindLabel.setText(f"{data['text']}")
        def record():
            bind = AskKey(self).open()
            sel = keybindList.getSelectedItem()
            if bind is None: return
            if sel is None: return
            Settings.setKeyBindData(sel.split(":")[0], sel.split(":")[1], bind)
            onListSelect()
        def reset():
            sel = keybindList.getSelectedItem()
            if sel is None: return
            if sel.split(":")[0] == "main":
                default = Config.KEY_BIND_CONFIG.getDefault()["main"][sel.split(":")[1]]
                Config.KEY_BIND_CONFIG["main"][sel.split(":")[1]] = default
                keyBindLabel.setText(f"{default['text']}")
            else:
                pluginName = sel.split(":")[0]
                pluginData = PluginManager.PLUGIN_DATA_DICT[pluginName]
                default = pluginData["plugin"]._defaultBinds[sel.split(":")[1]]
                Config.KEY_BIND_CONFIG[pluginName][sel.split(":")[1]] = default
                keyBindLabel.setText(f"{default['text']}")
            Config.KEY_BIND_CONFIG.save()
        def setNone():
            sel = keybindList.getSelectedItem()
            if sel is None: return
            Settings.setKeyBindData(sel.split(":")[0], sel.split(":")[1], "CANCEL")
            onListSelect()
        def recreate():
            if tk.SimpleDialog.askOkayCancel(self, "Do you want to recreate the 'key_bindings.json' with default values?", "Settings"):
                Config.KEY_BIND_CONFIG.setDataToDefault()
                Config.KEY_BIND_CONFIG.save()
                updateList()
                keyBindLabel.setText("None")

        def updateList():
            keybindList.clear()
            for section in Config.KEY_BIND_CONFIG.keys():
                for name, data in iterDict(Config.KEY_BIND_CONFIG[section]):
                    keybindList.add(section + ":" + name)

            lf.setText(f"Keybinds ({keybindList.length()})")

        lf = tk.LabelFrame(frame).place(0, 0, 150, 375)
        keybindList = tk.Listbox(lf).placeRelative(changeWidth=-5, changeHeight=-50-50)
        keybindList.onSelectEvent(onListSelect)
        updateList()

        tk.Label(lf).setText("Search:").place(0, 328-50, 145, 25)
        searchEntry = tk.Entry(lf).place(0, 328, 145, 25).onUserInputEvent(search)
        searchOption = tk.Radiobutton(lf).onSelectEvent(search)
        searchOption.createNewRadioButton().setText("name").place(0, 328-25, 72, 25).setSelected()
        searchOption.createNewRadioButton().setText("key").place(72, 328 - 25, 72, 25)

        kbs = tk.LabelFrame(frame).setText("Keybind Settings").place(150, 0, 445, 375)
        tk.Label(kbs).setText("Hotkey:").setTextOrientation(tk.Anchor.LEFT).place(10, 10, 300, 30)
        keyBindLabel = tk.Label(kbs).setText("None").setTextOrientation(tk.Anchor.LEFT).place(56, 10, 300, 30).setFont(underline=True)

        tk.Button(kbs).setText("Record hotkey..").place(0, 375-50, 150, 30).setCommand(record)
        tk.Button(kbs).setText("Reset hotkey").place(150, 375 - 50, 150, 30).setCommand(reset)
        tk.Button(kbs).setText("Disable hotkey").place(300, 375 - 50, 150, 30).setCommand(setNone)
        tk.Button(kbs).setText("Recreate default config").place(300, 375 - 50-30, 150, 30).setCommand(recreate)
    def create_Advanced(self, frame):
        pass
    def create_Plugins(self, frame):
        plSelect = tk.LabelFrame(frame).setText("Plugins").place(0, 0, 150, 375)
        self.pluginList = tk.Listbox(plSelect).placeRelative(changeWidth=-5, changeHeight=-50)
        self.pluginList.onSelectEvent(self.onPluginSelect)
        self.nameToData = {}
        for data in PluginManager.PLUGIN_DATA:
            self.pluginList.add(data["name"])
            self.nameToData[data["name"]] = data
        self.pluginList.setItemSelectedByIndex(0)

        def _openPMgr():
            cancel = self.close()
            if not cancel: PluginManager.openGUI()


        tk.Button(plSelect).setText("Open Plugin Manager").place(0, 328, 145, 25).setCommand(_openPMgr)

        self.pluginSettings = tk.LabelFrame(frame).setText("Plugin Settings").place(150, 0, 445, 375)
        # plugin frame size: 440 355
        self.activePluginFrame = None
        self.onPluginSelect()

    def _changeValue(self, e):
        if isinstance(e, tk.Event):
            value = e.getValue()
            key, _type = e.getArgs()
            self.config[key] = _type(value)
            self.config.save()
    def onPluginSelect(self, e=""):
        sel = self.pluginList.getSelectedItem()
        if sel is not None:
            if self.activePluginFrame is not None:
                self.activePluginFrame.destroy()
                self.activePluginFrame = None

            data = self.nameToData[sel]
            blankFrame = tk.Frame(self.pluginSettings)
            try:
                constructedFrame = data["plugin"]._constructPluginSettings(blankFrame)
            except:
                exc = format_exc()
                tk.SimpleDialog.askError(Settings.WINDOW, "The Settings Frame could not be built.\nCheck the error log on the Frame.", f"Plugin Settings Exception ({data['name']})")
                constructedFrame = tk.Frame(self.pluginSettings)
                tk.Text(constructedFrame, scrollAble=True).setText(exc).setWrapping(tk.Wrap.NONE).place(0, 0, 440, 355)


            self.activePluginFrame:tk.Frame = constructedFrame.placeRelative(changeHeight=-20, changeWidth=-5)
            if len(self.activePluginFrame._getAllChildWidgets()) == 0:
                tk.Label(self.activePluginFrame).setText("This Plugin has no settings!").placeRelative()
    def close(self):
        cancel = self._onCloseEvent("", True)
        if not cancel: self.destroy()
        return cancel
    def _onCloseEvent(self, e, force=False):

        cancel = PluginManager.call("onSettingsCloseEvent")
        if not force: e.setCanceled(cancel)
        SettingsGUI._OPEN = False
        Settings.WINDOW.activeNotebook.activeTab.updateFileTree()
        return cancel
class Settings:
    WINDOW = None
    @staticmethod
    def fileCheck(fileName:str):
        ext = os.path.splitext(fileName)[1]
        if not Settings.get("show_system_files", std=False):
            if ext in [".ini", ".sys"] or fileName.startswith("$"):
                return True
            if fileName == "bootmgr":
                return True
        if not Settings.get("show_hidden_files", std=False):
            if fileName.startswith("."): return True
        return False
    @staticmethod
    def get(key, std):
        return Config.SETTINGS_CONFIG.get(key, std)
    @staticmethod
    def getKeyBindData(sec, name):
        if sec in Config.KEY_BIND_CONFIG.keys():
            if name in Config.KEY_BIND_CONFIG[sec].keys():
                return Config.KEY_BIND_CONFIG[sec][name]
            else:
                tk.SimpleDialog.askWarning(Settings.WINDOW, f"Could not get keybind from config.\nName: '{sec}:{name}'", "Settings")
                return {"bind":"CANCEL", "text":"None"}
        else:
            tk.SimpleDialog.askWarning(Settings.WINDOW, f"Could not get keybind from config.\nSection does not exist!\nName: '{sec}:{name}'", "Settings")
    @staticmethod
    def setKeyBindData(sec, name, bind):
        if sec in Config.KEY_BIND_CONFIG.keys():
            if name in Config.KEY_BIND_CONFIG[sec].keys():
                Config.KEY_BIND_CONFIG[sec][name] = {"bind":bind, "text":parseTkEvent(bind)}
            else:
                tk.SimpleDialog.askWarning(Settings.WINDOW, f"Could not set keybind to {bind}.\nName: '{sec}:{name}'", "Settings")
        else:
            tk.SimpleDialog.askWarning(Settings.WINDOW, f"Could not set keybind to {bind}.\nSection does not exist!\nName: '{sec}:{name}'", "Settings")
            return None
        Config.KEY_BIND_CONFIG.save()
    @staticmethod
    def getKeyBind(name):
        data = Settings.getKeyBindData('main', name)
        if data is None:
            return "CANCEL"
        return data["bind"]
    @staticmethod
    def openGUI():
        if not SettingsGUI._OPEN:
            gui = SettingsGUI(Settings.WINDOW)
    @staticmethod
    def getKeyBindText(name):
        return str(Settings.getKeyBindData('main', name)["text"])
